(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_5c79c8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_5c79c8._.js",
  "chunks": [
    "static/chunks/_2ed78a._.js",
    "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_keyless-actions_746a0c.js"
  ],
  "source": "dynamic"
});
