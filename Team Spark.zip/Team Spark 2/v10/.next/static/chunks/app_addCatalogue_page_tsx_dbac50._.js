(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_addCatalogue_page_tsx_dbac50._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_addCatalogue_page_tsx_dbac50._.js",
  "chunks": [
    "static/chunks/_680965._.js",
    "static/chunks/c488b_next_e8cdd2._.js",
    "static/chunks/97c86_framer-motion_dist_es_8974f3._.js",
    "static/chunks/67227_@radix-ui_react-select_dist_index_mjs_17ccea._.js",
    "static/chunks/node_modules__pnpm_bdc9a7._.js"
  ],
  "source": "dynamic"
});
