(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_user_[id]_page_tsx_d0568e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_user_[id]_page_tsx_d0568e._.js",
  "chunks": [
    "static/chunks/_c34604._.js",
    "static/chunks/c488b_next_e8cdd2._.js",
    "static/chunks/97c86_framer-motion_dist_es_8974f3._.js",
    "static/chunks/node_modules__pnpm_689f77._.js"
  ],
  "source": "dynamic"
});
