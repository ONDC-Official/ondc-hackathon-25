(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_user_[id]_layout_tsx_dbac50._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_user_[id]_layout_tsx_dbac50._.js",
  "chunks": [
    "static/chunks/_a25519._.js"
  ],
  "source": "dynamic"
});
