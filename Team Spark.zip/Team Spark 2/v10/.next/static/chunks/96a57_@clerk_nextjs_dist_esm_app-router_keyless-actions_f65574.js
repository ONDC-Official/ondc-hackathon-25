(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_keyless-actions_f65574.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_keyless-actions_f65574.js",
  "chunks": [
    "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_keyless-actions_921dec.js"
  ],
  "source": "dynamic"
});
