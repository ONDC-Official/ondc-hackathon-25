(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_c04187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_c04187._.js",
  "chunks": [
    "static/chunks/_02f5d4._.js",
    "static/chunks/c488b_next_e8cdd2._.js",
    "static/chunks/97c86_framer-motion_dist_es_8974f3._.js",
    "static/chunks/node_modules__pnpm_689f77._.js"
  ],
  "source": "dynamic"
});
