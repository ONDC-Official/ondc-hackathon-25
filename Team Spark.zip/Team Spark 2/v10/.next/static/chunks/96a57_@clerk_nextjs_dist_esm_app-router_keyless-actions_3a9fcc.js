(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_keyless-actions_3a9fcc.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_keyless-actions_3a9fcc.js",
  "chunks": [
    "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_keyless-actions_921dec.js"
  ],
  "source": "dynamic"
});
