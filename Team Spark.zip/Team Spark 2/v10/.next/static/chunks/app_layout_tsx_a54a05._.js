(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_a54a05._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_a54a05._.js",
  "chunks": [
    "static/chunks/app_globals_73c377.css",
    "static/chunks/node_modules__pnpm_32ec8a._.js",
    "static/chunks/_3040d1._.js",
    "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_c61aa5._.js"
  ],
  "source": "dynamic"
});
