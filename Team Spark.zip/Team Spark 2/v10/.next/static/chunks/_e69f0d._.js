(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d._.js",
  "chunks": [
    "static/chunks/c488b_next_dist_compiled_react-dom_78920d._.js",
    "static/chunks/c488b_next_dist_compiled_f6cecc._.js",
    "static/chunks/c488b_next_dist_client_bc7e39._.js",
    "static/chunks/c488b_next_dist_84105e._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0a._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_847142._.js"
  ],
  "source": "entry"
});
