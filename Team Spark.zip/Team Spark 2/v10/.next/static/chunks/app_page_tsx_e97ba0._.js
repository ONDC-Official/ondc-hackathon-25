(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_e97ba0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_e97ba0._.js",
  "chunks": [
    "static/chunks/_0b7185._.js",
    "static/chunks/c488b_next_79801a._.js",
    "static/chunks/97c86_framer-motion_dist_es_8974f3._.js",
    "static/chunks/node_modules__pnpm_f48d29._.js"
  ],
  "source": "dynamic"
});
