(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_536bc3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_536bc3._.js",
  "chunks": [
    "static/chunks/_b15924._.js",
    "static/chunks/c488b_next_88ddf5._.js",
    "static/chunks/97c86_framer-motion_dist_es_8974f3._.js",
    "static/chunks/node_modules__pnpm_74a20f._.js"
  ],
  "source": "dynamic"
});
