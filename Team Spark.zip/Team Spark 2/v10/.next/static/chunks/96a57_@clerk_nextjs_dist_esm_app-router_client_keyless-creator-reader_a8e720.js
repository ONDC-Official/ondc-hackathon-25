(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_client_keyless-creator-reader_a8e720.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_client_keyless-creator-reader_a8e720.js",
  "chunks": [
    "static/chunks/96a57_@clerk_nextjs_dist_esm_app-router_afcc22._.js"
  ],
  "source": "dynamic"
});
