module.exports = {

"[project]/app/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// import { SidebarDemo } from "@/components/sidebar";
// export default function Home() {
//   return (
//     <div>
//       <SidebarDemo/>
//     </div>
//       );
// }
// Type 1
// import MultiStepForm from "@/components/MultiStepForm";
// export default function Page() {
//   return (
//     <div className="max-w-lg mx-auto mt-10">
//       <MultiStepForm />
//     </div>
//   );
// }
// Type 2
// import ProductCatalogueUploadForm from "@/components/product-catalogue-upload-form"
// export default function Home() {
//   return (
//     <main className="flex min-h-screen flex-col items-center justify-center p-4  ">
//       <ProductCatalogueUploadForm />
//     </main>
//   )
// }
// import  ProductCarousel  from "@/components/sellerCatalogue"
// import productsData from "@/data/products.json"
// export default function CataloguePage() {
//   return (
//     <SidebarDemo/>
//     <div className="max-w-lg mx-auto mt-6">
//       <h1 className="text-3xl font-bold">Your Product Catalogue</h1>
//       <ProductCarousel products={productsData} suppressHydrationWarning/>
//     </div>
//   )
// }
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$clerk$2b$nextjs$40$6$2e$9$2e$14_next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0_$5f$react$2d$dom$40$19$2e$0$2e$_daqgmhlvx3ydhjkoj2cfrzzepa$2f$node_modules$2f40$clerk$2f$nextjs$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@clerk+nextjs@6.9.14_next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0__react-dom@19.0._daqgmhlvx3ydhjkoj2cfrzzepa/node_modules/@clerk/nextjs/dist/esm/index.js [app-rsc] (ecmascript) <locals>");
// import { useRouter } from "next/router";
// const DashboardWithSidebar = () => {
//   const links = [
//     { label: "Dashboard", href: "#", icon: <IconBrandTabler className="icon-class" /> },
//     { label: "Add Catalogue", href: "/addCatalogue", icon: <IconUserBolt className="icon-class" /> },
//     { label: "Settings", href: "#", icon: <IconSettings className="icon-class" /> },
//     { label: "Logout", href: "#", icon: <IconArrowLeft className="icon-class" /> },
//   ];
//   // const router = useRouter();
//   // const { id } = router.query; // Access the dynamic ID from the URL
//   return (
//     <SidebarDemo links={links}>
//       <div className="max-w-lg mx-auto mt-6">
//         <h1 className="text-3xl font-bold mb-4">Your Products</h1>
//         <ProductCarousel products={productsData} suppressHydrationWarning />
//       </div>
//       {/* <div className="max-w-lg mx-auto mt-6">
//       <h1 className="text-3xl font-bold mb-4">Your Product Catalogue</h1>
//       <ProductCarousel products={productsData} />
//     </div> */}
//       {/* <ProductCatalogueUploadForm/> */}
//     </SidebarDemo>
//   );
// };
// export default DashboardWithSidebar;
// 'use client'
// import { useState } from 'react'
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Button } from "@/components/ui/button"
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
// import { Plus, Trash2, Upload } from 'lucide-react'
// import Image from "next/image"
// // Helper function to upload image to Cloudinary
// const uploadImageToCloudinary = async (file: File) => {
//   try {
//     // Get signature and timestamp from the backend API route
//     const response = await fetch('/api/products/1', { method: 'POST' })
//     const { signature, timestamp } = await response.json()
//     const formData = new FormData()
//     formData.append('file', file)
//     formData.append('upload_preset', process.env.NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET ?? '')
//     formData.append('cloud_name', process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME ?? '')
//     formData.append('signature', signature)
//     formData.append('timestamp', timestamp.toString())
//     // Upload to Cloudinary
//     const uploadResponse = await fetch(
//       `https://api.cloudinary.com/v1_1/${process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME}/image/upload`,
//       {
//         method: 'POST',
//         body: formData,
//       }
//     )
//     const data = await uploadResponse.json()
//     if (uploadResponse.ok) {
//       console.log('Image uploaded successfully:', data.secure_url)
//       return { success: true, url: data.secure_url }
//     } else {
//       console.error('Error uploading image:', data)
//       return { success: false, error: data.error.message }
//     }
//   } catch (error) {
//     console.error('Error uploading image:', error)
//     return { success: false, error: error.message }
//   }
// }
// export default function FileUpload({ formData, handleInputChange }) {
//   const [images, setImages] = useState<string[]>([])
//   const [selectedSizes, setSelectedSizes] = useState<number[]>([])
//   const [variants, setVariants] = useState<string[]>(['White Black Lines'])
//   const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
//     const files = e.target.files
//     if (files) {
//       // Process each file and upload to Cloudinary
//       const newImages: string[] = []
//       for (let i = 0; i < files.length; i++) {
//         const file = files[i]
//         const result = await uploadImageToCloudinary(file)
//         if (result.success && result.url) {
//           newImages.push(result.url)
//         }
//       }
//       setImages(prev => [...prev, ...newImages])
//     }
//   }
//   const sizes = Array.from({ length: 8 }, (_, i) => i + 25)
//   const toggleSize = (size: number) => {
//     setSelectedSizes(prev =>
//       prev.includes(size)
//         ? prev.filter(s => s !== size)
//         : [...prev, size]
//     )
//   }
//   return (
//     <div className="space-y-8">
//       {/* Product Images */}
//       <div className="space-y-4">
//         <div className="flex justify-between items-center">
//           <Label className="text-lg font-semibold">
//             Product Images<span className="text-red-500">*</span>
//           </Label>
//           <span className="text-sm text-gray-500">Make your fashion products look more attractive with 3:4 size photos.</span>
//         </div>
//         <div className="grid grid-cols-4 gap-4">
//           {images.map((image, index) => (
//             <div key={index} className="relative aspect-[3/4] bg-gray-100 rounded-lg overflow-hidden">
//               <Image
//                 src={image || "/placeholder.svg"}
//                 alt={`Product ${index + 1}`}
//                 fill
//                 className="object-cover"
//               />
//               <Button
//                 variant="destructive"
//                 size="icon"
//                 className="absolute top-2 right-2 h-8 w-8"
//                 onClick={() => setImages(prev => prev.filter((_, i) => i !== index))}
//               >
//                 <Trash2 className="h-4 w-4" />
//               </Button>
//             </div>
//           ))}
//           <label className="aspect-[3/4] border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50">
//             <Plus className="h-8 w-8 text-gray-400" />
//             <span className="text-sm text-gray-500 mt-2">Add more({6 - images.length})</span>
//             <Input
//               type="file"
//               className="hidden"
//               accept="image/*"
//               multiple
//               onChange={handleImageUpload}
//             />
//           </label>
//         </div>
//       </div>
//       {/* Other form fields */}
//       {/* Product Video */}
//       <div className="space-y-4">
//         <Label className="text-lg font-semibold">Product Video</Label>
//         <div className="text-sm text-gray-500">Size Max: 30MB, Resolution:1×1, 10-60 sec, Format: MP4</div>
//         <div className="border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center">
//           <Upload className="h-8 w-8 text-gray-400 mb-2" />
//           <label className="cursor-pointer">
//             <span className="text-primary">+ Drag or click to add video</span>
//             <Input type="file" accept="video/mp4" className="hidden" />
//           </label>
//         </div>
//       </div>
//       {/* Product Name */}
//       <div className="space-y-4">
//         <Label htmlFor="productName" className="text-lg font-semibold">
//           Product Name<span className="text-red-500">*</span>
//         </Label>
//         <div className="text-sm text-gray-500">Add product title that buyers would likely use to search.</div>
//         <Input
//           id="productName"
//           placeholder="Nike Air Jordan 1 retro High OG University Blue ..."
//           className="w-full"
//         />
//       </div>
//       {/* Product Description */}
//       <div className="space-y-4">
//         <Label htmlFor="productName" className="text-lg font-semibold">
//           Product Description<span className="text-red-500">*</span>
//         </Label>
//         <div className="text-sm text-gray-500">Add product title that buyers would likely use to search.</div>
//         <Input
//           id="productName"
//           placeholder="Product Description ..."
//           className="w-full"
//         />
//       </div>
//       {/* Category */}
//       <div className="space-y-4">
//         <Label className="text-lg font-semibold">
//           Category<span className="text-red-500">*</span>
//         </Label>
//         <div className="text-sm text-gray-500">Choose the category and sub-category most suitable for the product.</div>
//         <div className="flex gap-4">
//           <Select defaultValue="fashion">
//             <SelectTrigger>
//               <SelectValue placeholder="Fashion" />
//             </SelectTrigger>
//             <SelectContent>
//               <SelectItem value="Apparael">Apparael</SelectItem>
//               <SelectItem value="Electronics">Electronics</SelectItem>
//               <SelectItem value="FnB">FnB</SelectItem>
//             </SelectContent>
//           </Select>
//         </div>
//       </div>
//     </div>
//   )
// }
'use client';
;
;
;
function MyApp({ Component, pageProps }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$clerk$2b$nextjs$40$6$2e$9$2e$14_next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0_$5f$react$2d$dom$40$19$2e$0$2e$_daqgmhlvx3ydhjkoj2cfrzzepa$2f$node_modules$2f40$clerk$2f$nextjs$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ClerkProvider"], {
        ...pageProps,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$clerk$2b$nextjs$40$6$2e$9$2e$14_next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0_$5f$react$2d$dom$40$19$2e$0$2e$_daqgmhlvx3ydhjkoj2cfrzzepa$2f$node_modules$2f40$clerk$2f$nextjs$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["SignedIn"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: "You are signed in"
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 281,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 280,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "Always visible"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 283,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 279,
        columnNumber: 5
    }, this);
}
const __TURBOPACK__default__export__ = MyApp;
}}),
"[project]/app/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_namespace__(__turbopack_import__("[project]/app/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=app_page_tsx_107f55._.js.map