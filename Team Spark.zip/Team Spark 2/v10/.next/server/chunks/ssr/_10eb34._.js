module.exports = {

"[project]/components/sidebar.tsx (client proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "SidebarDemo": (()=>SidebarDemo)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const SidebarDemo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call SidebarDemo() from the server but SidebarDemo is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/sidebar.tsx <module evaluation>", "SidebarDemo");
}}),
"[project]/components/sidebar.tsx (client proxy)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "SidebarDemo": (()=>SidebarDemo)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const SidebarDemo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call SidebarDemo() from the server but SidebarDemo is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/sidebar.tsx", "SidebarDemo");
}}),
"[project]/components/sidebar.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$28$client__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/components/sidebar.tsx (client proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/sidebar.tsx (client proxy)");
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$28$client__proxy$29$__);
}}),
"[project]/data/products.json (json)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__(JSON.parse("[{\"id\":1,\"name\":\"Smart 4K TV\",\"description\":\"55-inch 4K Ultra HD Smart LED TV with HDR\",\"price\":699.99,\"imageUrl\":\"https://images.samsung.com/is/image/samsung/p6pim/in/ua50cu7700klxl/gallery/in-crystal-uhd-cu7000-ua50cu7700klxl-535859786?$684_547_PNG$\",\"videoUrl\":null,\"createdAt\":\"2024-01-15T10:00:00Z\",\"updatedAt\":\"2024-02-01T15:30:00Z\",\"categoryId\":1,\"category\":{\"id\":1,\"name\":\"Electronics\"},\"variants\":[{\"id\":101,\"sku\":\"TV-55-BLK\",\"name\":\"55 inch\",\"price\":699.99},{\"id\":102,\"sku\":\"TV-65-BLK\",\"name\":\"65 inch\",\"price\":999.99}],\"images\":[{\"id\":1001,\"url\":\"https://images.samsung.com/is/image/samsung/p6pim/in/ua50cu7700klxl/gallery/in-crystal-uhd-cu7000-ua50cu7700klxl-535859786?$684_547_PNG$\",\"alt\":\"Smart TV - Front View\"}],\"specifications\":{\"resolution\":\"4K Ultra HD\",\"displayType\":\"LED\",\"smartFeatures\":\"Yes\"},\"sellerCompany\":\"TechWorld\"},{\"id\":2,\"name\":\"Wireless Earbuds\",\"description\":\"True wireless earbuds with noise cancellation\",\"price\":149.99,\"imageUrl\":\"https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/25776410/2024/5/24/8faf3a17-ac84-4e51-84b2-87ed5d4aae7e1716533516608-NOISE-Aura-Buds-Truly-Wireless-Earbuds-with-60H-Playtime-and-1.jpg\",\"videoUrl\":null,\"createdAt\":\"2024-01-16T11:00:00Z\",\"updatedAt\":\"2024-02-02T09:30:00Z\",\"categoryId\":1,\"category\":{\"id\":1,\"name\":\"Electronics\"},\"variants\":[{\"id\":201,\"sku\":\"WE-WHT\",\"name\":\"White\",\"price\":149.99},{\"id\":202,\"sku\":\"WE-BLK\",\"name\":\"Black\",\"price\":149.99}],\"images\":[{\"id\":2001,\"url\":\"https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/25776410/2024/5/24/8faf3a17-ac84-4e51-84b2-87ed5d4aae7e1716533516608-NOISE-Aura-Buds-Truly-Wireless-Earbuds-with-60H-Playtime-and-1.jpg\",\"alt\":\"Wireless Earbuds\"}],\"specifications\":{\"batteryLife\":\"24 hours\",\"noiseControl\":\"Active\",\"waterResistant\":\"IPX4\"},\"sellerCompany\":\"AudioTech\"},{\"id\":3,\"name\":\"Gaming Laptop\",\"description\":\"15.6-inch Gaming Laptop with RTX 3060\",\"price\":1299.99,\"imageUrl\":\"https://in-media.apjonlinecdn.com/catalog/product/cache/b3b166914d87ce343d4dc5ec5117b502/c/0/c08867130_1.png\",\"videoUrl\":null,\"createdAt\":\"2024-01-17T12:00:00Z\",\"updatedAt\":\"2024-02-03T10:30:00Z\",\"categoryId\":1,\"category\":{\"id\":1,\"name\":\"Electronics\"},\"variants\":[{\"id\":301,\"sku\":\"GL-16GB\",\"name\":\"16GB RAM\",\"price\":1299.99},{\"id\":302,\"sku\":\"GL-32GB\",\"name\":\"32GB RAM\",\"price\":1499.99}],\"images\":[{\"id\":3001,\"url\":\"https://in-media.apjonlinecdn.com/catalog/product/cache/b3b166914d87ce343d4dc5ec5117b502/c/0/c08867130_1.png\",\"alt\":\"Gaming Laptop\"}],\"specifications\":{\"processor\":\"Intel i7\",\"graphics\":\"RTX 3060\",\"storage\":\"1TB SSD\"},\"sellerCompany\":\"GameTech\"},{\"id\":4,\"name\":\"Smartwatch\",\"description\":\"Advanced fitness tracking smartwatch\",\"price\":199.99,\"imageUrl\":\"https://www.reliancedigital.in/medias/Samsung-Watch7-Smart-Watch-494421968-i-1-1200Wx1200H-300Wx300H?context=bWFzdGVyfGltYWdlc3w0Nzg1NHxpbWFnZS9qcGVnfGltYWdlcy9oOWYvaDQzLzEwMTc0MjU4MzE1Mjk0LmpwZ3xmNzgxNTk0MzBjYjJhOGFjNTAwYWYxOTc4NzUyZGZmNjUyZDE1OGY2ZGM2OTlkMTNlZDMxYWI2YWVkZTc1MzIz\",\"videoUrl\":null,\"createdAt\":\"2024-01-18T13:00:00Z\",\"updatedAt\":\"2024-02-04T11:30:00Z\",\"categoryId\":1,\"category\":{\"id\":1,\"name\":\"Electronics\"},\"variants\":[{\"id\":401,\"sku\":\"SW-SLV\",\"name\":\"Silver\",\"price\":199.99},{\"id\":402,\"sku\":\"SW-GLD\",\"name\":\"Gold\",\"price\":219.99}],\"images\":[{\"id\":4001,\"url\":\"https://www.reliancedigital.in/medias/Samsung-Watch7-Smart-Watch-494421968-i-1-1200Wx1200H-300Wx300H?context=bWFzdGVyfGltYWdlc3w0Nzg1NHxpbWFnZS9qcGVnfGltYWdlcy9oOWYvaDQzLzEwMTc0MjU4MzE1Mjk0LmpwZ3xmNzgxNTk0MzBjYjJhOGFjNTAwYWYxOTc4NzUyZGZmNjUyZDE1OGY2ZGM2OTlkMTNlZDMxYWI2YWVkZTc1MzIz\",\"alt\":\"Smartwatch\"}],\"specifications\":{\"display\":\"AMOLED\",\"batteryLife\":\"5 days\",\"waterproof\":\"Yes\"},\"sellerCompany\":\"WearTech\"},{\"id\":5,\"name\":\"Bluetooth Speaker\",\"description\":\"Portable waterproof bluetooth speaker\",\"price\":79.99,\"imageUrl\":\"https://images-cdn.ubuy.co.in/633ff668d5bfc656c91eef1a-bluetooth-speaker-60w80w-peak-booming.jpg\",\"videoUrl\":null,\"createdAt\":\"2024-01-19T14:00:00Z\",\"updatedAt\":\"2024-02-05T12:30:00Z\",\"categoryId\":1,\"category\":{\"id\":1,\"name\":\"Electronics\"},\"variants\":[{\"id\":501,\"sku\":\"BS-BLU\",\"name\":\"Blue\",\"price\":79.99},{\"id\":502,\"sku\":\"BS-RED\",\"name\":\"Red\",\"price\":79.99}],\"images\":[{\"id\":5001,\"url\":\"https://images-cdn.ubuy.co.in/633ff668d5bfc656c91eef1a-bluetooth-speaker-60w80w-peak-booming.jpg\",\"alt\":\"Bluetooth Speaker\"}],\"specifications\":{\"batteryLife\":\"12 hours\",\"waterproof\":\"IPX7\",\"connectivity\":\"Bluetooth 5.0\"},\"sellerCompany\":\"SoundTech\"},{\"id\":6,\"name\":\"Digital Camera\",\"description\":\"Mirrorless digital camera with 4K video\",\"price\":899.99,\"imageUrl\":\"https://in.canon/media/image/2018/11/19/b639ce271d2b450c974112ee3a7246ba_PowerShot-SX70-HS-Front-Slant.png\",\"videoUrl\":null,\"createdAt\":\"2024-01-20T15:00:00Z\",\"updatedAt\":\"2024-02-06T13:30:00Z\",\"categoryId\":1,\"category\":{\"id\":1,\"name\":\"Electronics\"},\"variants\":[{\"id\":601,\"sku\":\"DC-BLK\",\"name\":\"Black\",\"price\":899.99},{\"id\":602,\"sku\":\"DC-SLV\",\"name\":\"Silver\",\"price\":899.99}],\"images\":[{\"id\":6001,\"url\":\"https://in.canon/media/image/2018/11/19/b639ce271d2b450c974112ee3a7246ba_PowerShot-SX70-HS-Front-Slant.png\",\"alt\":\"Digital Camera\"}],\"specifications\":{\"sensor\":\"24.2MP\",\"video\":\"4K/30fps\",\"stabilization\":\"5-axis\"},\"sellerCompany\":\"CameraTech\"},{\"id\":7,\"name\":\"Denim Jacket\",\"description\":\"Classic denim jacket with modern fit\",\"price\":59.99,\"imageUrl\":\"https://dtcralphlauren.scene7.com/is/image/PoloGSI/s7-1470065_lifestyle?$rl_4x5_pdp$\",\"videoUrl\":null,\"createdAt\":\"2024-01-21T16:00:00Z\",\"updatedAt\":\"2024-02-07T14:30:00Z\",\"categoryId\":2,\"category\":{\"id\":2,\"name\":\"Apparel\"},\"variants\":[{\"id\":701,\"sku\":\"DJ-M-BLU\",\"name\":\"Medium Blue\",\"price\":59.99},{\"id\":702,\"sku\":\"DJ-L-BLU\",\"name\":\"Large Blue\",\"price\":59.99}],\"images\":[{\"id\":7001,\"url\":\"https://dtcralphlauren.scene7.com/is/image/PoloGSI/s7-1470065_lifestyle?$rl_4x5_pdp$\",\"alt\":\"Denim Jacket\"}],\"specifications\":{\"material\":\"100% Cotton\",\"fit\":\"Regular\",\"care\":\"Machine Wash\"},\"sellerCompany\":\"DenimCo\"},{\"id\":8,\"name\":\"Running Shoes\",\"description\":\"Lightweight running shoes with cushioning\",\"price\":129.99,\"imageUrl\":\"https://static.nike.com/a/images/t_PDP_936_v1/f_auto,q_auto:eco/df6a994a-bc85-4637-94bf-3ae4af43a8fe/NIKE+REACTX+INFINITY+RUN+4.png\",\"videoUrl\":null,\"createdAt\":\"2024-01-22T17:00:00Z\",\"updatedAt\":\"2024-02-08T15:30:00Z\",\"categoryId\":2,\"category\":{\"id\":2,\"name\":\"Apparel\"},\"variants\":[{\"id\":801,\"sku\":\"RS-9-BLK\",\"name\":\"Size 9 Black\",\"price\":129.99},{\"id\":802,\"sku\":\"RS-10-BLK\",\"name\":\"Size 10 Black\",\"price\":129.99}],\"images\":[{\"id\":8001,\"url\":\"https://static.nike.com/a/images/t_PDP_936_v1/f_auto,q_auto:eco/df6a994a-bc85-4637-94bf-3ae4af43a8fe/NIKE+REACTX+INFINITY+RUN+4.png\",\"alt\":\"Running Shoes\"}],\"specifications\":{\"material\":\"Mesh\",\"sole\":\"Rubber\",\"closure\":\"Lace-up\"},\"sellerCompany\":\"SportGear\"},{\"id\":9,\"name\":\"Cotton T-Shirt\",\"description\":\"Premium cotton crew neck t-shirt\",\"price\":24.99,\"imageUrl\":\"https://m.media-amazon.com/images/I/61NhI0YYF2L._AC_UY1100_.jpg\",\"videoUrl\":null,\"createdAt\":\"2024-01-23T18:00:00Z\",\"updatedAt\":\"2024-02-09T16:30:00Z\",\"categoryId\":2,\"category\":{\"id\":2,\"name\":\"Apparel\"},\"variants\":[{\"id\":901,\"sku\":\"CT-M-WHT\",\"name\":\"Medium White\",\"price\":24.99},{\"id\":902,\"sku\":\"CT-L-WHT\",\"name\":\"Large White\",\"price\":24.99}],\"images\":[{\"id\":9001,\"url\":\"https://m.media-amazon.com/images/I/61NhI0YYF2L._AC_UY1100_.jpg\",\"alt\":\"Cotton T-Shirt\"}],\"specifications\":{\"material\":\"100% Cotton\",\"fit\":\"Regular\",\"care\":\"Machine Wash\"},\"sellerCompany\":\"BasicWear\"},{\"id\":10,\"name\":\"Winter Jacket\",\"description\":\"Warm winter jacket with hood\",\"price\":149.99,\"imageUrl\":\"https://thesparkshop.in/wp-content/uploads/2022/11/Outwear-Coat-Climbing-Hiking-Women-Winter-Warm-Ski-Snow-Waterproof-Sport-Ski-Jacket.webp\",\"videoUrl\":null,\"createdAt\":\"2024-01-24T19:00:00Z\",\"updatedAt\":\"2024-02-10T17:30:00Z\",\"categoryId\":2,\"category\":{\"id\":2,\"name\":\"Apparel\"},\"variants\":[{\"id\":1001,\"sku\":\"WJ-M-BLK\",\"name\":\"Medium Black\",\"price\":149.99},{\"id\":1002,\"sku\":\"WJ-L-BLK\",\"name\":\"Large Black\",\"price\":149.99}],\"images\":[{\"id\":10001,\"url\":\"https://thesparkshop.in/wp-content/uploads/2022/11/Outwear-Coat-Climbing-Hiking-Women-Winter-Warm-Ski-Snow-Waterproof-Sport-Ski-Jacket.webp\",\"alt\":\"Winter Jacket\"}],\"specifications\":{\"material\":\"Polyester\",\"filling\":\"Down\",\"waterproof\":\"Yes\"},\"sellerCompany\":\"WinterWear\"},{\"id\":11,\"name\":\"Yoga Pants\",\"description\":\"High-waisted yoga pants with pockets\",\"price\":44.99,\"imageUrl\":\"https://www.zemoda.in/cdn/shop/files/Buy_Women_s_Classic_Black_Pocket_Yoga_Pants_Online_Shopping-003.jpg?v=1724837113&width=1946\",\"videoUrl\":null,\"createdAt\":\"2024-01-25T20:00:00Z\",\"updatedAt\":\"2024-02-11T18:30:00Z\",\"categoryId\":2,\"category\":{\"id\":2,\"name\":\"Apparel\"},\"variants\":[{\"id\":1101,\"sku\":\"YP-S-BLK\",\"name\":\"Small Black\",\"price\":44.99},{\"id\":1102,\"sku\":\"YP-M-BLK\",\"name\":\"Medium Black\",\"price\":44.99}],\"images\":[{\"id\":11001,\"url\":\"https://www.zemoda.in/cdn/shop/files/Buy_Women_s_Classic_Black_Pocket_Yoga_Pants_Online_Shopping-003.jpg?v=1724837113&width=1946\",\"alt\":\"Yoga Pants\"}],\"specifications\":{\"material\":\"Spandex Blend\",\"rise\":\"High\",\"length\":\"Full\"},\"sellerCompany\":\"YogaFit\"},{\"id\":12,\"name\":\"Summer Dress\",\"description\":\"Floral print summer dress\",\"price\":39.99,\"imageUrl\":\"https://www.bunaai.com/cdn/shop/products/bahar-6127.jpg?v=1681317553\",\"videoUrl\":null,\"createdAt\":\"2024-01-26T21:00:00Z\",\"updatedAt\":\"2024-02-12T19:30:00Z\",\"categoryId\":2,\"category\":{\"id\":2,\"name\":\"Apparel\"},\"variants\":[{\"id\":1201,\"sku\":\"SD-S-FLR\",\"name\":\"Small Floral\",\"price\":39.99},{\"id\":1202,\"sku\":\"SD-M-FLR\",\"name\":\"Medium Floral\",\"price\":39.99}],\"images\":[{\"id\":12001,\"url\":\"https://www.bunaai.com/cdn/shop/products/bahar-6127.jpg?v=1681317553\",\"alt\":\"Summer Dress\"}],\"specifications\":{\"material\":\"Cotton Blend\",\"length\":\"Knee Length\",\"pattern\":\"Floral\"},\"sellerCompany\":\"SummerStyle\"},{\"id\":13,\"name\":\"Margherita Pizza\",\"description\":\"Classic Italian pizza with fresh basil\",\"price\":14.99,\"imageUrl\":\"https://safrescobaldistatic.blob.core.windows.net/media/2022/11/PIZZA-MARGHERITA.jpg\",\"videoUrl\":null,\"createdAt\":\"2024-01-27T22:00:00Z\",\"updatedAt\":\"2024-02-13T20:30:00Z\",\"categoryId\":3,\"category\":{\"id\":3,\"name\":\"FNB\"},\"variants\":[{\"id\":1301,\"sku\":\"PZ-REG\",\"name\":\"Regular\",\"price\":14.99},{\"id\":1302,\"sku\":\"PZ-LRG\",\"name\":\"Large\",\"price\":19.99}],\"images\":[{\"id\":13001,\"url\":\"https://safrescobaldistatic.blob.core.windows.net/media/2022/11/PIZZA-MARGHERITA.jpg\",\"alt\":\"Margherita Pizza\"}],\"specifications\":{\"size\":\"12 inch\",\"crust\":\"Thin\",\"vegetarian\":\"Yes\"},\"sellerCompany\":\"PizzaHouse\"},{\"id\":14,\"name\":\"Classic Burger\",\"description\":\"Beef burger with cheese and fresh vegetables\",\"price\":12.99,\"imageUrl\":\"https://www.foodandwine.com/thmb/LUEdbNTLcdq_BtCmINp23zQbQro=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/classic-cheeseburgers-eat-delicious-XL-BLOG0517-b578f43651854aeb8e2e605580094811.jpg\",\"videoUrl\":null,\"createdAt\":\"2024-01-28T23:00:00Z\",\"updatedAt\":\"2024-02-14T21:30:00Z\",\"categoryId\":3,\"category\":{\"id\":3,\"name\":\"FNB\"},\"variants\":[{\"id\":1401,\"sku\":\"BG-REG\",\"name\":\"Regular\",\"price\":12.99},{\"id\":1402,\"sku\":\"BG-DBL\",\"name\":\"Double Patty\",\"price\":16.99}],\"images\":[{\"id\":14001,\"url\":\"https://www.foodandwine.com/thmb/LUEdbNTLcdq_BtCmINp23zQbQro=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/classic-cheeseburgers-eat-delicious-XL-BLOG0517-b578f43651854aeb8e2e605580094811.jpg\",\"alt\":\"Classic Burger\"}],\"specifications\":{\"patty\":\"Beef\",\"bun\":\"Sesame\",\"serves\":\"1\"},\"sellerCompany\":\"BurgerJoint\"},{\"id\":15,\"name\":\"Cola Drink\",\"description\":\"Refreshing carbonated cola drink\",\"price\":2.99,\"imageUrl\":\"https://www.ingredientsnetwork.com/47/pdcnewsitem/11/40/74/cocacola-is-world-s-most-valuable-drink-brand-but.jpeg\",\"videoUrl\":null,\"createdAt\":\"2024-01-29T00:00:00Z\",\"updatedAt\":\"2024-02-15T22:30:00Z\",\"categoryId\":3,\"category\":{\"id\":3,\"name\":\"FNB\"},\"variants\":[{\"id\":1501,\"sku\":\"CD-REG\",\"name\":\"Regular\",\"price\":2.99},{\"id\":1502,\"sku\":\"CD-LRG\",\"name\":\"Large\",\"price\":3.99}],\"images\":[{\"id\":15001,\"url\":\"https://www.ingredientsnetwork.com/47/pdcnewsitem/11/40/74/cocacola-is-world-s-most-valuable-drink-brand-but.jpeg\",\"alt\":\"Cola Drink\"}],\"specifications\":{\"size\":\"500ml\",\"calories\":\"140\",\"container\":\"Can\"},\"sellerCompany\":\"BeverageCo\"},{\"id\":16,\"name\":\"Vegetable Pasta\",\"description\":\"Fresh pasta with mixed vegetables\",\"price\":13.99,\"imageUrl\":\"https://fullofplants.com/wp-content/uploads/2023/04/quick-vegan-pasta-vegetable-stir-fry-with-ginger-and-garlic-8.jpg\",\"videoUrl\":null,\"createdAt\":\"2024-01-30T01:00:00Z\",\"updatedAt\":\"2024-02-16T23:30:00Z\",\"categoryId\":3,\"category\":{\"id\":3,\"name\":\"FNB\"},\"variants\":[{\"id\":1601,\"sku\":\"VP-REG\",\"name\":\"Regular\",\"price\":13.99},{\"id\":1602,\"sku\":\"VP-LRG\",\"name\":\"Large\",\"price\":17.99}],\"images\":[{\"id\":16001,\"url\":\"https://fullofplants.com/wp-content/uploads/2023/04/quick-vegan-pasta-vegetable-stir-fry-with-ginger-and-garlic-8.jpg\",\"alt\":\"Vegetable Pasta\"}],\"specifications\":{\"type\":\"Penne\",\"sauce\":\"Tomato\",\"spicyLevel\":\"Mild\"},\"sellerCompany\":\"PastaPlace\"},{\"id\":17,\"name\":\"Chicken Momos\",\"description\":\"Steamed dumplings with chicken filling\",\"price\":8.99,\"imageUrl\":\"https://static.toiimg.com/thumb/60275824.cms?width=1200&height=900\",\"videoUrl\":null,\"createdAt\":\"2024-01-31T02:00:00Z\",\"updatedAt\":\"2024-02-17T00:30:00Z\",\"categoryId\":3,\"category\":{\"id\":3,\"name\":\"FNB\"},\"variants\":[{\"id\":1701,\"sku\":\"CM-6PC\",\"name\":\"6 Pieces\",\"price\":8.99},{\"id\":1702,\"sku\":\"CM-12PC\",\"name\":\"12 Pieces\",\"price\":15.99}],\"images\":[{\"id\":17001,\"url\":\"https://static.toiimg.com/thumb/60275824.cms?width=1200&height=900\",\"alt\":\"Chicken Momos\"}],\"specifications\":{\"filling\":\"Chicken\",\"cooking\":\"Steamed\",\"spicyLevel\":\"Medium\"},\"sellerCompany\":\"MomoHouse\"},{\"id\":18,\"name\":\"Green Tea\",\"description\":\"Premium Japanese green tea\",\"price\":3.99,\"imageUrl\":\"https://domf5oio6qrcr.cloudfront.net/medialibrary/8468/Tea.jpg\",\"videoUrl\":null,\"createdAt\":\"2024-02-01T03:00:00Z\",\"updatedAt\":\"2024-02-18T01:30:00Z\",\"categoryId\":3,\"category\":{\"id\":3,\"name\":\"FNB\"},\"variants\":[{\"id\":1801,\"sku\":\"GT-REG\",\"name\":\"Regular\",\"price\":3.99},{\"id\":1802,\"sku\":\"GT-LRG\",\"name\":\"Large\",\"price\":4.99}],\"images\":[{\"id\":18001,\"url\":\"https://domf5oio6qrcr.cloudfront.net/medialibrary/8468/Tea.jpg\",\"alt\":\"Green Tea\"}],\"specifications\":{\"type\":\"Sencha\",\"origin\":\"Japan\",\"serving\":\"Hot\"},\"sellerCompany\":\"TeaHouse\"},{\"id\":19,\"name\":\"Ice Cream Sundae\",\"description\":\"Classic vanilla ice cream sundae with toppings\",\"price\":6.99,\"imageUrl\":\"https://ticktocktea.com/cdn/shop/articles/Ice-Cream-Sundae-800x800px-min.jpg?v=1657010846\",\"videoUrl\":null,\"createdAt\":\"2024-02-02T04:00:00Z\",\"updatedAt\":\"2024-02-19T02:30:00Z\",\"categoryId\":3,\"category\":{\"id\":3,\"name\":\"FNB\"},\"variants\":[{\"id\":1901,\"sku\":\"IC-REG\",\"name\":\"Regular\",\"price\":6.99},{\"id\":1902,\"sku\":\"IC-LRG\",\"name\":\"Large\",\"price\":8.99}],\"images\":[{\"id\":19001,\"url\":\"https://ticktocktea.com/cdn/shop/articles/Ice-Cream-Sundae-800x800px-min.jpg?v=1657010846\",\"alt\":\"Ice Cream Sundae\"}],\"specifications\":{\"flavor\":\"Vanilla\",\"toppings\":\"Chocolate Sauce, Nuts\",\"serves\":\"1\"},\"sellerCompany\":\"IceCreamParlor\"},{\"id\":20,\"name\":\"Fresh Fruit Juice\",\"description\":\"Mixed fresh fruit juice blend\",\"price\":4.99,\"imageUrl\":\"https://static.vecteezy.com/system/resources/previews/029/283/229/non_2x/a-front-view-fresh-fruit-cocktails-with-fresh-fruit-slices-ice-cooling-on-blue-drink-juice-co-free-photo.jpg\",\"videoUrl\":null,\"createdAt\":\"2024-02-03T05:00:00Z\",\"updatedAt\":\"2024-02-20T03:30:00Z\",\"categoryId\":3,\"category\":{\"id\":3,\"name\":\"FNB\"},\"variants\":[{\"id\":2001,\"sku\":\"FJ-REG\",\"name\":\"Regular\",\"price\":4.99},{\"id\":2002,\"sku\":\"FJ-LRG\",\"name\":\"Large\",\"price\":6.99}],\"images\":[{\"id\":20001,\"url\":\"https://static.vecteezy.com/system/resources/previews/029/283/229/non_2x/a-front-view-fresh-fruit-cocktails-with-fresh-fruit-slices-ice-cooling-on-blue-drink-juice-co-free-photo.jpg\",\"alt\":\"Fresh Fruit Juice\"}],\"specifications\":{\"fruits\":\"Orange, Apple, Pineapple\",\"sugar\":\"No Added Sugar\",\"volume\":\"350ml\"},\"sellerCompany\":\"JuiceBar\"}]"));}}),
"[project]/components/sellerCatalogue.tsx (client proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/sellerCatalogue.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/sellerCatalogue.tsx <module evaluation>", "default");
}}),
"[project]/components/sellerCatalogue.tsx (client proxy)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/sellerCatalogue.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/sellerCatalogue.tsx", "default");
}}),
"[project]/components/sellerCatalogue.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$28$client__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/components/sellerCatalogue.tsx (client proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/sellerCatalogue.tsx (client proxy)");
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$28$client__proxy$29$__);
}}),
"[project]/components/product-catalogue-upload-form.tsx (client proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/product-catalogue-upload-form.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/product-catalogue-upload-form.tsx <module evaluation>", "default");
}}),
"[project]/components/product-catalogue-upload-form.tsx (client proxy)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/product-catalogue-upload-form.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/product-catalogue-upload-form.tsx", "default");
}}),
"[project]/components/product-catalogue-upload-form.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$product$2d$catalogue$2d$upload$2d$form$2e$tsx__$28$client__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/components/product-catalogue-upload-form.tsx (client proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$product$2d$catalogue$2d$upload$2d$form$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/product-catalogue-upload-form.tsx (client proxy)");
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$product$2d$catalogue$2d$upload$2d$form$2e$tsx__$28$client__proxy$29$__);
}}),
"[project]/app/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// import { SidebarDemo } from "@/components/sidebar";
// export default function Home() {
//   return (
//     <div>
//       <SidebarDemo/>
//     </div>
//       );
// }
// Type 1
// import MultiStepForm from "@/components/MultiStepForm";
// export default function Page() {
//   return (
//     <div className="max-w-lg mx-auto mt-10">
//       <MultiStepForm />
//     </div>
//   );
// }
// Type 2
// import ProductCatalogueUploadForm from "@/components/product-catalogue-upload-form"
// export default function Home() {
//   return (
//     <main className="flex min-h-screen flex-col items-center justify-center p-4  ">
//       <ProductCatalogueUploadForm />
//     </main>
//   )
// }
// import  ProductCarousel  from "@/components/sellerCatalogue"
// import productsData from "@/data/products.json"
// export default function CataloguePage() {
//   return (
//     <SidebarDemo/>
//     <div className="max-w-lg mx-auto mt-6">
//       <h1 className="text-3xl font-bold">Your Product Catalogue</h1>
//       <ProductCarousel products={productsData} suppressHydrationWarning/>
//     </div>
//   )
// }
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/sidebar.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__ = __turbopack_import__("[project]/data/products.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/sellerCatalogue.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$product$2d$catalogue$2d$upload$2d$form$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/product-catalogue-upload-form.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconBrandTabler$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconBrandTabler$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tabler+icons-react@3.28.1_react@19.0.0/node_modules/@tabler/icons-react/dist/esm/icons/IconBrandTabler.mjs [app-rsc] (ecmascript) <export default as IconBrandTabler>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconUserBolt$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconUserBolt$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tabler+icons-react@3.28.1_react@19.0.0/node_modules/@tabler/icons-react/dist/esm/icons/IconUserBolt.mjs [app-rsc] (ecmascript) <export default as IconUserBolt>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconSettings$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconSettings$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tabler+icons-react@3.28.1_react@19.0.0/node_modules/@tabler/icons-react/dist/esm/icons/IconSettings.mjs [app-rsc] (ecmascript) <export default as IconSettings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconArrowLeft$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconArrowLeft$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tabler+icons-react@3.28.1_react@19.0.0/node_modules/@tabler/icons-react/dist/esm/icons/IconArrowLeft.mjs [app-rsc] (ecmascript) <export default as IconArrowLeft>");
;
;
;
;
;
;
// import { useRouter } from "next/router";
const DashboardWithSidebar = ()=>{
    const links = [
        {
            label: "Dashboard",
            href: "#",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconBrandTabler$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconBrandTabler$3e$__["IconBrandTabler"], {
                className: "icon-class"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 61,
                columnNumber: 44
            }, this)
        },
        {
            label: "Catalogue",
            href: "/user/111",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconUserBolt$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconUserBolt$3e$__["IconUserBolt"], {
                className: "icon-class"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 62,
                columnNumber: 52
            }, this)
        },
        {
            label: "Settings",
            href: "#",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconSettings$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconSettings$3e$__["IconSettings"], {
                className: "icon-class"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 63,
                columnNumber: 43
            }, this)
        },
        {
            label: "Logout",
            href: "#",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconArrowLeft$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconArrowLeft$3e$__["IconArrowLeft"], {
                className: "icon-class"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 64,
                columnNumber: 41
            }, this)
        }
    ];
    // const router = useRouter();
    // const { id } = router.query; // Access the dynamic ID from the URL
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SidebarDemo"], {
        links: links,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-lg mx-auto mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-3xl font-bold mb-4",
                        children: "Your Products | User ID:"
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        products: __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__["default"],
                        suppressHydrationWarning: true
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$product$2d$catalogue$2d$upload$2d$form$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = DashboardWithSidebar;
 // 'use client'
 // import { useState } from 'react'
 // import { Input } from "@/components/ui/input"
 // import { Label } from "@/components/ui/label"
 // import { Button } from "@/components/ui/button"
 // import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
 // import { Plus, Trash2, Upload } from 'lucide-react'
 // import Image from "next/image"
 // // Helper function to upload image to Cloudinary
 // const uploadImageToCloudinary = async (file: File) => {
 //   try {
 //     // Get signature and timestamp from the backend API route
 //     const response = await fetch('/api/products/1', { method: 'POST' })
 //     const { signature, timestamp } = await response.json()
 //     const formData = new FormData()
 //     formData.append('file', file)
 //     formData.append('upload_preset', process.env.NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET ?? '')
 //     formData.append('cloud_name', process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME ?? '')
 //     formData.append('signature', signature)
 //     formData.append('timestamp', timestamp.toString())
 //     // Upload to Cloudinary
 //     const uploadResponse = await fetch(
 //       `https://api.cloudinary.com/v1_1/${process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME}/image/upload`,
 //       {
 //         method: 'POST',
 //         body: formData,
 //       }
 //     )
 //     const data = await uploadResponse.json()
 //     if (uploadResponse.ok) {
 //       console.log('Image uploaded successfully:', data.secure_url)
 //       return { success: true, url: data.secure_url }
 //     } else {
 //       console.error('Error uploading image:', data)
 //       return { success: false, error: data.error.message }
 //     }
 //   } catch (error) {
 //     console.error('Error uploading image:', error)
 //     return { success: false, error: error.message }
 //   }
 // }
 // export default function FileUpload({ formData, handleInputChange }) {
 //   const [images, setImages] = useState<string[]>([])
 //   const [selectedSizes, setSelectedSizes] = useState<number[]>([])
 //   const [variants, setVariants] = useState<string[]>(['White Black Lines'])
 //   const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
 //     const files = e.target.files
 //     if (files) {
 //       // Process each file and upload to Cloudinary
 //       const newImages: string[] = []
 //       for (let i = 0; i < files.length; i++) {
 //         const file = files[i]
 //         const result = await uploadImageToCloudinary(file)
 //         if (result.success && result.url) {
 //           newImages.push(result.url)
 //         }
 //       }
 //       setImages(prev => [...prev, ...newImages])
 //     }
 //   }
 //   const sizes = Array.from({ length: 8 }, (_, i) => i + 25)
 //   const toggleSize = (size: number) => {
 //     setSelectedSizes(prev =>
 //       prev.includes(size)
 //         ? prev.filter(s => s !== size)
 //         : [...prev, size]
 //     )
 //   }
 //   return (
 //     <div className="space-y-8">
 //       {/* Product Images */}
 //       <div className="space-y-4">
 //         <div className="flex justify-between items-center">
 //           <Label className="text-lg font-semibold">
 //             Product Images<span className="text-red-500">*</span>
 //           </Label>
 //           <span className="text-sm text-gray-500">Make your fashion products look more attractive with 3:4 size photos.</span>
 //         </div>
 //         <div className="grid grid-cols-4 gap-4">
 //           {images.map((image, index) => (
 //             <div key={index} className="relative aspect-[3/4] bg-gray-100 rounded-lg overflow-hidden">
 //               <Image
 //                 src={image || "/placeholder.svg"}
 //                 alt={`Product ${index + 1}`}
 //                 fill
 //                 className="object-cover"
 //               />
 //               <Button
 //                 variant="destructive"
 //                 size="icon"
 //                 className="absolute top-2 right-2 h-8 w-8"
 //                 onClick={() => setImages(prev => prev.filter((_, i) => i !== index))}
 //               >
 //                 <Trash2 className="h-4 w-4" />
 //               </Button>
 //             </div>
 //           ))}
 //           <label className="aspect-[3/4] border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50">
 //             <Plus className="h-8 w-8 text-gray-400" />
 //             <span className="text-sm text-gray-500 mt-2">Add more({6 - images.length})</span>
 //             <Input
 //               type="file"
 //               className="hidden"
 //               accept="image/*"
 //               multiple
 //               onChange={handleImageUpload}
 //             />
 //           </label>
 //         </div>
 //       </div>
 //       {/* Other form fields */}
 //       {/* Product Video */}
 //       <div className="space-y-4">
 //         <Label className="text-lg font-semibold">Product Video</Label>
 //         <div className="text-sm text-gray-500">Size Max: 30MB, Resolution:1×1, 10-60 sec, Format: MP4</div>
 //         <div className="border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center">
 //           <Upload className="h-8 w-8 text-gray-400 mb-2" />
 //           <label className="cursor-pointer">
 //             <span className="text-primary">+ Drag or click to add video</span>
 //             <Input type="file" accept="video/mp4" className="hidden" />
 //           </label>
 //         </div>
 //       </div>
 //       {/* Product Name */}
 //       <div className="space-y-4">
 //         <Label htmlFor="productName" className="text-lg font-semibold">
 //           Product Name<span className="text-red-500">*</span>
 //         </Label>
 //         <div className="text-sm text-gray-500">Add product title that buyers would likely use to search.</div>
 //         <Input
 //           id="productName"
 //           placeholder="Nike Air Jordan 1 retro High OG University Blue ..."
 //           className="w-full"
 //         />
 //       </div>
 //       {/* Product Description */}
 //       <div className="space-y-4">
 //         <Label htmlFor="productName" className="text-lg font-semibold">
 //           Product Description<span className="text-red-500">*</span>
 //         </Label>
 //         <div className="text-sm text-gray-500">Add product title that buyers would likely use to search.</div>
 //         <Input
 //           id="productName"
 //           placeholder="Product Description ..."
 //           className="w-full"
 //         />
 //       </div>
 //       {/* Category */}
 //       <div className="space-y-4">
 //         <Label className="text-lg font-semibold">
 //           Category<span className="text-red-500">*</span>
 //         </Label>
 //         <div className="text-sm text-gray-500">Choose the category and sub-category most suitable for the product.</div>
 //         <div className="flex gap-4">
 //           <Select defaultValue="fashion">
 //             <SelectTrigger>
 //               <SelectValue placeholder="Fashion" />
 //             </SelectTrigger>
 //             <SelectContent>
 //               <SelectItem value="Apparael">Apparael</SelectItem>
 //               <SelectItem value="Electronics">Electronics</SelectItem>
 //               <SelectItem value="FnB">FnB</SelectItem>
 //             </SelectContent>
 //           </Select>
 //         </div>
 //       </div>
 //     </div>
 //   )
 // }
}}),
"[project]/app/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_namespace__(__turbopack_import__("[project]/app/page.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/.next-internal/server/app/page/actions.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=_10eb34._.js.map