module.exports = {

"[project]/components/sidebar.tsx (client proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "SidebarDemo": (()=>SidebarDemo)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const SidebarDemo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call SidebarDemo() from the server but SidebarDemo is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/sidebar.tsx <module evaluation>", "SidebarDemo");
}}),
"[project]/components/sidebar.tsx (client proxy)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "SidebarDemo": (()=>SidebarDemo)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const SidebarDemo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call SidebarDemo() from the server but SidebarDemo is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/sidebar.tsx", "SidebarDemo");
}}),
"[project]/components/sidebar.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$28$client__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/components/sidebar.tsx (client proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/sidebar.tsx (client proxy)");
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$28$client__proxy$29$__);
}}),
"[project]/data/products.json (json)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__(JSON.parse("[{\"id\":1,\"name\":\"4K OLED Smart TV\",\"description\":\"Experience stunning picture quality and smart features with this 4K OLED TV.\",\"price\":1499.99,\"imageUrl\":\"https://amstradworld.com/wp-content/uploads/2023/12/Amstrad-AM65UWGTA-WebOS-TV_front.jpg\",\"videoUrl\":\"https://example.com/videos/4k-oled-smart-tv-demo.mp4\",\"createdAt\":\"2023-01-10T09:00:00Z\",\"updatedAt\":\"2023-06-15T14:30:00Z\",\"categoryId\":1,\"category\":{\"id\":1,\"name\":\"Electronics\"},\"variants\":[{\"id\":101,\"sku\":\"TV-OLED-55\",\"name\":\"55 inch\",\"price\":1499.99},{\"id\":102,\"sku\":\"TV-OLED-65\",\"name\":\"65 inch\",\"price\":1999.99}],\"images\":[{\"id\":1001,\"url\":\"https://amstradworld.com/wp-content/uploads/2023/12/Amstrad-AM65UWGTA-WebOS-TV_front.jpg\",\"alt\":\"4K OLED Smart TV - Front View\"},{\"id\":1002,\"url\":\"https://m.media-amazon.com/images/I/51EXj4BRQaL.jpg\",\"alt\":\"4K OLED Smart TV - Angle View\"},{\"id\":1003,\"url\":\"https://amstradworld.com/wp-content/uploads/2023/12/Amstrad-AM65UWGTA-WebOS-TV_front.jpg\",\"alt\":\"4K OLED Smart TV - Remote Control\"}],\"specifications\":{\"brand\":\"TechVision\",\"model\":\"OLED-5500X\",\"screenSize\":\"55 inches\",\"resolution\":\"3840 x 2160 (4K)\",\"hdrSupport\":[\"HDR10\",\"Dolby Vision\"],\"refreshRate\":\"120Hz\",\"smartFeatures\":[\"Voice Control\",\"App Store\",\"Screen Mirroring\"],\"connectivity\":[\"Wi-Fi 6\",\"Bluetooth 5.0\",\"HDMI 2.1 x 4\",\"USB 3.0 x 3\"],\"audioOutput\":\"40W (2.1 Channel)\",\"dimensions\":\"122.8 x 70.6 x 2.3 cm\",\"weight\":\"16.8 kg\"},\"sellerCompany\":\"ElectroHub Inc.\"},{\"id\":2,\"name\":\"Wireless Noise-Cancelling Headphones\",\"description\":\"Immerse yourself in your music with these premium wireless noise-cancelling headphones.\",\"price\":299.99,\"imageUrl\":\"https://m.media-amazon.com/images/I/51EXj4BRQaL.jpg\",\"videoUrl\":\"https://example.com/videos/wireless-headphones-demo.mp4\",\"createdAt\":\"2023-02-05T11:30:00Z\",\"updatedAt\":\"2023-06-20T16:45:00Z\",\"categoryId\":1,\"category\":{\"id\":1,\"name\":\"Electronics\"},\"variants\":[{\"id\":201,\"sku\":\"WH-NC-BLK\",\"name\":\"Black\",\"price\":299.99},{\"id\":202,\"sku\":\"WH-NC-WHT\",\"name\":\"White\",\"price\":299.99},{\"id\":203,\"sku\":\"WH-NC-NAVY\",\"name\":\"Navy Blue\",\"price\":309.99}],\"images\":[{\"id\":2001,\"url\":\"https://m.media-amazon.com/images/I/51EXj4BRQaL.jpg\",\"alt\":\"Wireless Noise-Cancelling Headphones - Front View\"},{\"id\":2002,\"url\":\"https://m.media-amazon.com/images/I/51EXj4BRQaL.jpg\",\"alt\":\"Wireless Noise-Cancelling Headphones - Side View\"},{\"id\":2003,\"url\":\"https://m.media-amazon.com/images/I/51EXj4BRQaL.jpg\",\"alt\":\"Wireless Noise-Cancelling Headphones - Folded\"}],\"specifications\":{\"brand\":\"SoundMaster\",\"model\":\"WH-1000XM5\",\"type\":\"Over-ear\",\"wireless\":true,\"noiseCancelling\":true,\"battery\":\"Up to 30 hours\",\"driver\":\"40mm\",\"frequency\":\"4Hz-40,000Hz\",\"bluetooth\":\"5.2\",\"weight\":\"250g\",\"additionalFeatures\":[\"Touch controls\",\"Adaptive sound control\",\"Multipoint connection\"]},\"sellerCompany\":\"AudioTech Co.\"},{\"id\":3,\"name\":\"Classic Leather Jacket\",\"description\":\"A timeless leather jacket that combines style and durability for a classic look.\",\"price\":249.99,\"imageUrl\":\"https://hnscraftsmanship.com/wp-content/uploads/2024/05/CLASSIC-LEATHER-JACKET-003-%E2%80%93-BLACK.jpg\",\"videoUrl\":null,\"createdAt\":\"2023-03-15T13:45:00Z\",\"updatedAt\":\"2023-06-25T10:20:00Z\",\"categoryId\":2,\"category\":{\"id\":2,\"name\":\"Apparel\"},\"variants\":[{\"id\":301,\"sku\":\"LJ-CL-S-BLK\",\"name\":\"Small - Black\",\"price\":249.99},{\"id\":302,\"sku\":\"LJ-CL-M-BLK\",\"name\":\"Medium - Black\",\"price\":249.99},{\"id\":303,\"sku\":\"LJ-CL-L-BLK\",\"name\":\"Large - Black\",\"price\":249.99},{\"id\":304,\"sku\":\"LJ-CL-XL-BLK\",\"name\":\"X-Large - Black\",\"price\":269.99}],\"images\":[{\"id\":3001,\"url\":\"https://hnscraftsmanship.com/wp-content/uploads/2024/05/CLASSIC-LEATHER-JACKET-003-%E2%80%93-BLACK.jpg\",\"alt\":\"Classic Leather Jacket - Front View\"},{\"id\":3002,\"url\":\"https://hnscraftsmanship.com/wp-content/uploads/2024/05/CLASSIC-LEATHER-JACKET-003-%E2%80%93-BLACK.jpg\",\"alt\":\"Classic Leather Jacket - Back View\"},{\"id\":3003,\"url\":\"https://hnscraftsmanship.com/wp-content/uploads/2024/05/CLASSIC-LEATHER-JACKET-003-%E2%80%93-BLACK.jpg\",\"alt\":\"Classic Leather Jacket - Detail View\"}],\"specifications\":{\"material\":\"100% Genuine Leather\",\"lining\":\"100% Polyester\",\"closure\":\"YKK Zipper\",\"pockets\":\"2 side pockets, 1 inner pocket\",\"fit\":\"Regular fit\",\"care\":\"Professional leather clean only\",\"origin\":\"Made in Italy\"},\"sellerCompany\":\"UrbanStyle Apparel\"},{\"id\":4,\"name\":\"Smart Fitness Watch\",\"description\":\"Track your fitness goals with this feature-packed smart fitness watch.\",\"price\":199.99,\"imageUrl\":\"https://5.imimg.com/data5/ANDROID/Default/2022/8/IU/QR/QN/148827935/product-jpeg-500x500.jpg\",\"videoUrl\":\"https://example.com/videos/smart-fitness-watch-features.mp4\",\"createdAt\":\"2023-04-20T08:15:00Z\",\"updatedAt\":\"2023-06-30T11:50:00Z\",\"categoryId\":1,\"category\":{\"id\":1,\"name\":\"Electronics\"},\"variants\":[{\"id\":401,\"sku\":\"SFW-BLK\",\"name\":\"Black\",\"price\":199.99},{\"id\":402,\"sku\":\"SFW-SLVR\",\"name\":\"Silver\",\"price\":199.99},{\"id\":403,\"sku\":\"SFW-ROSE\",\"name\":\"Rose Gold\",\"price\":209.99}],\"images\":[{\"id\":4001,\"url\":\"https://5.imimg.com/data5/ANDROID/Default/2022/8/IU/QR/QN/148827935/product-jpeg-500x500.jpg\",\"alt\":\"Smart Fitness Watch - Front View\"},{\"id\":4002,\"url\":\"https://5.imimg.com/data5/ANDROID/Default/2022/8/IU/QR/QN/148827935/product-jpeg-500x500.jpg\",\"alt\":\"Smart Fitness Watch - Side View\"},{\"id\":4003,\"url\":\"https://5.imimg.com/data5/ANDROID/Default/2022/8/IU/QR/QN/148827935/product-jpeg-500x500.jpg\",\"alt\":\"Smart Fitness Watch - App Interface\"}],\"specifications\":{\"brand\":\"FitTech\",\"model\":\"ProActive 2000\",\"display\":\"1.4 inch AMOLED\",\"resolution\":\"454 x 454 pixels\",\"waterResistance\":\"5 ATM\",\"sensors\":[\"Heart rate\",\"GPS\",\"Accelerometer\",\"Gyroscope\",\"Altimeter\"],\"battery\":\"Up to 14 days\",\"compatibility\":\"iOS 11.0+ / Android 6.0+\",\"connectivity\":[\"Bluetooth 5.0\",\"Wi-Fi\"],\"features\":[\"24/7 heart rate monitoring\",\"Sleep tracking\",\"50+ sport modes\",\"Blood oxygen monitoring\"]},\"sellerCompany\":\"FitTech Innovations\"},{\"id\":5,\"name\":\"Designer Tote Bag\",\"description\":\"A stylish and spacious tote bag perfect for work or weekend outings.\",\"price\":129.99,\"imageUrl\":\"https://i.pinimg.com/736x/08/44/0d/08440d16139a5600db51676c7196ec91.jpg\",\"videoUrl\":null,\"createdAt\":\"2023-05-05T10:00:00Z\",\"updatedAt\":\"2023-07-01T09:30:00Z\",\"categoryId\":3,\"category\":{\"id\":3,\"name\":\"Fashion\"},\"variants\":[{\"id\":501,\"sku\":\"DTB-TAN\",\"name\":\"Tan\",\"price\":129.99},{\"id\":502,\"sku\":\"DTB-BLK\",\"name\":\"Black\",\"price\":129.99},{\"id\":503,\"sku\":\"DTB-NVY\",\"name\":\"Navy\",\"price\":129.99}],\"images\":[{\"id\":5001,\"url\":\"https://i.pinimg.com/736x/08/44/0d/08440d16139a5600db51676c7196ec91.jpg\",\"alt\":\"Designer Tote Bag - Front View\"},{\"id\":5002,\"url\":\"https://i.pinimg.com/736x/08/44/0d/08440d16139a5600db51676c7196ec91.jpg\",\"alt\":\"Designer Tote Bag - Inside View\"},{\"id\":5003,\"url\":\"https://i.pinimg.com/736x/08/44/0d/08440d16139a5600db51676c7196ec91.jpg\",\"alt\":\"Designer Tote Bag - Worn\"}],\"specifications\":{\"material\":\"Full-grain leather\",\"dimensions\":\"40cm x 30cm x 15cm\",\"handle\":\"Double top handles, 25cm drop\",\"closure\":\"Top zip closure\",\"interior\":\"Fabric lining, 1 zip pocket, 2 slip pockets\",\"exterior\":\"1 front slip pocket\",\"hardware\":\"Gold-tone\",\"care\":\"Wipe clean with a soft, dry cloth\"},\"sellerCompany\":\"LuxeStyle Accessories\"}]"));}}),
"[project]/components/sellerCatalogue.tsx (client proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ProductCarousel": (()=>ProductCarousel)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const ProductCarousel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ProductCarousel() from the server but ProductCarousel is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/sellerCatalogue.tsx <module evaluation>", "ProductCarousel");
}}),
"[project]/components/sellerCatalogue.tsx (client proxy)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ProductCarousel": (()=>ProductCarousel)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const ProductCarousel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ProductCarousel() from the server but ProductCarousel is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/sellerCatalogue.tsx", "ProductCarousel");
}}),
"[project]/components/sellerCatalogue.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$28$client__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/components/sellerCatalogue.tsx (client proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/sellerCatalogue.tsx (client proxy)");
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$28$client__proxy$29$__);
}}),
"[project]/components/ui/toaster.tsx (client proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Toaster": (()=>Toaster)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const Toaster = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Toaster() from the server but Toaster is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/ui/toaster.tsx <module evaluation>", "Toaster");
}}),
"[project]/components/ui/toaster.tsx (client proxy)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Toaster": (()=>Toaster)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const Toaster = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Toaster() from the server but Toaster is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/ui/toaster.tsx", "Toaster");
}}),
"[project]/components/ui/toaster.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toaster$2e$tsx__$28$client__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/components/ui/toaster.tsx (client proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toaster$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/ui/toaster.tsx (client proxy)");
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toaster$2e$tsx__$28$client__proxy$29$__);
}}),
"[project]/app/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// import { SidebarDemo } from "@/components/sidebar";
// export default function Home() {
//   return (
//     <div>
//       <SidebarDemo/>
//     </div>
//       );
// }
// Type 1
// import MultiStepForm from "@/components/MultiStepForm";
// export default function Page() {
//   return (
//     <div className="max-w-lg mx-auto mt-10">
//       <MultiStepForm />
//     </div>
//   );
// }
// Type 2
// import ProductCatalogueUploadForm from "@/components/product-catalogue-upload-form"
// export default function Home() {
//   return (
//     <main className="flex min-h-screen flex-col items-center justify-center p-4  ">
//       <ProductCatalogueUploadForm />
//     </main>
//   )
// }
// import  ProductCarousel  from "@/components/sellerCatalogue"
// import productsData from "@/data/products.json"
// export default function CataloguePage() {
//   return (
//     <SidebarDemo/>
//     <div className="max-w-lg mx-auto mt-6">
//       <h1 className="text-3xl font-bold">Your Product Catalogue</h1>
//       <ProductCarousel products={productsData} suppressHydrationWarning/>
//     </div>
//   )
// }
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.4_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/sidebar.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__ = __turbopack_import__("[project]/data/products.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/sellerCatalogue.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toaster$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/ui/toaster.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconBrandTabler$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconBrandTabler$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tabler+icons-react@3.28.1_react@19.0.0/node_modules/@tabler/icons-react/dist/esm/icons/IconBrandTabler.mjs [app-rsc] (ecmascript) <export default as IconBrandTabler>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconUserBolt$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconUserBolt$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tabler+icons-react@3.28.1_react@19.0.0/node_modules/@tabler/icons-react/dist/esm/icons/IconUserBolt.mjs [app-rsc] (ecmascript) <export default as IconUserBolt>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconSettings$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconSettings$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tabler+icons-react@3.28.1_react@19.0.0/node_modules/@tabler/icons-react/dist/esm/icons/IconSettings.mjs [app-rsc] (ecmascript) <export default as IconSettings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconArrowLeft$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconArrowLeft$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tabler+icons-react@3.28.1_react@19.0.0/node_modules/@tabler/icons-react/dist/esm/icons/IconArrowLeft.mjs [app-rsc] (ecmascript) <export default as IconArrowLeft>");
;
;
;
;
;
;
// import { useRouter } from "next/router";
const DashboardWithSidebar = ()=>{
    const links = [
        {
            label: "Dashboard",
            href: "#",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconBrandTabler$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconBrandTabler$3e$__["IconBrandTabler"], {
                className: "icon-class"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 62,
                columnNumber: 44
            }, this)
        },
        {
            label: "Catalogue",
            href: "/user/111",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconUserBolt$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconUserBolt$3e$__["IconUserBolt"], {
                className: "icon-class"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 63,
                columnNumber: 52
            }, this)
        },
        {
            label: "Settings",
            href: "#",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconSettings$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconSettings$3e$__["IconSettings"], {
                className: "icon-class"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 64,
                columnNumber: 43
            }, this)
        },
        {
            label: "Logout",
            href: "#",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tabler$2b$icons$2d$react$40$3$2e$28$2e$1_react$40$19$2e$0$2e$0$2f$node_modules$2f40$tabler$2f$icons$2d$react$2f$dist$2f$esm$2f$icons$2f$IconArrowLeft$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__IconArrowLeft$3e$__["IconArrowLeft"], {
                className: "icon-class"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 65,
                columnNumber: 41
            }, this)
        }
    ];
    // const router = useRouter();
    // const { id } = router.query; // Access the dynamic ID from the URL
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SidebarDemo"], {
        links: links,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-lg mx-auto mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-3xl font-bold mb-4",
                        children: "Your Product Catalogue"
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 78,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sellerCatalogue$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ProductCarousel"], {
                        products: __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__["default"]
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 79,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$4_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toaster$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Toaster"], {}, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 81,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 72,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = DashboardWithSidebar;
 // 'use client'
 // import { useState } from 'react'
 // import { Input } from "@/components/ui/input"
 // import { Label } from "@/components/ui/label"
 // import { Button } from "@/components/ui/button"
 // import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
 // import { Plus, Trash2, Upload } from 'lucide-react'
 // import Image from "next/image"
 // // Helper function to upload image to Cloudinary
 // const uploadImageToCloudinary = async (file: File) => {
 //   try {
 //     // Get signature and timestamp from the backend API route
 //     const response = await fetch('/api/products/1', { method: 'POST' })
 //     const { signature, timestamp } = await response.json()
 //     const formData = new FormData()
 //     formData.append('file', file)
 //     formData.append('upload_preset', process.env.NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET ?? '')
 //     formData.append('cloud_name', process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME ?? '')
 //     formData.append('signature', signature)
 //     formData.append('timestamp', timestamp.toString())
 //     // Upload to Cloudinary
 //     const uploadResponse = await fetch(
 //       `https://api.cloudinary.com/v1_1/${process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME}/image/upload`,
 //       {
 //         method: 'POST',
 //         body: formData,
 //       }
 //     )
 //     const data = await uploadResponse.json()
 //     if (uploadResponse.ok) {
 //       console.log('Image uploaded successfully:', data.secure_url)
 //       return { success: true, url: data.secure_url }
 //     } else {
 //       console.error('Error uploading image:', data)
 //       return { success: false, error: data.error.message }
 //     }
 //   } catch (error) {
 //     console.error('Error uploading image:', error)
 //     return { success: false, error: error.message }
 //   }
 // }
 // export default function FileUpload({ formData, handleInputChange }) {
 //   const [images, setImages] = useState<string[]>([])
 //   const [selectedSizes, setSelectedSizes] = useState<number[]>([])
 //   const [variants, setVariants] = useState<string[]>(['White Black Lines'])
 //   const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
 //     const files = e.target.files
 //     if (files) {
 //       // Process each file and upload to Cloudinary
 //       const newImages: string[] = []
 //       for (let i = 0; i < files.length; i++) {
 //         const file = files[i]
 //         const result = await uploadImageToCloudinary(file)
 //         if (result.success && result.url) {
 //           newImages.push(result.url)
 //         }
 //       }
 //       setImages(prev => [...prev, ...newImages])
 //     }
 //   }
 //   const sizes = Array.from({ length: 8 }, (_, i) => i + 25)
 //   const toggleSize = (size: number) => {
 //     setSelectedSizes(prev =>
 //       prev.includes(size)
 //         ? prev.filter(s => s !== size)
 //         : [...prev, size]
 //     )
 //   }
 //   return (
 //     <div className="space-y-8">
 //       {/* Product Images */}
 //       <div className="space-y-4">
 //         <div className="flex justify-between items-center">
 //           <Label className="text-lg font-semibold">
 //             Product Images<span className="text-red-500">*</span>
 //           </Label>
 //           <span className="text-sm text-gray-500">Make your fashion products look more attractive with 3:4 size photos.</span>
 //         </div>
 //         <div className="grid grid-cols-4 gap-4">
 //           {images.map((image, index) => (
 //             <div key={index} className="relative aspect-[3/4] bg-gray-100 rounded-lg overflow-hidden">
 //               <Image
 //                 src={image || "/placeholder.svg"}
 //                 alt={`Product ${index + 1}`}
 //                 fill
 //                 className="object-cover"
 //               />
 //               <Button
 //                 variant="destructive"
 //                 size="icon"
 //                 className="absolute top-2 right-2 h-8 w-8"
 //                 onClick={() => setImages(prev => prev.filter((_, i) => i !== index))}
 //               >
 //                 <Trash2 className="h-4 w-4" />
 //               </Button>
 //             </div>
 //           ))}
 //           <label className="aspect-[3/4] border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50">
 //             <Plus className="h-8 w-8 text-gray-400" />
 //             <span className="text-sm text-gray-500 mt-2">Add more({6 - images.length})</span>
 //             <Input
 //               type="file"
 //               className="hidden"
 //               accept="image/*"
 //               multiple
 //               onChange={handleImageUpload}
 //             />
 //           </label>
 //         </div>
 //       </div>
 //       {/* Other form fields */}
 //       {/* Product Video */}
 //       <div className="space-y-4">
 //         <Label className="text-lg font-semibold">Product Video</Label>
 //         <div className="text-sm text-gray-500">Size Max: 30MB, Resolution:1×1, 10-60 sec, Format: MP4</div>
 //         <div className="border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center">
 //           <Upload className="h-8 w-8 text-gray-400 mb-2" />
 //           <label className="cursor-pointer">
 //             <span className="text-primary">+ Drag or click to add video</span>
 //             <Input type="file" accept="video/mp4" className="hidden" />
 //           </label>
 //         </div>
 //       </div>
 //       {/* Product Name */}
 //       <div className="space-y-4">
 //         <Label htmlFor="productName" className="text-lg font-semibold">
 //           Product Name<span className="text-red-500">*</span>
 //         </Label>
 //         <div className="text-sm text-gray-500">Add product title that buyers would likely use to search.</div>
 //         <Input
 //           id="productName"
 //           placeholder="Nike Air Jordan 1 retro High OG University Blue ..."
 //           className="w-full"
 //         />
 //       </div>
 //       {/* Product Description */}
 //       <div className="space-y-4">
 //         <Label htmlFor="productName" className="text-lg font-semibold">
 //           Product Description<span className="text-red-500">*</span>
 //         </Label>
 //         <div className="text-sm text-gray-500">Add product title that buyers would likely use to search.</div>
 //         <Input
 //           id="productName"
 //           placeholder="Product Description ..."
 //           className="w-full"
 //         />
 //       </div>
 //       {/* Category */}
 //       <div className="space-y-4">
 //         <Label className="text-lg font-semibold">
 //           Category<span className="text-red-500">*</span>
 //         </Label>
 //         <div className="text-sm text-gray-500">Choose the category and sub-category most suitable for the product.</div>
 //         <div className="flex gap-4">
 //           <Select defaultValue="fashion">
 //             <SelectTrigger>
 //               <SelectValue placeholder="Fashion" />
 //             </SelectTrigger>
 //             <SelectContent>
 //               <SelectItem value="Apparael">Apparael</SelectItem>
 //               <SelectItem value="Electronics">Electronics</SelectItem>
 //               <SelectItem value="FnB">FnB</SelectItem>
 //             </SelectContent>
 //           </Select>
 //         </div>
 //       </div>
 //     </div>
 //   )
 // }
}}),
"[project]/app/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_namespace__(__turbopack_import__("[project]/app/page.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/.next-internal/server/app/page/actions.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=_e2b050._.js.map