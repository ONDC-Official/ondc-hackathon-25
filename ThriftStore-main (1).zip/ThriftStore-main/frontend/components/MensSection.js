import React from 'react';
import { Link } from 'react-router-dom';

const MensSection = () => {
  return (
    <div>
      <h3>MensSection</h3>
    </div>
  )
}

export default MensSection
