import { Component, CUSTOM_ELEMENTS_SCHEMA, ElementRef, inject, viewChild, ViewChild } from '@angular/core';
import { NavbarComponent } from "../navbar/navbar.component";
import { FooterComponent } from "../footer/footer.component";
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgIf, NgFor } from '@angular/common';

declare var webkitSpeechRecognition: any; // Declare the SpeechRecognition API

import { AuthService } from '../services/auth.service';


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [NavbarComponent, FooterComponent, NgFor],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  cards = [
    {
      imgSrc: 'https://www.pngall.com/wp-content/uploads/13/Galaxy-S23-Ultra.png',
      title: 'Samsung Galaxy S23',
      price: 74999
    },
    {
      imgSrc: 'https://i.pinimg.com/originals/3a/78/87/3a78872b49e9024ad04243fe78d18663.png',
      title: 'Apple MacBook Air M2',
      price: 114900
    },
    {
      imgSrc: 'https://th.bing.com/th/id/R.e9344088b16009df0a91e0dd584136e0?rik=XVtkYN2AbYbxJw&riu=http%3a%2f%2fbbprod.weebly.com%2fuploads%2f2%2f0%2f0%2f2%2f20024585%2fthumbnails-large-default-upload-bucket-001-wh-1000xm4-w-1-png.png&ehk=ZBy8J89laMdBKJnOtvhokaAXgF5Lh73wxpFbSYY4ab8%3d&risl=&pid=ImgRaw&r=0',
      title: 'Sony WH-1000XM5 Headphones',
      price: 29990
    },
    {
      imgSrc: 'https://helios-i.mashable.com/imagery/articles/03qayUxYR7FoyvTHbIPJIrK/images-1.fill.size_2000x2000.v1646058644.png',
      title: 'Poco X6 Pro 5G',
      price: 13999
    },
    {
      imgSrc: 'https://static.iphoned.nl/orca/products/20160/apple-watch-series-9.png?w=960&h=640&fit=fill-max',
      title: 'Apple Watch Series 9',
      price: 41900
    }
  ];

  cards1 = [
    {
      imgSrc: 'https://th.bing.com/th/id/R.1d91033174585a81d67b0c4be91e0b76?rik=iGPVl3e0G6VK0g&riu=http%3a%2f%2fwww.spottedfashion.com%2fwp-content%2fuploads%2f2017%2f03%2fChanel-Black-Classic-Pure-Jumbo-Flap-Bag.png&ehk=GnQum1h9%2blFw8qzSNWuB%2bQ2U2X5nVlZLgUaYp9P%2bZH0%3d&risl=&pid=ImgRaw&r=0',
      title: 'Chanel Classic Flap Bag',
      price: 7499
    },
    {
      imgSrc: 'https://img1.picmix.com/output/stamp/normal/5/1/0/8/1918015_17344.png',
      title: 'Dior JAdore Perfume',
      price: 199
    },
    {
      imgSrc: 'https://www.pngmart.com/files/23/Gucci-Belt-Transparent-PNG.png',
      title: 'Gucci Leather Belt',
      price: 399
    },
    {
      imgSrc: 'https://assets.sunglasshut.com/is/image/LuxotticaRetail/8056597894791__STD__shad__qt.png?impolicy=SGH_bgtransparent',
      title: 'Versace Sunglasses',
      price: 299
    },
    {
      imgSrc: 'https://freepngclipart.com/download/lips/88198-yves-laurent-lipstick-gloss-lip-saint-rouge.png',
      title: 'Yves Saint Laurent Lipstick',
      price: 599
    }
  ];


  scroll(direction: string, div:string) {
    const container = document.querySelector('.'+div) as HTMLElement;
    const scrollAmount = 300; // Adjust based on card width and gap
    if (direction === 'prev') {
      container.scrollLeft -= scrollAmount;
    } else if (direction === 'next') {
      container.scrollLeft += scrollAmount;
    }
  }
}
