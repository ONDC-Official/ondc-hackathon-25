import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {

  private apiUrl = 'http://localhost:3000/ecommerce/routes';
  constructor(private http: HttpClient) {}
  //Add Plant Details
  addPlantDetails(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/add-plants`, data);
  }
  // Send contact form
  sendContactForm(formValues: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/contact-form`, formValues);
  }
  // Signup form
  signup(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/signup`, data);
  }
  // Login form
  login(data: any) {
    return this.http.post<any>(`${this.apiUrl}/login`, data);
  }
  verifyLoginOtp(data: any) {
    return this.http.post<any>(`${this.apiUrl}/verify-login-otp`, data);
  }
  verifyOtp(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/verify-otp`, data);
  }
  logout(email: string) {
    return this.http.post<any>(`${this.apiUrl}/logout`, { email });
  }
  // Forgot password - Step 1: Send OTP
  sendOtp(email: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/forgot-password`, { email });
  }
  // Forgot password - Step 2: Verify OTP
  verifyForgotPasswordOtp(email: string, otp: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/verify-forgotp-otp`, { email, otp });
  }
  // Forgot password - Step 3: Reset Password
  resetPassword(email: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/reset-password`, { email, password });
  }
  isLoggedIn(): boolean {
    return !!localStorage.getItem('token'); // Check if token exists in localStorage
  }
  getUserName(email: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/getUserName`, { email });
  }
  // Verify Secret Key
  verifySecretKey(secretKey: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/verifySecretKey`, { secretKey });
  }
  // Verify Admin OTP
  verifyAdminOtp(otp: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/verifyAdminOtp`, { otp });
  }
  //Check User Type
  userType(email: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/user-type`, { email });
  }
  //Check if shop is registered
  isShopRegistered(email: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/shop-registered`, { email });
  }
  //Add Shop Details
  addShopDetails(data: any, email: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/add-details`, { ...data, email });
  }
  //Fetch Shop Details
  fetchShopDetails(email: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/fetch-details`, { email });
  }
  //Fetch Shops which are not verified
  fetchUnverifiedShops(page: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/fetch-unverified-shops?page=${page}`);
  }
  //Verify Shop Details
  verifyShopDetails(email: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/verify-shop`, { email });
  }
}

