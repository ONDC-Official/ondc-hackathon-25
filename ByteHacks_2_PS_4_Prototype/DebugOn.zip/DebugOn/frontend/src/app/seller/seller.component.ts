import { Component, CUSTOM_ELEMENTS_SCHEMA, inject } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { FooterComponent } from '../footer/footer.component';
import { HttpClient } from '@angular/common/http';
import { Chart } from 'chart.js';
import { AuthService } from '../services/auth.service';
import { Router, RouterLink } from '@angular/router';
import { NgFor,NgIf } from '@angular/common';
import { FormsModule, NgModel, ReactiveFormsModule } from '@angular/forms';
import { NotificationService } from '../services/notification.service';

@Component({
  selector: 'app-seller',
  imports: [ RouterLink, FooterComponent, NgIf, FormsModule ],
  templateUrl: './seller.component.html',
  styleUrl: './seller.component.css'
})
export class SellerComponent {
    loggedIn = false;
    isSeller = false;
    isRegistrationCommpleted = true;

    //Get user email from localstorage
    email = localStorage.getItem('email');
    userName = localStorage.getItem('userName');

    private http = inject(HttpClient);
    private authService = inject(AuthService);
    private router = inject(Router);
    private notification = inject(NotificationService);
    shopDetails = {
      shopName: '',
      gstNumber: '',
      address: '',
      contactNumber: '',
      empployeesNumber: '',
      shopType: '',
      details: '',
      isVerified: false
    };

    gstInvalid = false;

    // verifyGstin() {
    //   this.http.post('/api/verify-gst', { gstNumber: this.shopDetails.gstNumber }).subscribe(
    //     (res: any) => {
    //       this.gstInvalid = !res.valid;
    //     },
    //     () => {
    //       this.gstInvalid = true;
    //     }
    //   );
    // }
    addProduct(){}
    verifyGstin() {}
    submitDetails(form: any) {
      if (form.valid && !this.gstInvalid && this.email) {
        this.authService.addShopDetails(this.shopDetails, this.email).subscribe(
          (res: any) => {
            this.notification.showNotification('Details added successfully!', 'success');
          },
          (err) => {
            this.notification.showNotification('Failed to add details.', 'error');
          }
        );
      }
    }


    ngOnInit(): void {
      if(this.email){
        this.authService.isShopRegistered(this.email).subscribe(
          (res) => {
            this.isRegistrationCommpleted = res.shopRegistered;
            if(res.shopRegistered && this.email){
              this.authService.fetchShopDetails(this.email).subscribe(
                (res) => {
                  this.shopDetails = res.shopDetails;
                  console.log(this.shopDetails)
                },
                (err) => {
                  this.notification.showNotification(`${err.error.msg}`,'error');
                }
              )
            }
          },
          (err) => {
            this.notification.showNotification(`${err.error.msg}`,'error');
          }
        )
      }
    }
    //Logout User
    logout() {
      const email = localStorage.getItem('email');
      if (email) {

        this.authService.logout(email).subscribe(
          (res) => {
            // Clear localStorage and update component state
            localStorage.clear();
            this.loggedIn = false;
            this.isSeller = false;

            // Navigate back to the login page
            this.router.navigate(['/login']);
            this.notification.showNotification(`${res.msg}`,'success');  // Show success message
          },
          (err) => {
            this.notification.showNotification(`${err.error.msg}`,'error');
          }
        );
      }
    }
    goToSection(section: string) {
      // Navigate to the home component and scroll to the #about section
      this.router.navigate([''], { fragment: `${section}` });
      if (this.router.url === '/') {
        const gallerySection = document.getElementById(section);
        if (gallerySection) {
          gallerySection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      } else {
        this.router.navigate(['/']).then(() => {
          const gallerySection = document.getElementById(section);
          if (gallerySection) {
            gallerySection.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        });
      }
    }
}
