//User model for users
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
  userName: { type: String },
  email: { type: String, required: true, unique: true },
  password: { type: String },
  userType: { type: String},
  otp: { type: String },
  gstNumber: { type: String },
  address: { type: String },
  shopName: { type: String },
  contactNumber: { type: String },
  empployeesNumber: { type: String },
  shopType: { type: String },
  details: { type: String },
  shopImage: { type: String },
  isVerified: { type: Boolean, default: false },
  isRegistered: { type: Boolean, default: false }
});

module.exports = mongoose.model('User', userSchema);