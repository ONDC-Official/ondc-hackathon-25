const express = require('express');
const router = express.Router();

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const User = require('../models/ecommerce_user');

const { GoogleGenerativeAI } = require('@google/generative-ai');
const { console } = require('inspector');

// let SummarizerManager = require("node-summarizer").SummarizerManager;

require('dotenv').config();
// const upload = multer({ dest: 'uploads/' });

// Plant.ID API configuration

const apiKey = process.env.API_KEY;
const genAI = new GoogleGenerativeAI(apiKey);
const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

//Nodemailer setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER, 
    pass: process.env.EMAIL_PASS 
  }
});

// API request to /api/users

//Contact Form
router.post('/contact-form', (req, res) => {
  const { name, email, profession, message } = req.body;
  try {
    const mailOptions = {
      from: process.env.EMAIL_USER, // User's email
      to: process.env.EMAIL_USER, // Admin's email
      subject: `New Message from ${name}`,
      text: `Profession: ${profession}\nMessage: ${message}\nFrom: ${email}`
    };
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return res.status(500).json({ msg: 'Error sending email' });
      } else {
        return res.status(200).json({ msg: 'Message sent successfully' });
      }
    });
  } catch (err) {
    // console.error(err.message);
    res.status(500).send('Server error');
  }
});


// Register Route
router.post('/signup', async (req, res) => {
  const { email } = req.body;
  console.log(email);
  
  try {
    console.log(email);
    // Check if the user already exists and has completed registration
    let user = await User.findOne({ email });

    // If user exists and has completed registration
    if (user && user.userName && user.password) {
      return res.status(200).json({ error: true, msg: 'User already exists' });
    }

    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000); // 6-digit OTP

    if (user && !user.userName) {
      // User exists with only email and otp, update the OTP
      user.otp = otp;
      await user.save();
    } else {
      // Create new user with just email, userId, and OTP
      user = new User({
        email,
        otp,
      });
      await user.save();
    }

    // Send OTP to email using Nodemailer
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'OTP Verification',
      text: `Your OTP is ${otp}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return res.status(500).json({ msg: 'Error sending OTP' });
      } else {
        res.status(200).json({ msg: 'OTP sent successfully', email });
      }
    });
  } catch (err) {
    res.status(500).send('Server error'); // Do not expose specific error details
  }
});

router.post('/verify-otp', async (req, res) => {
  const { email, otp, userName, password, userType } = req.body;

  try {
    // Find user by email
    let user = await User.findOne({ email });

    if (!user || !user.otp) {
      return res.status(200).json({ error: true, msg: 'OTP has not been sent. Please sign up first.' });
    }

    // Check if OTP matches
    if (user.otp !== otp) {
      return res.status(200).json({ error: true, msg: 'Invalid OTP' });
    }

    const _userType = email === process.env.EMAIL_USER ? 'admin' : userType;

    // Update user details after successful OTP verification
    user.userName = userName;
    user.password = bcrypt.hashSync(password, 10); // Hash password
    user.otp = undefined;  // Remove OTP after verification
    user.userType = _userType;

    await user.save();

    res.status(200).json({ msg: 'User registered successfully', isAdmin: email === EMAIL_USER });
  } catch (err) {
    res.status(500).send('Server error');
  }
});
//Login Route
router.post('/login', async (req, res) => {
  const { email, password, userType } = req.body;

  try {
    // Find user by email
    let user = await User.findOne({ email });
    if (!user || !user.userName) {
      return res.status(200).json({ error: true, msg: 'User not found' });
    }
    if(!user.userType){
      return res.status(200).json({ error: true, msg: 'Invalid User Type' });
    }
    if(user.userType !== userType){
      return res.status(200).json({ error: true, msg: 'Access denied' });
    }
    // Compare the entered password with the hashed password in the database
    const isMatch = await bcrypt.compare(password, user.password);
    
    if (!isMatch) {
      return res.status(200).json({ error: true, msg: 'Invalid email or password' });
    }

    // OTP handling and JWT generation
    const otp = Math.floor(100000 + Math.random() * 900000); // 6-digit OTP
    user.otp = otp;
    await user.save();

    // Send OTP to email using Nodemailer
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Login OTP Verification',
      text: `Your OTP is ${otp}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return res.status(500).json({ msg: 'Error sending OTP' });
      } else {
        res.status(200).json({ msg: 'OTP sent successfully', userId: user._id });
      }
    });
  } catch (err) {
    res.status(500).send('Server error');
  }
});

router.post('/verify-login-otp', async (req, res) => {
  const { email, otp } = req.body;

  try {
    // Find the user by email
    let user = await User.findOne({ email });

    if (!user || !user.otp) {
      return res.status(200).json({ error: true, msg: 'OTP has not been sent. Please try logging in again.' });
    }

    if (user.otp !== otp) {
      return res.status(200).json({ error: true, msg: 'Invalid OTP' });
    }

    const token = jwt.sign({ userId: user.userId }, process.env.JWT_TOKEN, { expiresIn: '168h' });

    user.otp = undefined;
    await user.save();
    const userstatus = user.userType
    if(userstatus === 'admin'){
      return res.status(200).json({ error: false, msg: 'Login successful', isAdmin: true, token });
    }
    if(userstatus === 'seller'){
      return res.status(200).json({ error: false, msg: 'Login successful', isSeller: true, token });
    }
    else{
      return res.status(200).json({ error: false, msg: 'Login successful', isAdmin: false, token });
    }
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// Logout Route
router.post('/logout', async (req, res) => {
  const { email } = req.body;

  try {

    // Find the user by email
    let user = await User.findOne({ email });
    
    if (!user) {
      return res.status(200).json({error:true, msg: 'User not found' });
    }

    // Update loggedInStatus to false
    user.loggedInStatus = false;
    await user.save();

    res.status(200).json({ msg: 'Logout successful' });
  } catch (err) {
    res.status(500).send('Server error');
  }
});
// Forgot Password Route - Step 1: Generate OTP and send to email address
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  try {
    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      // User-specific error, return 400 but not log
      return res.status(400).json({ msg: 'User not found' });
    }
    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000); // 6-digit OTP
    user.otp = otp;
    await user.save();

    // Send OTP to email using Nodemailer
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Password Reset OTP',
      text: `Your OTP for password reset is ${otp}`
    };

    transporter.sendMail(mailOptions, (error) => {
      if (error) {
        // Server error when sending email
        return res.status(500).json({ msg: 'Error sending OTP, please try again later.' });
      }
      // Success
      return res.status(200).json({ msg: 'OTP sent successfully', userId: user._id });
    });

  } catch (err) {
    // Server error, log it and return 500 status
    return res.status(500).json({ msg: 'Server error, please try again later.' });
  }
});

// OTP Verification Route - Step 2: Verify OTP and allow password reset
router.post('/verify-forgotp-otp', async (req, res) => {
  const { email, otp } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user || user.otp !== otp) {
      // User-specific error, return 400 but not log
      return res.status(400).json({ msg: 'Invalid OTP' });
    }

    // OTP is valid, allow password reset
    return res.status(200).json({ msg: 'OTP verified successfully' });
  } catch (err) {
    // Server error, log it and return 500 status
    return res.status(500).json({ msg: 'Server error, please try again later.' });
  }
});

// Password Reset Route - Step 3: Reset Password
router.post('/reset-password', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      // User-specific error, return 400 but not log
      return res.status(400).json({ msg: 'User not found' });
    }

    // Hash the new password
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(password, salt);
    user.otp = undefined; // Clear OTP after password reset
    await user.save();

    // Success
    return res.status(200).json({ msg: 'Password changed successfully' });
  } catch (err) {
    // Server error, log it and return 500 status
    return res.status(500).json({ msg: 'Server error, please try again later.' });
  }
});
// Find the user by email
router.post('/getUserName', async (req, res) => {
  const { email } = req.body; 
    try {
        // Fetch user by email, selecting only the userName field
        const user = await User.findOne({ email: email }, 'userName');

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        return res.status(200).json({ name: user.userName });
    } catch (error) {
        console.error('Error fetching user by email:', error);
        return res.status(500).json({ message: 'Internal server error' });
    }
});
router.post('/user-type', async (req, res) => {
  const { email } = req.body;
  try {
    let user = await User.findOne({email});
    if (user.userType === 'admin') {
      return res.status(200).json({ userType: 'admin' });
    }
    else if (user.userType === 'student') {
      return res.status(200).json({ userType: 'student' });
    }
  } catch (err) {
    res.status(500).send('Server error');
  }
});
//Check if the shop is registered

router.post('/shop-registered', async (req, res) => {
  const { email } = req.body;
  try {
    let shop = await User.findOne({ email });
    if (shop.isRegistered) {
      return res.status(200).json({ shopRegistered: true });
    }
    else {
      return res.status(200).json({ shopRegistered: false });
    }
  } catch (err) {
    res.status(500).send('Server error');
  }
});
router.post('/add-details', async (req, res) => {
  const { email, shopName, gstNumber, address, contactNumber, empployeesNumber, shopType, details } = req.body;
  try {
    const user = await User.findOneAndUpdate(
      { email },
      {
        $set: {
          shopName,
          gstNumber,
          address,
          contactNumber,
          empployeesNumber,
          shopType,
          details,
          isRegistered: true
        }
      },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({ message: 'Details added successfully' });
  } catch (error) {
    console.error('Error adding shop details:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Get shop details

router.post('/fetch-details', async (req, res) => {
  const { email } = req.body;
  try {
    let shop = await User.findOne({ email });
    if (shop) {
      console.log(shop)
      return res.status(200).json({ shopDetails: shop });
    } else {
      return res.status(200).json({ shopDetails: null });
    }
  } catch (err) {
    res.status(500).send('Server error');
  }
});
//Fetch shop details which are not verified
router.get('/fetch-unverified-shops', async (req, res) => {
  const { page = 0 } = req.query; // Default to page 0 if not provided
  const PAGE_SIZE = 10; // Number of shops per page

  try {
    // Find shops with pagination
    const shops = await User.find({ isVerified: false , isRegistered: true })
      .skip(page * PAGE_SIZE) // Skip the first (page * PAGE_SIZE) results
      .limit(PAGE_SIZE) // Limit results to PAGE_SIZE
      .exec();

    // Get the total number of shops
    const totalShops = await User.countDocuments({ isVerified: false });

    res.status(200).json({
      shops,
      total: totalShops, // Total number of shops
    });
  } catch (err) {
    console.error('Error fetching shops:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update shop details to verified
router.post('/verify-shop', async (req, res) => {
  const { email } = req.body;
  try {
    const user = await User.findOneAndUpdate(
      { email },
      {
        $set: {
          isVerified: true
        }
      },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({ message: 'Shop verified successfully' });
  } catch (error) {
    console.error('Error verifying shop:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});
module.exports = router