product_name = unquote(product_name)
    product_name = product_name.replace('/', ' ')