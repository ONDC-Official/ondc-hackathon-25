
document.getElementById('productForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Get the product description
    var description = document.getElementById('productDescription').value;
    document.getElementById('previewDescription').textContent = description;

    // Get the product image
    var fileInput = document.getElementById('productImage');
    var file = fileInput.files[0];
    var reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('previewImage').src = e.target.result;
    };
    reader.readAsDataURL(file);

    // Show the product preview
    document.getElementById('productPreview').style.display = 'block';
});