function nextStep(step) {
    document.querySelectorAll('.step').forEach(function(stepElement) {
        stepElement.style.display = 'none';
    });
    document.getElementById('step-' + step).style.display = 'block';
}

function prevStep(step) {
    document.querySelectorAll('.step').forEach(function(stepElement) {
        stepElement.style.display = 'none';
    });
    document.getElementById('step-' + step).style.display = 'block';
}

function sendOtp() {
    alert('OTP sent to your registered mobile number.');
}

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission
    window.location.href = 'home.html'; // Redirect to the home page
});

document.getElementById('signupForm').addEventListener('submit', function(event) {
    // ...existing code...
});

document.getElementById('verifyButton').addEventListener('click', function() {
    // ...existing code...
});

document.getElementById('gstForm').addEventListener('submit', function(event) {
    // ...existing code...
});

document.getElementById('languageSelect').addEventListener('change', function(event) {
    // ...existing code...
});

document.addEventListener('DOMContentLoaded', function() {
    // Add any JavaScript functionality here if needed
});
