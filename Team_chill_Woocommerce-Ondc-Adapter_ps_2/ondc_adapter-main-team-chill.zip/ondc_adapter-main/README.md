### ONDC ADAPTER

- Live Link: [https://ondc-woocom-adapter.netlify.app/](https://ondc-woocom-adapter.netlify.app/)

- Video Link: [Click Here!!](https://drive.google.com/drive/folders/1d5jPVZnj79-01zUEA3_9bUE21RtoamuO?usp=sharing)