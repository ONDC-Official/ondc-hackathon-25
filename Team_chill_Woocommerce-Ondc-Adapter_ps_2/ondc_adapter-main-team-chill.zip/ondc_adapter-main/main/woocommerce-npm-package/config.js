// const dotenv = require('dotenv');
// const path = require('path');

// // Load environment variables
// dotenv.config({ path: path.join(process.cwd(), '.env') });

// const config = {
//   woocommerce: {
//     storeUrl: process.env.WOOCOMMERCE_STORE_URL,
//     consumerKey: process.env.WOOCOMMERCE_CONSUMER_KEY,
//     consumerSecret: process.env.WOOCOMMERCE_CONSUMER_SECRET,
//     version: process.env.WOOCOMMERCE_API_VERSION || 'wc/v3'
//   },
//   ondc: {
//     networkId: process.env.ONDC_NETWORK_ID,
//     subscriberId: process.env.ONDC_SUBSCRIBER_ID,
//     subscriberUrl: process.env.ONDC_SUBSCRIBER_URL,
//     signingPrivateKey: process.env.ONDC_SIGNING_PRIVATE_KEY,
//     encryptionPublicKey: process.env.ONDC_ENCRYPTION_PUBLIC_KEY,
//     uniqueKey: process.env.ONDC_UNIQUE_KEY
//   }
// };

// module.exports = config;