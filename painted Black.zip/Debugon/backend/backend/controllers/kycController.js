const Seller = require("../models/Seller.js");

// Register seller
const registerSeller = async (req, res) => {
    try {
        const { name, email,  gstNumber,panNumber,businessAddress } = req.body;

        if (!name || !email || !gstNumber || !panNumber || !businessAddress) {
            return res.status(400).json({ message: "All fields are required." });
        }

        const seller = new Seller({
            name,
            email,
            gstNumber,
            panNumber,
            businessAddress,
        });

        await seller.save();
        console.log(seller)
        res.status(201).json({ message: "Seller registered successfully", seller });
    } catch (error) {
        console.error("Error registering seller:", error.message);
        if (error.code === 11000) {
            // Handle duplicate email error
            return res.status(400).json({ message: "Email already exists." });
        }
        res.status(500).json({ message: "Internal Server Error" });
    }

};

// Validate seller details
const validateSeller = async (req, res) => {
    try {
        const { gstNumber, panNumber } = req.body;

        // Mock validation with external API calls
        const isGSTValid = gstNumber === "valid-gst"; // Replace with actual validation logic
        const isPANValid = panNumber === "valid-pan"; // Replace with actual validation logic

        if (isGSTValid && isPANValid) {
            const seller = await Seller.findOneAndUpdate(
                { gstNumber, panNumber },
                { isVerified: true },
                { new: true }
            );

            if (seller) {
                return res.status(200).json({ message: "Validation successful", seller });
            }
        }
        console.log(seller)

        res.status(400).json({ message: "Validation failed" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

module.exports = { registerSeller, validateSeller };