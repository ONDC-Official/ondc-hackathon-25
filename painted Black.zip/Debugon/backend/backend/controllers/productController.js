const Product = require("../models/Product");
const csv = require("csv-parser");
const fs = require("fs");

exports.addProduct = async (req, res) => {
    try {
        const product = new Product(req.body);
        await product.save();
        res.status(201).json(product);
    } catch (error) {
        res.status(500).json({ message: "Failed to add product", error });
    }
};

exports.bulkUpload = async (req, res) => {
    try {
        // Check if the file exists in the request
        if (!req.file) {
            return res.status(400).json({ message: "No file uploaded" });
        }

        const filePath = req.file.path; // Assuming middleware handles file upload
        const products = [];

        // Read the CSV file and push each row to the products array
        fs.createReadStream(filePath)
            .pipe(csv()) // Assuming you are using csv-parser
            .on("data", (row) => {
                // Optional: Add data validation here before pushing to the array
                if (row.name && row.price && row.stock) {
                    products.push(row);
                }
            })
            .on("end", async () => {
                try {
                    // Insert all products into the database
                    await Product.insertMany(products);

                    // Send a success response
                    res.status(200).json({ message: "Products uploaded successfully" });
                } catch (err) {
                    // Handle database insertion errors
                    res.status(500).json({ message: "Error inserting products", error: err });
                }
            })
            .on("error", (err) => {
                // Handle file read errors
                res.status(500).json({ message: "Error reading file", error: err });
            });

    } catch (error) {
        // Catch unexpected errors
        res.status(500).json({ message: "Bulk upload failed", error: error.message });
    }
};

exports.getProducts = async (req, res) => {
    try {
       
        const products = await Product.find({});
        console.log(products);
        res.status(200).json(products);
    } catch (error) {
        res.status(500).json({ message: "Failed to fetch products", error });
    }
};
