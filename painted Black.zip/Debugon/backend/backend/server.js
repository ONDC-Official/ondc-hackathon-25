const express = require("express");
const path= require("path");
const dotenv = require("dotenv");
const connectDB = require("./config/db.js");
const kycRoutes = require("./routes/kycRoutes.js");
const cors = require("cors");
const productRoutes = require("./routes/productRoutes.js")
const userRoutes = require("./routes/users")
const auth = require("./routes/auth")


dotenv.config();
connectDB();

const app = express();

app.use(cors());  // Allow all origins or customize as needed
app.use(express.json());

app.use("/api/kyc", kycRoutes);
app.use("/api/products", productRoutes);
app.use('/api/users', userRoutes);
app.use('/api/auth', auth);


const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});