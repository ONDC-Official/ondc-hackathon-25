const express = require('express');
const mongoose = require('mongoose');
const User = require("../models/user");
const Product= require("../models/Product")
const router = express.Router();

// // Middleware to validate userId
const validateUserId = (req, res, next) => {
    const { userId } = req.params;
  
    // Check if the userId is a valid MongoDB ObjectId
    if (!mongoose.isValidObjectId(userId)) {
        return res.status(400).json({ error: 'Invalid userId format' });
    }
  
    next(); // Proceed to the next middleware or route handler
};

// GET user by ID
router.get('/', async (req, res) => {
    try {
  
        const user = await User.find({});
  
        if (!user) {
            console.error("User not found");
            return res.status(404).json({ error: 'User not found.' });
        }
  
        console.log("User found:", user); // Log the found user
        res.json(user); // Return the found user
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Add EcoPoints
router.post('/addEcoPoints', async (req, res) => {
    const { userId, points } = req.body;
    try {
        // Check if userId is valid ObjectId
        // if (!mongoose.Types.ObjectId.isValid(userId)) {
        //     return res.status(400).json({ error: 'Invalid userId format' });
        // }

        const user = await User.findById(userId);  // Find the user by userId
        if (!user) {
            return res.status(404).json({ error: 'User not found.' });
        }

        user.ecoPoints += points;  // Add the points to the user's EcoPoints
        await user.save();  // Save updated user to the database
        res.status(200).json({ message: 'EcoPoints added successfully.' });
    } catch (err) {
        console.error("Error occurred:", err);
        res.status(500).json({ error: err.message });
    }
});

// Create a new user
router.post('/user', async (req, res) => {
    try {
        const { name, email } = req.body;
        if (!name || !email) {
            return res.status(400).json({ error: 'Name and email are required' });
        }

        const user = new User({ name, email });
        await user.save();
        console.log(user)
        res.status(201).json(user);
    } catch (err) {
        console.error('Error creating user:', err);

        // Handle duplicate email error (MongoDB specific error code)
        if (err.code === 11000) {
            return res.status(400).json({ error: 'Email already exists' });
        }

        res.status(500).json({ error: err.message });
    }

});


// Update user details
router.put('/:userId', validateUserId, async (req, res) => {
    const { name, email, ecoPoints } = req.body;
    try {
        const user = await User.findById(req.params.userId);  // Find user by userId
        if (!user) {
            return res.status(404).json({ error: 'User not found.' });
        }

        user.name = name;  // Update user properties
        user.email = email;
        user.ecoPoints = ecoPoints;

        await user.save();  // Save the updated user data
        res.status(200).json(user);  // Return the updated user
    } catch (err) {
        console.error("Error occurred:", err);
        res.status(500).json({ error: err.message });
    }
});

// GET current user (requires authentication middleware)
router.get('/current', async (req, res) => {
    try {
        const userId = req.user.id; // Assuming you have user authentication middleware that sets `req.user`
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.status(200).json(user);
    } catch (err) {
        console.error('Error fetching user:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});
  
module.exports = router;
