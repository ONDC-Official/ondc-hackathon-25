const express = require("express");
const multer = require('multer');
const upload = multer({ dest: 'uploads/' }); // Set destination folder
const { addProduct, bulkUpload, getProducts } = require("../controllers/productController");
const router = express.Router();

router.post("/add", addProduct);

router.post('/bulk-upload', upload.single('file'), bulkUpload);

router.get("/getproducts", getProducts);

module.exports = router;
