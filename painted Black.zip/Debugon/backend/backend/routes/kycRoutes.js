const express = require("express");
const path= require("path");

const { registerSeller, validateSeller } = require("../controllers/kycController.js");
const router = express.Router();

router.post("/register", registerSeller);
router.post("/validate", validateSeller);

module.exports = router;