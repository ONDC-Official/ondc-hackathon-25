const mongoose = require("mongoose");

const connectDB = async () => {
    try {
        const dbURI = "mongodb://127.0.0.1:27017/sellerKYC"; // Ensure the database name is correct
        await mongoose.connect(dbURI); // No options needed for modern versions
        console.log(`MongoDB Connected: ${dbURI}`);
    } catch (error) {
        console.error(`Error connecting to MongoDB: ${error.message}`);
        process.exit(1); // Exit the process with failure
    }
};

module.exports = connectDB;
