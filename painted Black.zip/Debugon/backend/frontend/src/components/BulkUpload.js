import React, { useState } from "react";
import { bulkUpload } from "../services/api";

const BulkUpload = () => {
    const [file, setFile] = useState(null);

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!file) {
            alert("Please select a file.");
            return;
        }

        const formData = new FormData();
        formData.append("file", file);

        try {
            await bulkUpload(formData);
            alert("Bulk upload successful!");
        } catch (error) {
            console.error("Error in bulk upload:", error);
        }
    };

    return (
        <div>
            <h2>Bulk Upload</h2>
            <form onSubmit={handleSubmit}>
                <input type="file" onChange={handleFileChange} required />
                <button type="submit">Upload</button>
            </form>
        </div>
    );
};

export default BulkUpload;
