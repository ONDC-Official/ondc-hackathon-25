import React, { useState } from "react";
import axios from "axios";
import '../App.css';

const KYCForm = () => {
    // State for form data
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        gstNumber: "",
        panNumber: "",
        businessAddress: "",
    });

    // Handle form field changes
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/api/kyc/register", formData);
            alert(response.data.message);
        } catch (error) {
            // Improved error handling
            if (error.response) {
                // Request was made and server responded with a status code
                // outside of the range of 2xx
                alert(`Error: ${error.response?.data?.message || "Something went wrong"}`);
            } else if (error.request) {
                // Request was made but no response was received
                alert("No response received from server.");
            } else {
                // Something happened in setting up the request that triggered an error
                alert(`Error in request: ${error.message}`);
            }
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                name="name"
                placeholder="Name"
                value={formData.name}
                onChange={handleChange}
            />
            <input
                type="email"
                name="email"
                placeholder="Email"
                value={formData.email}
                onChange={handleChange}
            />
            <input
                type="text"
                name="gstNumber"
                placeholder="GST Number"
                value={formData.gstNumber}
                onChange={handleChange}
            />
            <input
                type="text"
                name="panNumber"
                placeholder="PAN Number"
                value={formData.panNumber}
                onChange={handleChange}
            />
            <textarea
                name="businessAddress"
                placeholder="Business Address"
                value={formData.businessAddress}
                onChange={handleChange}
            ></textarea>
            <button type="submit">Register</button>
        </form>
    );
};

export default KYCForm;
