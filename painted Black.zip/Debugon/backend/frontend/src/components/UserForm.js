import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';  // Import useNavigate

const UserForm = () => {
  const [isRegister, setIsRegister] = useState(true); // Toggle between login and register
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [ecoPoints, setEcoPoints] = useState(0);
  const [userDetails, setUserDetails] = useState(null); // Store logged-in user details
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');

    try {
      if (isRegister) {
        // Registration logic
        const res = await axios.post('http://localhost:5000/api/auth/register', { name, email, password });
        setMessage(res.data.message);
      } else {
        // Login logic
        const res = await axios.post('http://localhost:5000/api/auth/login', { email, password });
        const { token, user } = res.data;

        // Store token in localStorage
        localStorage.setItem('authToken', token);

        // Update user details
        setEcoPoints(user.ecoPoints);
        setUserDetails(user);

        setMessage('Login successful!');

        // Redirect to Dashboard after successful login
        navigate('/KYCForm');
      }

      // Clear form fields
      setName('');
      setEmail('');
      setPassword('');
    } catch (err) {
      // Handle backend errors
      if (err.response?.data?.errors) {
        const validationErrors = err.response.data.errors.map((error) => error.msg).join(', ');
        setError(validationErrors);
      } else if (err.response?.data?.error) {
        // Handle login error specifically
        if (err.response.data.error === 'Invalid credentials' || err.response.data.error === 'User not found') {
          setError('User email or password is wrong. Please try again.');
        } else {
          setError(err.response?.data?.error || 'Something went wrong. Please try again.');
        }
      } else {
        setError('Something went wrong. Please try again.');
      }

      console.error('Error details:', err); // Log error for debugging
    }
  };

  return (
    <div className="form-container">
      <h2>{isRegister ? 'Register' : 'Login'}</h2>

      {error && <p style={{ color: 'red' }}>{error}</p>}
      {message && <p style={{ color: 'green' }}>{message}</p>}

      {!userDetails ? (
        <form onSubmit={handleSubmit}>
          {isRegister && (
            <div>
              <label>Name:</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required={isRegister}
                placeholder="Enter your name"
              />
            </div>
          )}
          <div>
            <label>Email:</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="Enter your email"
            />
          </div>
          <div>
            <label>Password:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Enter your password"
            />
          </div>
          <button type="submit">{isRegister ? 'Register' : 'Login'}</button>
        </form>
      ) : (
        <div className="user-details">
          <h3>Logged-in User Details</h3>
          <p><strong>ID:</strong> {userDetails.id}</p>
          <p><strong>Name:</strong> {userDetails.name}</p>
          <p><strong>Email:</strong> {userDetails.email}</p>
          <p><strong>EcoPoints:</strong> {ecoPoints}</p>
        </div>
      )}

      <button
        className="toggle-button"
        onClick={() => {
          setIsRegister(!isRegister);
          setError('');
          setMessage('');
          setName('');
          setEmail('');
          setPassword('');
        }}
      >
        {isRegister ? 'Already have an account? Login' : "Don't have an account? Register"}
      </button>
    </div>
  );
};

export default UserForm;
