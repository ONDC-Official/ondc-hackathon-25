import React, { useEffect, useState } from "react";
import { fetchProducts } from "../services/api"; // Import from the updated API file
import "./product.css"
function ProductList() {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const loadProducts = async () => {
            try {
                const data = await fetchProducts(); // Use the refactored function
                setProducts(data);
            } catch (err) {
                console.error("Error loading products:", err);
                setError("Failed to fetch products. Please try again.");
            } finally {
                setLoading(false);
            }
        };

        loadProducts();
    }, []);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div>
            <h2>Product List</h2>
            <ul>
                {products.length > 0 ? (
                    products.map((product) => (
                        <li key={product._id}>
                            <h3>{product.name}</h3>
                            <p>{product.description}</p>
                            <p>Price: ${product.price}</p>
                        </li>
                    ))
                ) : (
                    <p>No products available.</p>
                )}
            </ul>
        </div>
    );
}

export default ProductList;
