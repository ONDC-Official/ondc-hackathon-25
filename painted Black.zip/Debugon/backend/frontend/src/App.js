import React from "react";
import { BrowserRouter as Router, Routes, Route, NavLink } from "react-router-dom";
import KYCForm from "./components/KYCForm";
import AddProduct from "./components/AddProduct";
import BulkUpload from "./components/BulkUpload";
import ProductList from "./components/ProductList";
import Home from "./home/homepage";
import "./App.css"; // Assuming your CSS file is here
import GetStarted from "./home/getStarted";
import Learn from "./home/learn"
import UserForm from "./components/UserForm";

function App() {
  return (
    <Router>
      <div className="app-container">
        {/* Navigation Bar */}
        <header className="header">
          <div className="logo">Virtual Market</div>
          <nav className="navigation">
            <ul>
              <li><NavLink to="/" activeClassName="active">Home</NavLink></li>
              <li><NavLink to="/KYCForm" activeClassName="active">KYC Registration</NavLink></li>
              <li><NavLink to="/add-product" activeClassName="active">Add Product</NavLink></li>
              <li><NavLink to="/bulk-upload" activeClassName="active">Bulk Upload</NavLink></li>
              <li><NavLink to="/getproducts" activeClassName="active">Product List</NavLink></li>
              <li><a href="#contact">Contact</a></li>
              <li><a href="/form" className="btn-primary">Sign Up</a></li>
              <li><a href="/form" className="btn-primary">Sign In</a></li>
            </ul>
          </nav>
        </header>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/KYCForm" element={<KYCForm />} />
          <Route path="/add-product" element={<AddProduct />} />
          <Route path="/bulk-upload" element={<BulkUpload />} />
          <Route path="/getproducts" element={<ProductList />} />
          <Route path="/getStarted" element={<GetStarted />} />
          <Route path="/learn" element={<Learn />} />
          <Route path="/form" element={<UserForm />} />
        </Routes>

        {/* Footer */}
        <footer className="footer">
          <p>&copy; {new Date().getFullYear()} Virtual Market. All Rights Reserved.</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;
