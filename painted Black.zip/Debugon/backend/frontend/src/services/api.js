import axios from "axios";

// Set up the base API instance
const API = axios.create({ baseURL: "http://localhost:5000/api" });

// Fetch all products
export const fetchProducts = async () => {
    try {
        const response = await API.get("/products/getproducts"); // Adjust the endpoint based on your backend
        return response.data; // Return the data directly
    } catch (error) {
        console.error("Error fetching products:", error);
        throw error; // Throw the error to be handled by the calling code
    }
};

// Add a single product
export const addProduct = async (product) => {
    try {
        const response = await API.post("/products/add", product); // Adjust endpoint if necessary
        return response.data;
    } catch (error) {
        console.error("Error adding product:", error);
        throw error;
    }
};

// Bulk upload products
export const bulkUpload = async (formData) => {
    try {
        const response = await API.post("/products/bulk-upload", formData, {
            headers: {
                "Content-Type": "multipart/form-data", // Necessary for file uploads
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error during bulk upload:", error);
        throw error;
    }
};
