import React from 'react';
import './home.css';

const App = () => {
  return (
    <div className="app-container">
    

      {/* Hero Section */}
      <section className="hero">
        <h1>Transforming Local Markets into Digital Hubs</h1>
        <p>Your one-stop solution for virtualizing local markets and empowering sellers.</p>
        <div className="cta-buttons">
          <a href="getStarted" className="btn-primary">Get Started</a>
          <a href="learn" className="btn-secondary">Learn More</a>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="features">
        <h2>Key Features</h2>
        <div className="feature-list">
          <div className="feature-item">
            <h3>Limitless Inventory</h3>
            <p>Extensive inventory support for both physical and virtual stores.</p>
          </div>
          <div className="feature-item">
            <h3>Order Aggregation</h3>
            <p>Streamlined order fulfillment from local shops.</p>
          </div>
          <div className="feature-item">
            <h3>SaaS-Based POS System</h3>
            <p>Easy-to-use system for managing transactions and inventory.</p>
          </div>
          <div className="feature-item">
            <h3>Advanced Technology</h3>
            <p>Empowering sellers with self-service tools and shared resources.</p>
          </div>
          <div className="feature-item">
            <h3>Comprehensive Analytics</h3>
            <p>Sales reports, performance metrics, and inventory insights.</p>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="about">
        <h2>About Us</h2>
        <p>
          Our mission is to modernize traditional markets by creating a comprehensive ecosystem that supports sellers and enhances customer experiences. With technology-driven solutions, we aim to bring local markets to a global stage while preserving their unique charm.
        </p>
      </section>

      {/* Footer Section */}
      <footer className="footer">
        <div className="footer-content">
          <p>&copy; 2025 Virtual Market. All Rights Reserved.</p>
          <nav className="footer-navigation">
            <a href="#privacy">Privacy Policy</a>
            <a href="#terms">Terms of Service</a>
          </nav>
        </div>
      </footer>
    </div>
  );
};

export default App;
