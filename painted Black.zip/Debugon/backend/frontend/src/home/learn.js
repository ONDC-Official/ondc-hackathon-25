import React from 'react';
import './learn.css';

const Learn = () => {
  return (
    <div className="learn-container">
      <header className="learn-header">
        <h1>Welcome to the Virtual Market Learning Portal</h1>
        <p>Your guide to getting started and mastering the platform</p>
      </header>

      <section className="learn-section">
        <h2>Getting Started</h2>
        <p>
          To begin using our Virtual Market platform, sign up for an account, verify your identity through KYC, and set up your store. This will allow you to start managing your products and take full advantage of the platform's features.
        </p>
        <ul>
          <li>Sign up and create your account.</li>
          <li>Verify your identity through the KYC process.</li>
          <li>Complete your profile setup (GST, PAN, etc.).</li>
        </ul>
      </section>

      <section className="learn-section">
        <h2>Inventory Management</h2>
        <p>Learn how to manage your products effectively with our inventory management tools.</p>
        <ul>
          <li>Create your product catalog.</li>
          <li>Bulk upload your products for easy management.</li>
          <li>Manage inventory with real-time updates.</li>
          <li>Publish inventory on a time-based release schedule.</li>
        </ul>
      </section>

      <section className="learn-section">
        <h2>Store Management</h2>
        <p>Set up and manage multiple stores easily with the platform’s tools.</p>
        <ul>
          <li>Set up multiple stores for different product categories.</li>
          <li>Track orders and complaints efficiently.</li>
        </ul>
      </section>

      <section className="learn-section">
        <h2>Catalog Management</h2>
        <p>Organize and monitor your product catalog with ease.</p>
        <ul>
          <li>Organize your products into categories for easier browsing.</li>
          <li>Monitor the real-time progress of your catalog.</li>
        </ul>
      </section>

      <section className="learn-section">
        <h2>Sales and Reporting</h2>
        <p>Keep track of your sales and analyze your performance.</p>
        <ul>
          <li>Access detailed sales reports.</li>
          <li>Analyze inventory data and track performance metrics (top-selling, best-rated products, etc.).</li>
        </ul>
      </section>

      <section className="learn-section">
        <h2>Troubleshooting and Support</h2>
        <p>If you encounter any issues, we’re here to help.</p>
        <ul>
          <li>Check our FAQs for common solutions.</li>
          <li>Contact support through email or live chat for further assistance.</li>
        </ul>
      </section>
    </div>
  );
};

export default Learn;
