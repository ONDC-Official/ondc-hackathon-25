import React from 'react';
 import './get.css';

const GetStarted = () => {
  return (
    <div className="get-started-container">
      <h1>Welcome to Virtual Market</h1>
      <p>
        Ready to transform your local market into a digital hub? Follow the steps below to get started:
      </p>
      <ol>
        <li>Register your account and verify your identity through KYC.</li>
        <li>Add your products using our user-friendly interface.</li>
        <li>Leverage advanced analytics to optimize your business operations.</li>
      </ol>
      <a href="/KYCForm" className="btn-primary">Start Now</a>
    </div>
  );
};

export default GetStarted;
