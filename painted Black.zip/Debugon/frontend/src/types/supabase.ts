export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      stores: {
        Row: {
          id: string
          name: string
          description: string | null
          location: string | null
          cover_image_url: string | null
          profile_image_url: string | null
          owner_id: string
          rating: number
          reviews_count: number
          followers_count: number
          products_count: number
          featured: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          location?: string | null
          cover_image_url?: string | null
          profile_image_url?: string | null
          owner_id: string
          rating?: number
          reviews_count?: number
          followers_count?: number
          products_count?: number
          featured?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          location?: string | null
          cover_image_url?: string | null
          profile_image_url?: string | null
          owner_id?: string
          rating?: number
          reviews_count?: number
          followers_count?: number
          products_count?: number
          featured?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      store_categories: {
        Row: {
          id: string
          store_id: string
          category: string
          created_at: string
        }
        Insert: {
          id?: string
          store_id: string
          category: string
          created_at?: string
        }
        Update: {
          id?: string
          store_id?: string
          category?: string
          created_at?: string
        }
      }
      products: {
        Row: {
          id: string
          store_id: string
          name: string
          description: string | null
          price: number
          stock: number
          image_url: string | null
          category: string | null
          rating: number
          reviews_count: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          store_id: string
          name: string
          description?: string | null
          price: number
          stock?: number
          image_url?: string | null
          category?: string | null
          rating?: number
          reviews_count?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          store_id?: string
          name?: string
          description?: string | null
          price?: number
          stock?: number
          image_url?: string | null
          category?: string | null
          rating?: number
          reviews_count?: number
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}