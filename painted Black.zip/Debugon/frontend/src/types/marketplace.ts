export interface Store {
  id: string;
  name: string;
  description: string;
  image: string;
  coverImage: string;
  owner: {
    name: string;
    image: string;
  };
  rating: number;
  reviews: number;
  location: string;
  followers: number;
  productsCount: number;
  featured: boolean;
  categories: string[];
  products: Product[];
}

export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  stock: number;
}