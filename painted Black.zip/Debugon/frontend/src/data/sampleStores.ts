import { Store } from '../types/marketplace';

export const sampleStores: Store[] = [
  {
    id: '1',
    name: 'Mountain Crafts Co.',
    description: 'Handcrafted items from the heart of the mountains. We specialize in unique ceramic pieces and home decor that bring the beauty of nature into your space.',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
    coverImage: 'https://images.unsplash.com/photo-1449247709967-d4461a6a6103?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
    owner: {
      name: 'Sarah Johnson',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80'
    },
    rating: 4.9,
    reviews: 328,
    location: 'Colorado, USA',
    followers: 1200,
    productsCount: 45,
    featured: true,
    categories: ['Ceramics', 'Home Decor'],
    products: [
      {
        id: '1',
        name: 'Mountain Vista Ceramic Vase',
        price: 89.99,
        description: 'Hand-thrown ceramic vase with mountain landscape design',
        image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        category: 'Ceramics',
        rating: 4.8,
        reviews: 45,
        stock: 8
      },
      {
        id: '2',
        name: 'Rustic Coffee Pour-Over Set',
        price: 129.99,
        description: 'Handcrafted ceramic coffee pour-over set with wooden stand',
        image: 'https://images.unsplash.com/photo-1572785031839-8d006462dcd8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        category: 'Ceramics',
        rating: 4.9,
        reviews: 32,
        stock: 5
      }
    ]
  },
  {
    id: '2',
    name: 'Artisan Jewelry Studio',
    description: 'Unique handcrafted jewelry pieces that combine traditional techniques with modern design. Each piece is carefully created to tell its own story.',
    image: 'https://images.unsplash.com/photo-1617038220319-276d3cfab638?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
    coverImage: 'https://images.unsplash.com/photo-1531995811006-35cb42e1a022?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
    owner: {
      name: 'Emily Chen',
      image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80'
    },
    rating: 4.8,
    reviews: 256,
    location: 'New York, USA',
    followers: 890,
    productsCount: 78,
    featured: true,
    categories: ['Jewelry', 'Accessories'],
    products: [
      {
        id: '1',
        name: 'Silver Mountain Pendant',
        price: 149.99,
        description: 'Hand-forged silver pendant with mountain range design',
        image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        category: 'Jewelry',
        rating: 4.9,
        reviews: 28,
        stock: 12
      },
      {
        id: '2',
        name: 'Moonstone Ring Set',
        price: 199.99,
        description: 'Set of three stackable rings with moonstone accents',
        image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        category: 'Jewelry',
        rating: 4.7,
        reviews: 34,
        stock: 6
      }
    ]
  },
  {
    id: '3',
    name: 'Nordic Textile Works',
    description: 'Contemporary textiles inspired by Scandinavian design. We create beautiful, functional pieces for your home using sustainable materials.',
    image: 'https://images.unsplash.com/photo-1528458909336-e7a0adfed0a5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
    coverImage: 'https://images.unsplash.com/photo-1544365558-35aa4afcf11f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
    owner: {
      name: 'Lisa Anderson',
      image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80'
    },
    rating: 4.7,
    reviews: 189,
    location: 'Stockholm, Sweden',
    followers: 670,
    productsCount: 34,
    featured: false,
    categories: ['Textiles', 'Home Decor'],
    products: [
      {
        id: '1',
        name: 'Wool Wall Hanging',
        price: 299.99,
        description: 'Large-scale wool wall hanging with geometric patterns',
        image: 'https://images.unsplash.com/photo-1615529182904-14819c35db37?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        category: 'Textiles',
        rating: 4.8,
        reviews: 23,
        stock: 4
      },
      {
        id: '2',
        name: 'Linen Throw Pillows Set',
        price: 159.99,
        description: 'Set of three hand-printed linen throw pillows',
        image: 'https://images.unsplash.com/photo-1584100936595-c0654b55a2e6?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        category: 'Textiles',
        rating: 4.6,
        reviews: 18,
        stock: 9
      }
    ]
  }
];