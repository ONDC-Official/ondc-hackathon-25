import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Header from './components/shared/Header';
import LoginForm from './components/auth/LoginForm';
import SignUpForm from './components/auth/SignUpForm';
import ForgotPassword from './components/auth/ForgotPassword';
import Home from './pages/Home';
import AboutUs from './pages/AboutUs';
import ContactUs from './pages/ContactUs';
import FAQ from './pages/FAQ';
import TermsAndConditions from './pages/TermsAndConditions';
import PrivacyPolicy from './pages/PrivacyPolicy';
import BrowseMarket from './components/marketplace/BrowseMarket';
import MarketplaceDashboard from './components/marketplace/MarketplaceDashboard';
import Cart from './components/marketplace/Cart';
import Notifications from './components/dashboard/Notifications';
import SellerDashboard from './components/dashboard/SellerDashboard';
import UserProfile from './components/auth/UserProfile';
import BecomeSeller from './pages/BecomeSeller';
import Chatbot from './components/chat/Chatbot';
import KYCRegistration from './components/seller/KYCRegistration';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Header />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<LoginForm />} />
              <Route path="/signup" element={<SignUpForm />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/about" element={<AboutUs />} />
              <Route path="/contact" element={<ContactUs />} />
              <Route path="/faq" element={<FAQ />} />
              <Route path="/terms" element={<TermsAndConditions />} />
              <Route path="/privacy" element={<PrivacyPolicy />} />
              <Route path="/browse" element={<BrowseMarket />} />
              <Route path="/marketplace" element={<MarketplaceDashboard />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/dashboard" element={<SellerDashboard />} />
              <Route path="/profile" element={<UserProfile />} />
              <Route path="/become-seller" element={<BecomeSeller />} />
              <Route path="/kyc" element={<KYCRegistration />} />
            </Routes>
          </main>
          <Chatbot />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;