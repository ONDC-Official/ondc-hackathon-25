import React from 'react';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-extrabold text-gray-900 mb-8">
          Privacy Policy
        </h2>
        <div className="prose prose-indigo max-w-none">
          <h3>1. Information We Collect</h3>
          <p>
            We collect information that you provide directly to us, including but not limited to
            your name, email address, and other contact information.
          </p>
          
          <h3>2. How We Use Your Information</h3>
          <p>
            We use the information we collect to provide, maintain, and improve our services,
            to process your transactions, and to communicate with you.
          </p>
        </div>
      </div>
    </div>
  );
}