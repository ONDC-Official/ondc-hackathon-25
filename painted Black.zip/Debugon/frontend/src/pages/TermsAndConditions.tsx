import React from 'react';

export default function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-extrabold text-gray-900 mb-8">
          Terms and Conditions
        </h2>
        <div className="prose prose-indigo max-w-none">
          <h3>1. Acceptance of Terms</h3>
          <p>
            By accessing and using this marketplace, you accept and agree to be bound by the terms
            and provision of this agreement.
          </p>
          
          <h3>2. User Account</h3>
          <p>
            You must create an account and provide accurate information to use our services.
            You are responsible for maintaining the confidentiality of your account.
          </p>
        </div>
      </div>
    </div>
  );
}