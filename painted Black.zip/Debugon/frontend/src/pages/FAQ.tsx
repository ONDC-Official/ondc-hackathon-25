import React from 'react';

export default function FAQ() {
  const faqs = [
    {
      question: "How do I become a seller?",
      answer: "To become a seller, you need to create an account and complete our KYC process. Once approved, you can start listing your products."
    },
    {
      question: "What payment methods are accepted?",
      answer: "We accept major credit cards, debit cards, and various digital payment methods."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-extrabold text-gray-900 text-center mb-8">
          Frequently Asked Questions
        </h2>
        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white shadow rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">{faq.question}</h3>
              <p className="text-gray-500">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}