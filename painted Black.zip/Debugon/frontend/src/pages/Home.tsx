import React from 'react';
import HeroSection from '../components/home/HeroSection';
import FeaturedProducts from '../components/home/FeaturedProducts';
import CategoryShowcase from '../components/home/CategoryShowcase';
import ImpactSection from '../components/home/ImpactSection';
import HowItWorks from '../components/home/HowItWorks';
import SellerSuccess from '../components/home/SellerSuccess';
import TrustSection from '../components/home/TrustSection';
import TestimonialsSection from '../components/home/TestimonialsSection';
import NewsletterSection from '../components/home/NewsletterSection';

export default function Home() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <FeaturedProducts />
      <CategoryShowcase />
      <ImpactSection />
      <HowItWorks />
      <SellerSuccess />
      <TrustSection />
      <TestimonialsSection />
      <NewsletterSection />
    </div>
  );
}