import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import { Wallet } from 'lucide-react';

export default function WalletConnect() {
  const [account, setAccount] = useState<string | null>(null);
  const [balance, setBalance] = useState<string>('0');
  const [error, setError] = useState<string | null>(null);

  const connectWallet = async () => {
    try {
      setError(null);
      if (window.ethereum) {
        const accounts = await window.ethereum.request({
          method: 'eth_requestAccounts'
        });
        const provider = new ethers.BrowserProvider(window.ethereum);
        const balance = await provider.getBalance(accounts[0]);
        setAccount(accounts[0]);
        setBalance(ethers.formatEther(balance));
      } else {
        setError('Please install MetaMask to connect your wallet');
      }
    } catch (error: any) {
      // Handle user rejection gracefully
      if (error?.code === 4001) {
        setError('Connection request was cancelled');
      } else {
        setError('Failed to connect wallet. Please try again.');
        console.error('Wallet connection error:', error);
      }
    }
  };

  // Listen for account changes
  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts: string[]) => {
        if (accounts.length === 0) {
          setAccount(null);
          setBalance('0');
        } else {
          setAccount(accounts[0]);
          const provider = new ethers.BrowserProvider(window.ethereum);
          provider.getBalance(accounts[0]).then((balance) => {
            setBalance(ethers.formatEther(balance));
          });
        }
      });
    }

    return () => {
      if (window.ethereum) {
        window.ethereum.removeListener('accountsChanged', () => {});
      }
    };
  }, []);

  return (
    <div className="flex items-center gap-4">
      {account ? (
        <div className="flex items-center gap-2 bg-emerald-50 px-4 py-2 rounded-lg">
          <Wallet className="h-5 w-5 text-emerald-600" />
          <span className="text-sm text-emerald-600">
            {account.slice(0, 6)}...{account.slice(-4)} ({parseFloat(balance).toFixed(4)} ETH)
          </span>
        </div>
      ) : (
        <div className="relative">
          <button
            onClick={connectWallet}
            className="flex items-center gap-2 bg-gradient-to-r from-teal-500 to-emerald-500 text-white px-4 py-2 rounded-lg hover:from-teal-600 hover:to-emerald-600 transition-all"
          >
            <Wallet className="h-5 w-5" />
            Connect Wallet
          </button>
          {error && (
            <div className="absolute top-full mt-2 left-0 right-0 bg-red-50 text-red-600 text-sm p-2 rounded-md">
              {error}
            </div>
          )}
        </div>
      )}
    </div>
  );
}