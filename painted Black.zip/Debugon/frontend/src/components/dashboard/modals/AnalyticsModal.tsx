import React from 'react';
import { X } from 'lucide-react';

interface AnalyticsModalProps {
  onClose: () => void;
}

export default function AnalyticsModal({ onClose }: AnalyticsModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-4xl w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold">Analytics Dashboard</h3>
          <button onClick={onClose}>
            <X className="h-6 w-6" />
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 p-6 rounded-lg">
            <h4 className="text-lg font-semibold mb-4">Sales Overview</h4>
            <div className="h-64 bg-white rounded-lg p-4">
              <div className="flex items-center justify-center h-full text-gray-500">
                Sales Chart Coming Soon
              </div>
            </div>
          </div>
          <div className="bg-gray-50 p-6 rounded-lg">
            <h4 className="text-lg font-semibold mb-4">Customer Demographics</h4>
            <div className="h-64 bg-white rounded-lg p-4">
              <div className="flex items-center justify-center h-full text-gray-500">
                Demographics Chart Coming Soon
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}