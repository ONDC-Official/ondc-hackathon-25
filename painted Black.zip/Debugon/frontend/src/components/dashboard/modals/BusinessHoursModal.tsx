import React, { useState } from 'react';
import { X } from 'lucide-react';

interface BusinessHours {
  [key: string]: {
    open: string;
    close: string;
    closed: boolean;
  };
}

interface BusinessHoursModalProps {
  onClose: () => void;
  onSave: (hours: BusinessHours) => void;
}

export default function BusinessHoursModal({ onClose, onSave }: BusinessHoursModalProps) {
  const [hours, setHours] = useState<BusinessHours>({
    monday: { open: '09:00', close: '17:00', closed: false },
    tuesday: { open: '09:00', close: '17:00', closed: false },
    wednesday: { open: '09:00', close: '17:00', closed: false },
    thursday: { open: '09:00', close: '17:00', closed: false },
    friday: { open: '09:00', close: '17:00', closed: false },
    saturday: { open: '10:00', close: '15:00', closed: false },
    sunday: { open: '10:00', close: '15:00', closed: true }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(hours);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-2xl w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold">Update Business Hours</h3>
          <button onClick={onClose}>
            <X className="h-6 w-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          {Object.entries(hours).map(([day, time]) => (
            <div key={day} className="flex items-center gap-4">
              <span className="w-28 font-medium capitalize">{day}</span>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={!time.closed}
                  onChange={(e) => setHours({
                    ...hours,
                    [day]: { ...time, closed: !e.target.checked }
                  })}
                  className="mr-2"
                />
                Open
              </label>
              {!time.closed && (
                <>
                  <input
                    type="time"
                    value={time.open}
                    onChange={(e) => setHours({
                      ...hours,
                      [day]: { ...time, open: e.target.value }
                    })}
                    className="rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                  />
                  <span>to</span>
                  <input
                    type="time"
                    value={time.close}
                    onChange={(e) => setHours({
                      ...hours,
                      [day]: { ...time, close: e.target.value }
                    })}
                    className="rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                  />
                </>
              )}
            </div>
          ))}
          <div className="flex justify-end gap-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 rounded-md"
            >
              Save Hours
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}