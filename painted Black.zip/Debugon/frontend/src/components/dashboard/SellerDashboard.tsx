import React, { useState } from 'react';
import { 
  BarChart, 
  Package, 
  ShoppingBag, 
  Settings, 
  Store as StoreIcon,
  DollarSign
} from 'lucide-react';
import Overview from './Overview';
import ProductsTab from './ProductsTab';
import OrdersTab from './OrdersTab';
import SettingsTab from './SettingsTab';
import StoreManagement from './StoreManagement';
import CreateStore from './CreateStore';
import ProductFormModal from './modals/ProductFormModal';
import BusinessHoursModal from './modals/BusinessHoursModal';
import AnalyticsModal from './modals/AnalyticsModal';
import { Store } from '../../types/marketplace';
import InventoryManagement from '../seller/InventoryManagement';
import PaymentReports from '../seller/PaymentReports';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  category: string;
  images: string[];
}

export default function SellerDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showUpdateHours, setShowUpdateHours] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [store, setStore] = useState<Store | null>(null);

  const handleAddProduct = (product: Omit<Product, 'id'>) => {
    const newProduct = {
      ...product,
      id: Date.now().toString()
    };
    setProducts([...products, newProduct]);
    setShowAddProduct(false);
  };

  const handleEditProduct = (product: Product) => {
    setProducts(products.map(p => p.id === product.id ? product : p));
    setEditingProduct(null);
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts(products.filter(p => p.id !== productId));
  };

  const handleStoreCreated = (newStore: Store) => {
    setStore(newStore);
    setActiveTab('store');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Seller Dashboard</h1>
          <p className="text-gray-600">Manage your store, products, and orders</p>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8 border-b border-gray-200">
          <nav className="flex space-x-8">
            {[
              { id: 'overview', name: 'Overview', icon: <BarChart className="h-5 w-5" /> },
              { id: 'store', name: 'Store', icon: <StoreIcon className="h-5 w-5" /> },
              { id: 'products', name: 'Products', icon: <Package className="h-5 w-5" /> },
              { id: 'orders', name: 'Orders', icon: <ShoppingBag className="h-5 w-5" /> },
              { id: 'inventory', name: 'Inventory', icon: <Package className="h-5 w-5" /> },
              { id: 'payments', name: 'Payments', icon: <DollarSign className="h-5 w-5" /> },
              { id: 'settings', name: 'Settings', icon: <Settings className="h-5 w-5" /> }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-4 py-2 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-teal-500 text-teal-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.icon}
                <span className="ml-2">{tab.name}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Content Sections */}
        {activeTab === 'overview' && (
          <Overview
            onShowAddProduct={() => setShowAddProduct(true)}
            onShowUpdateHours={() => setShowUpdateHours(true)}
            onShowAnalytics={() => setShowAnalytics(true)}
            onTabChange={setActiveTab}
          />
        )}

        {activeTab === 'store' && (
          store ? (
            <StoreManagement store={store} onStoreUpdate={setStore} />
          ) : (
            <CreateStore onStoreCreated={handleStoreCreated} />
          )
        )}

        {activeTab === 'products' && (
          <ProductsTab
            products={products}
            onAddProduct={() => setShowAddProduct(true)}
            onEditProduct={(product) => {
              setEditingProduct(product);
              setShowAddProduct(true);
            }}
            onDeleteProduct={handleDeleteProduct}
          />
        )}

        {activeTab === 'orders' && <OrdersTab />}

        {activeTab === 'inventory' && <InventoryManagement />}

        {activeTab === 'payments' && <PaymentReports />}

        {activeTab === 'settings' && <SettingsTab />}

        {/* Modals */}
        {showAddProduct && (
          <ProductFormModal
            product={editingProduct}
            onClose={() => {
              setShowAddProduct(false);
              setEditingProduct(null);
            }}
            onSubmit={editingProduct ? handleEditProduct : handleAddProduct}
          />
        )}

        {showUpdateHours && (
          <BusinessHoursModal
            onClose={() => setShowUpdateHours(false)}
            onSave={(hours) => {
              console.log('Saving hours:', hours);
              setShowUpdateHours(false);
            }}
          />
        )}

        {showAnalytics && (
          <AnalyticsModal onClose={() => setShowAnalytics(false)} />
        )}
      </div>
    </div>
  );
}