import React from 'react';
import { Bell, Package, CreditCard, MessageSquare } from 'lucide-react';

export default function Notifications() {
  const notifications = [
    {
      id: 1,
      type: 'order',
      title: 'New Order Received',
      message: 'Order #1234 has been placed for Ceramic Coffee Set',
      time: '5 minutes ago',
      icon: <Package className="h-6 w-6 text-teal-500" />
    },
    {
      id: 2,
      type: 'payment',
      title: 'Payment Received',
      message: 'Payment of $129.99 has been processed for Order #1234',
      time: '1 hour ago',
      icon: <CreditCard className="h-6 w-6 text-green-500" />
    },
    {
      id: 3,
      type: 'message',
      title: 'New Message',
      message: 'Sarah has sent you a message about your product',
      time: '2 hours ago',
      icon: <MessageSquare className="h-6 w-6 text-blue-500" />
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Notifications</h1>
        <button className="text-teal-500 hover:text-teal-600">Mark all as read</button>
      </div>

      <div className="space-y-4">
        {notifications.map((notification) => (
          <div
            key={notification.id}
            className="bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                {notification.icon}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">{notification.title}</h3>
                <p className="text-gray-600">{notification.message}</p>
                <span className="text-sm text-gray-500">{notification.time}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}