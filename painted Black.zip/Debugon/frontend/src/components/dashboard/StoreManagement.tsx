import React, { useState } from 'react';
import { 
  Layout, 
  Palette, 
  Image as ImageIcon, 
  Edit, 
  Trash2, 
  Plus,
  Save,
  X
} from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  images: string[];
  category: string;
  stock: number;
}

export default function StoreManagement() {
  const [storeTheme, setStoreTheme] = useState('modern');
  const [storeBanner, setStoreBanner] = useState('https://images.unsplash.com/photo-1557821552-17105176677c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80');
  const [storeDescription, setStoreDescription] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);
  const [isCustomizing, setIsCustomizing] = useState(false);

  const themes = [
    { id: 'modern', name: 'Modern & Clean' },
    { id: 'vintage', name: 'Vintage Style' },
    { id: 'minimal', name: 'Minimalist' },
    { id: 'bold', name: 'Bold & Creative' }
  ];

  const handleSaveProduct = (product: Product) => {
    if (currentProduct) {
      setProducts(products.map(p => p.id === currentProduct.id ? product : p));
    } else {
      setProducts([...products, { ...product, id: Date.now().toString() }]);
    }
    setIsEditingProduct(false);
    setCurrentProduct(null);
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts(products.filter(p => p.id !== productId));
  };

  const ProductForm = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-2xl w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold">
            {currentProduct ? 'Edit Product' : 'Add New Product'}
          </h3>
          <button onClick={() => setIsEditingProduct(false)}>
            <X className="h-6 w-6" />
          </button>
        </div>
        <form className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">Product Name</label>
            <input
              type="text"
              defaultValue={currentProduct?.name}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Price</label>
              <input
                type="number"
                defaultValue={currentProduct?.price}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Stock</label>
              <input
                type="number"
                defaultValue={currentProduct?.stock}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Description</label>
            <textarea
              rows={3}
              defaultValue={currentProduct?.description}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Category</label>
            <select
              defaultValue={currentProduct?.category}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
            >
              <option>Jewelry</option>
              <option>Ceramics</option>
              <option>Textiles</option>
              <option>Woodwork</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Images</label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                <ImageIcon className="mx-auto h-12 w-12 text-gray-400" />
                <div className="flex text-sm text-gray-600">
                  <label className="relative cursor-pointer bg-white rounded-md font-medium text-teal-600 hover:text-teal-500">
                    <span>Upload files</span>
                    <input type="file" className="sr-only" multiple />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-4">
            <button
              type="button"
              onClick={() => setIsEditingProduct(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 rounded-md"
            >
              Save Product
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  const StoreCustomization = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-4xl w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold">Customize Your Store</h3>
          <button onClick={() => setIsCustomizing(false)}>
            <X className="h-6 w-6" />
          </button>
        </div>
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">Store Theme</label>
            <div className="mt-2 grid grid-cols-2 gap-4">
              {themes.map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => setStoreTheme(theme.id)}
                  className={`p-4 rounded-lg border-2 ${
                    storeTheme === theme.id
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-gray-200 hover:border-teal-200'
                  }`}
                >
                  <h4 className="font-medium">{theme.name}</h4>
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Banner Image</label>
            <div className="mt-2">
              <img
                src={storeBanner}
                alt="Store Banner"
                className="w-full h-48 object-cover rounded-lg"
              />
              <button className="mt-2 px-4 py-2 text-sm font-medium text-teal-600 bg-teal-50 rounded-md hover:bg-teal-100">
                Change Banner
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Store Description</label>
            <textarea
              value={storeDescription}
              onChange={(e) => setStoreDescription(e.target.value)}
              rows={4}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
              placeholder="Tell customers about your store..."
            />
          </div>
          <div className="flex justify-end gap-4">
            <button
              onClick={() => setIsCustomizing(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
            >
              Cancel
            </button>
            <button
              onClick={() => setIsCustomizing(false)}
              className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 rounded-md"
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Store Management</h1>
        <button
          onClick={() => setIsCustomizing(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600"
        >
          <Palette className="h-5 w-5" />
          Customize Store
        </button>
      </div>

      {/* Store Preview */}
      <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
        <div
          className="h-48 bg-cover bg-center"
          style={{ backgroundImage: `url(${storeBanner})` }}
        />
        <div className="p-6">
          <h2 className="text-2xl font-bold mb-4">Your Store Preview</h2>
          <p className="text-gray-600">{storeDescription || 'Add a store description...'}</p>
        </div>
      </div>

      {/* Products Management */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Products</h2>
          <button
            onClick={() => setIsEditingProduct(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-lg hover:from-teal-600 hover:to-emerald-600"
          >
            <Plus className="h-5 w-5" />
            Add Product
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <div key={product.id} className="border rounded-lg overflow-hidden">
              <img
                src={product.images[0] || 'https://via.placeholder.com/300'}
                alt={product.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="font-semibold mb-2">{product.name}</h3>
                <p className="text-gray-600 mb-2">${product.price}</p>
                <p className="text-sm text-gray-500 mb-4">Stock: {product.stock}</p>
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => {
                      setCurrentProduct(product);
                      setIsEditingProduct(true);
                    }}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-md"
                  >
                    <Edit className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => handleDeleteProduct(product.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-md"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modals */}
      {isEditingProduct && <ProductForm />}
      {isCustomizing && <StoreCustomization />}
    </div>
  );
}