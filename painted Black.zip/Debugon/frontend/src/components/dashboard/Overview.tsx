import React from 'react';
import { DollarSign, Package, Users, TrendingUp, Plus, Clock, BarChart, Settings } from 'lucide-react';
import StatsCard from './StatsCard';
import RecentOrders from './RecentOrders';

interface OverviewProps {
  onShowAddProduct: () => void;
  onShowUpdateHours: () => void;
  onShowAnalytics: () => void;
  onTabChange: (tab: string) => void;
}

export default function Overview({ 
  onShowAddProduct, 
  onShowUpdateHours, 
  onShowAnalytics, 
  onTabChange 
}: OverviewProps) {
  const stats = [
    {
      title: 'Total Sales',
      value: '$12,345',
      icon: <DollarSign className="h-6 w-6 text-teal-500" />,
      change: '+12.5%'
    },
    {
      title: 'Orders',
      value: '156',
      icon: <Package className="h-6 w-6 text-blue-500" />,
      change: '+8.2%'
    },
    {
      title: 'Customers',
      value: '1,245',
      icon: <Users className="h-6 w-6 text-purple-500" />,
      change: '+15.3%'
    },
    {
      title: 'Conversion Rate',
      value: '3.2%',
      icon: <TrendingUp className="h-6 w-6 text-green-500" />,
      change: '+2.1%'
    }
  ];

  const quickActions = [
    {
      icon: <Plus className="h-5 w-5" />,
      label: 'Add Product',
      onClick: onShowAddProduct,
      className: 'from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600'
    },
    {
      icon: <Clock className="h-5 w-5" />,
      label: 'Update Hours',
      onClick: onShowUpdateHours,
      className: 'from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600'
    },
    {
      icon: <BarChart className="h-5 w-5" />,
      label: 'Analytics',
      onClick: onShowAnalytics,
      className: 'from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600'
    },
    {
      icon: <Settings className="h-5 w-5" />,
      label: 'Settings',
      onClick: () => onTabChange('settings'),
      className: 'from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600'
    }
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {quickActions.map((action, index) => (
            <button
              key={index}
              onClick={action.onClick}
              className={`flex items-center gap-2 p-4 bg-gradient-to-r text-white rounded-lg ${action.className}`}
            >
              {action.icon}
              {action.label}
            </button>
          ))}
        </div>
      </div>

      <RecentOrders />
    </div>
  );
}