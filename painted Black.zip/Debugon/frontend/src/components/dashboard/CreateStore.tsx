import React, { useState } from 'react';
import { Upload, Plus, X } from 'lucide-react';
import { Store } from '../../types/marketplace';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';

interface CreateStoreProps {
  onStoreCreated: (store: Store) => void;
}

export default function CreateStore({ onStoreCreated }: CreateStoreProps) {
  const { state: { user } } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [coverImagePreview, setCoverImagePreview] = useState<string | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    location: '',
    categories: [] as string[],
    coverImage: null as File | null,
    profileImage: null as File | null
  });

  const categories = [
    'Jewelry',
    'Ceramics',
    'Textiles',
    'Woodwork',
    'Art',
    'Home Decor',
    'Accessories'
  ];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'cover' | 'profile') => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError('Image size should be less than 5MB');
        return;
      }

      const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        setError('Only JPG, PNG, and WebP images are allowed');
        return;
      }

      // Create preview URL
      const previewUrl = URL.createObjectURL(file);
      
      if (type === 'cover') {
        setFormData({ ...formData, coverImage: file });
        setCoverImagePreview(previewUrl);
      } else {
        setFormData({ ...formData, profileImage: file });
        setProfileImagePreview(previewUrl);
      }
    }
  };

  const uploadImage = async (file: File, path: string) => {
    try {
      const fileExt = file.name.split('.').pop()?.toLowerCase() || '';
      const allowedExts = ['jpg', 'jpeg', 'png', 'webp'];
      
      if (!allowedExts.includes(fileExt)) {
        throw new Error('Invalid file type');
      }

      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${path}/${fileName}`;

      // First check if the bucket exists and is accessible
      const { data: bucketData, error: bucketError } = await supabase
        .storage
        .getBucket('store-images');

      if (bucketError) {
        console.error('Bucket error:', bucketError);
        throw new Error('Storage is not properly configured');
      }

      // Upload the file
      const { error: uploadError, data } = await supabase.storage
        .from('store-images')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw new Error('Failed to upload image');
      }

      // Get the public URL
      const { data: { publicUrl } } = supabase.storage
        .from('store-images')
        .getPublicUrl(filePath);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading image:', error);
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setError('You must be logged in to create a store');
      return;
    }

    if (!formData.coverImage || !formData.profileImage) {
      setError('Both cover and profile images are required');
      return;
    }

    if (!formData.name.trim()) {
      setError('Store name is required');
      return;
    }

    if (!formData.description.trim()) {
      setError('Store description is required');
      return;
    }

    if (!formData.location.trim()) {
      setError('Store location is required');
      return;
    }

    if (formData.categories.length === 0) {
      setError('Please select at least one category');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Upload images
      const [coverImageUrl, profileImageUrl] = await Promise.all([
        uploadImage(formData.coverImage, 'covers'),
        uploadImage(formData.profileImage, 'profiles')
      ]);

      // Create store
      const { data: store, error: storeError } = await supabase
        .from('stores')
        .insert({
          name: formData.name.trim(),
          description: formData.description.trim(),
          location: formData.location.trim(),
          cover_image_url: coverImageUrl,
          profile_image_url: profileImageUrl,
          owner_id: user.id
        })
        .select()
        .single();

      if (storeError) {
        console.error('Store creation error:', storeError);
        throw new Error('Failed to create store');
      }

      if (!store) {
        throw new Error('No store data returned');
      }

      // Add categories
      if (formData.categories.length > 0) {
        const { error: categoriesError } = await supabase
          .from('store_categories')
          .insert(
            formData.categories.map(category => ({
              store_id: store.id,
              category
            }))
          );

        if (categoriesError) {
          console.error('Categories error:', categoriesError);
          throw new Error('Failed to add store categories');
        }
      }

      // Transform store data to match Store type
      const newStore: Store = {
        id: store.id,
        name: store.name,
        description: store.description || '',
        image: profileImageUrl,
        coverImage: coverImageUrl,
        owner: {
          name: user.name || 'Store Owner',
          image: profileImageUrl
        },
        rating: 0,
        reviews: 0,
        location: store.location || '',
        followers: 0,
        productsCount: 0,
        featured: false,
        categories: formData.categories,
        products: []
      };

      onStoreCreated(newStore);
    } catch (err) {
      console.error('Error creating store:', err);
      setError(err instanceof Error ? err.message : 'Failed to create store');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold mb-6">Create Your Store</h2>
        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-lg">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Store Images */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Cover Image
              </label>
              <div className="relative h-48 rounded-lg border-2 border-dashed border-gray-300 hover:border-teal-500 transition-colors overflow-hidden">
                <input
                  type="file"
                  accept="image/*"
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  onChange={(e) => handleImageChange(e, 'cover')}
                />
                {coverImagePreview ? (
                  <div className="absolute inset-0">
                    <img
                      src={coverImagePreview}
                      alt="Cover preview"
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setFormData({ ...formData, coverImage: null });
                        setCoverImagePreview(null);
                      }}
                      className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-md hover:bg-red-50"
                    >
                      <X className="h-4 w-4 text-red-500" />
                    </button>
                  </div>
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <Upload className="h-12 w-12 text-gray-400" />
                    <p className="mt-2 text-sm text-gray-500">Upload cover image</p>
                  </div>
                )}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Profile Image
              </label>
              <div className="relative h-48 rounded-lg border-2 border-dashed border-gray-300 hover:border-teal-500 transition-colors overflow-hidden">
                <input
                  type="file"
                  accept="image/*"
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  onChange={(e) => handleImageChange(e, 'profile')}
                />
                {profileImagePreview ? (
                  <div className="absolute inset-0">
                    <img
                      src={profileImagePreview}
                      alt="Profile preview"
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setFormData({ ...formData, profileImage: null });
                        setProfileImagePreview(null);
                      }}
                      className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-md hover:bg-red-50"
                    >
                      <X className="h-4 w-4 text-red-500" />
                    </button>
                  </div>
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <Upload className="h-12 w-12 text-gray-400" />
                    <p className="mt-2 text-sm text-gray-500">Upload profile image</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Store Details */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Store Name
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Location
            </label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Categories
            </label>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => {
                    const isSelected = formData.categories.includes(category);
                    setFormData({
                      ...formData,
                      categories: isSelected
                        ? formData.categories.filter((c) => c !== category)
                        : [...formData.categories, category]
                    });
                  }}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    formData.categories.includes(category)
                      ? 'bg-teal-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isLoading}
              className={`px-6 py-2 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-lg hover:from-teal-600 hover:to-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2`}
            >
              {isLoading ? 'Creating Store...' : 'Create Store'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}