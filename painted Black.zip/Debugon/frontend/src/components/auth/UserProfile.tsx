import React from 'react';
import { User, Settings, ShoppingBag, Heart, CreditCard } from 'lucide-react';

export default function UserProfile() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-center mb-6">
              <div className="w-24 h-24 rounded-full bg-teal-100 mx-auto mb-4 flex items-center justify-center">
                <User className="h-12 w-12 text-teal-500" />
              </div>
              <h2 className="text-xl font-semibold">John Doe</h2>
              <p className="text-gray-600">john.doe@example.com</p>
            </div>
            <nav className="space-y-2">
              <button className="w-full flex items-center gap-2 px-4 py-2 text-left rounded-lg bg-teal-50 text-teal-700">
                <User className="h-5 w-5" />
                Profile
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 text-left rounded-lg hover:bg-gray-50">
                <ShoppingBag className="h-5 w-5" />
                Orders
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 text-left rounded-lg hover:bg-gray-50">
                <Heart className="h-5 w-5" />
                Wishlist
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 text-left rounded-lg hover:bg-gray-50">
                <CreditCard className="h-5 w-5" />
                Payment Methods
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 text-left rounded-lg hover:bg-gray-50">
                <Settings className="h-5 w-5" />
                Settings
              </button>
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-xl font-semibold mb-6">Profile Information</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    First Name
                  </label>
                  <input
                    type="text"
                    defaultValue="John"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Last Name
                  </label>
                  <input
                    type="text"
                    defaultValue="Doe"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    defaultValue="john.doe@example.com"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Phone
                  </label>
                  <input
                    type="tel"
                    defaultValue="+1 (555) 123-4567"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Address
                </label>
                <textarea
                  defaultValue="123 Main St, Apt 4B, New York, NY 10001"
                  rows={3}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500"
                />
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="bg-teal-500 text-white px-6 py-2 rounded-lg hover:bg-teal-600 transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}