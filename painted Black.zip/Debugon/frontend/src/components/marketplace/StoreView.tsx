import React from 'react';
import { Star, Heart, Share2, ShoppingCart, MapPin, ArrowLeft } from 'lucide-react';
import { Store } from '../../types/marketplace';

interface StoreViewProps {
  store: Store;
  onBack: () => void;
}

export default function StoreView({ store, onBack }: StoreViewProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Store Header */}
      <div className="relative h-64 md:h-96">
        <img
          src={store.coverImage}
          alt={store.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
        <button
          onClick={onBack}
          className="absolute top-4 left-4 p-2 bg-white/90 rounded-full hover:bg-white transition-colors"
        >
          <ArrowLeft className="h-6 w-6 text-gray-900" />
        </button>
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8">
          <div className="max-w-7xl mx-auto flex items-center gap-6">
            <img
              src={store.owner.image}
              alt={store.owner.name}
              className="w-20 h-20 md:w-24 md:h-24 rounded-full border-4 border-white"
            />
            <div className="text-white">
              <h1 className="text-3xl md:text-4xl font-bold mb-2">{store.name}</h1>
              <div className="flex items-center gap-4 text-sm md:text-base">
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {store.location}
                </div>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 text-yellow-400 fill-current" />
                  <span>{store.rating}</span>
                  <span>({store.reviews} reviews)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Store Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Store Info */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">About {store.name}</h2>
          <p className="text-gray-600 mb-6">{store.description}</p>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-900">{store.productsCount}</div>
              <div className="text-sm text-gray-600">Products</div>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-900">{store.followers}</div>
              <div className="text-sm text-gray-600">Followers</div>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-900">{store.reviews}</div>
              <div className="text-sm text-gray-600">Reviews</div>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <h2 className="text-2xl font-bold mb-6">Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {store.products.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300"
            >
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-4 right-4 flex gap-2">
                  <button className="p-2 bg-white rounded-full shadow-lg hover:bg-pink-50">
                    <Heart className="h-5 w-5 text-pink-500" />
                  </button>
                  <button className="p-2 bg-white rounded-full shadow-lg hover:bg-blue-50">
                    <Share2 className="h-5 w-5 text-blue-500" />
                  </button>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
                <p className="text-gray-600 mb-4">{product.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-teal-600">
                    ${product.price.toFixed(2)}
                  </span>
                  <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-lg hover:from-teal-600 hover:to-emerald-600">
                    <ShoppingCart className="h-4 w-4" />
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}