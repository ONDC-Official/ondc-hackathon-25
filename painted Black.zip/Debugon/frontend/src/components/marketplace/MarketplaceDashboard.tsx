import React, { useState } from 'react';
import { Search, Filter, Grid, List, Sliders, TrendingUp, Star, Heart, Share2, Store, MapPin, Users, Package } from 'lucide-react';
import { Store as StoreType } from '../../types/marketplace';
import { sampleStores } from '../../data/sampleStores';
import StoreView from './StoreView';

export default function MarketplaceDashboard() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('trending');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStore, setSelectedStore] = useState<StoreType | null>(null);

  const categories = [
    'All Categories',
    'Jewelry',
    'Ceramics',
    'Textiles',
    'Woodwork',
    'Accessories',
    'Home & Living',
    'Art'
  ];

  const sortOptions = [
    { value: 'trending', label: 'Trending', icon: <TrendingUp className="h-4 w-4" /> },
    { value: 'rating', label: 'Highest Rated', icon: <Star className="h-4 w-4" /> },
    { value: 'newest', label: 'Newest First', icon: <TrendingUp className="h-4 w-4" /> }
  ];

  const filteredStores = sampleStores.filter(store => 
    (searchQuery === '' || 
      store.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      store.description.toLowerCase().includes(searchQuery.toLowerCase())) &&
    (selectedCategory === 'all' || store.categories.some(cat => 
      cat.toLowerCase() === selectedCategory.toLowerCase()))
  );

  if (selectedStore) {
    return <StoreView store={selectedStore} onBack={() => setSelectedStore(null)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Artisan Stores</h1>
            <p className="text-gray-600">Discover unique stores from talented artisans</p>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-lg ${
                viewMode === 'grid'
                  ? 'bg-teal-500 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Grid className="h-5 w-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-lg ${
                viewMode === 'list'
                  ? 'bg-teal-500 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-50'
              }`}
            >
              <List className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder="Search stores..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            <div className="flex gap-4">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="pl-4 pr-10 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              >
                {categories.map((category) => (
                  <option key={category} value={category.toLowerCase()}>
                    {category}
                  </option>
                ))}
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="pl-4 pr-10 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              >
                {sortOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <button className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50">
                <Sliders className="h-5 w-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        {/* Stores Grid */}
        <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8' : 'space-y-6'}>
          {filteredStores.map((store) => (
            <div
              key={store.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-1 transition-all duration-300"
            >
              <div className="relative h-48">
                <img
                  src={store.coverImage}
                  alt={store.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6">
                  <div className="flex items-center gap-4">
                    <img
                      src={store.owner.image}
                      alt={store.owner.name}
                      className="w-12 h-12 rounded-full border-2 border-white"
                    />
                    <div className="text-white">
                      <h3 className="font-semibold">{store.name}</h3>
                      <p className="text-sm opacity-90">{store.owner.name}</p>
                    </div>
                  </div>
                </div>
                {store.featured && (
                  <div className="absolute top-4 right-4 bg-teal-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    Featured
                  </div>
                )}
              </div>
              <div className="p-6">
                <p className="text-gray-600 mb-4">{store.description}</p>
                <div className="flex items-center gap-6 text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {store.location}
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    {store.followers} followers
                  </div>
                  <div className="flex items-center gap-1">
                    <Package className="h-4 w-4" />
                    {store.productsCount} products
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <span className="font-medium">{store.rating}</span>
                    <span className="text-gray-500">({store.reviews} reviews)</span>
                  </div>
                  <button
                    onClick={() => setSelectedStore(store)}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-lg hover:from-teal-600 hover:to-emerald-600"
                  >
                    <Store className="h-4 w-4" />
                    Visit Store
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}