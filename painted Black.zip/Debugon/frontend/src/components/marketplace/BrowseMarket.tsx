import React, { useState } from 'react';
import { Search, Filter, Star, Heart, Share2 } from 'lucide-react';

export default function BrowseMarket() {
  const [selectedCategory, setSelectedCategory] = useState('All Products');
  
  const categories = [
    { name: 'All Products', color: 'bg-gradient-to-r from-pink-500 to-rose-500' },
    { name: 'Jewelry', color: 'bg-gradient-to-r from-purple-500 to-indigo-500' },
    { name: 'Ceramics', color: 'bg-gradient-to-r from-blue-500 to-cyan-500' },
    { name: 'Textiles', color: 'bg-gradient-to-r from-emerald-500 to-teal-500' },
    { name: 'Woodwork', color: 'bg-gradient-to-r from-amber-500 to-orange-500' },
    { name: 'Leather', color: 'bg-gradient-to-r from-red-500 to-pink-500' },
    { name: 'Art', color: 'bg-gradient-to-r from-violet-500 to-purple-500' }
  ];

  const products = [
    {
      id: 1,
      name: 'Handwoven Wool Scarf',
      price: 79.99,
      image: 'https://images.unsplash.com/photo-1601244005535-a48d21d951ac?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      seller: 'Mountain Crafts Co.',
      rating: 4.8,
      likes: 234,
      category: 'Textiles'
    },
    {
      id: 2,
      name: 'Handmade Ceramic Vase',
      price: 149.99,
      image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      seller: 'Clay & Fire Studio',
      rating: 4.9,
      likes: 189,
      category: 'Ceramics'
    },
    {
      id: 3,
      name: 'Leather Messenger Bag',
      price: 199.99,
      image: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      seller: 'Urban Leather Works',
      rating: 4.7,
      likes: 312,
      category: 'Leather'
    },
    {
      id: 4,
      name: 'Abstract Wall Art',
      price: 299.99,
      image: 'https://images.unsplash.com/photo-1549887534-1541e9326642?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      seller: 'Modern Art Studio',
      rating: 4.9,
      likes: 428,
      category: 'Art'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-teal-500 to-emerald-500 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-center mb-6">Discover Unique Artisan Crafts</h1>
          <div className="max-w-3xl mx-auto relative">
            <input
              type="text"
              placeholder="Search for handcrafted treasures..."
              className="w-full pl-12 pr-4 py-3 rounded-full text-gray-900 placeholder-gray-500 focus:ring-4 focus:ring-teal-300 focus:border-transparent"
            />
            <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
            <button className="absolute right-3 top-2 px-4 py-1.5 bg-teal-600 text-white rounded-full hover:bg-teal-700 transition-colors">
              Search
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Categories */}
        <div className="flex gap-4 overflow-x-auto pb-4 mb-8 scrollbar-hide">
          {categories.map((category) => (
            <button
              key={category.name}
              onClick={() => setSelectedCategory(category.name)}
              className={`px-6 py-3 rounded-full text-white font-medium transition-transform hover:scale-105 ${
                category.color
              } ${
                selectedCategory === category.name ? 'ring-4 ring-white ring-offset-2' : ''
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-8">
          <button className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <Filter className="h-5 w-5" />
            <span>Price Range</span>
          </button>
          <button className="px-4 py-2 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
            Rating: 4+ Stars
          </button>
          <button className="px-4 py-2 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
            Free Shipping
          </button>
          <button className="px-4 py-2 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
            On Sale
          </button>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="group bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <button className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-md hover:bg-pink-50">
                  <Heart className="h-5 w-5 text-pink-500" />
                </button>
                <div className="absolute bottom-4 right-4 flex gap-2">
                  <button className="p-2 bg-white rounded-full shadow-md hover:bg-blue-50">
                    <Share2 className="h-5 w-5 text-blue-500" />
                  </button>
                </div>
              </div>
              <div className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-lg">{product.name}</h3>
                  <span className="text-emerald-600 font-bold">${product.price}</span>
                </div>
                <p className="text-sm text-gray-600 mb-3">{product.seller}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <span className="ml-1 text-sm text-gray-600">{product.rating}</span>
                    <span className="mx-2 text-gray-300">•</span>
                    <Heart className="h-4 w-4 text-pink-500" />
                    <span className="ml-1 text-sm text-gray-600">{product.likes}</span>
                  </div>
                  <span className="text-xs text-teal-600 font-medium px-2 py-1 bg-teal-50 rounded-full">
                    {product.category}
                  </span>
                </div>
                <button className="w-full mt-4 bg-gradient-to-r from-teal-500 to-emerald-500 text-white py-2 rounded-lg hover:from-teal-600 hover:to-emerald-600 transition-all duration-300 transform hover:scale-[1.02]">
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}