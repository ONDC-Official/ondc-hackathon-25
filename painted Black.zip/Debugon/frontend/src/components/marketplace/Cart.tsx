import React from 'react';
import { Trash2, Plus, Minus, Truck, Shield, CreditCard } from 'lucide-react';

export default function Cart() {
  const cartItems = [
    {
      id: 1,
      name: 'Handwoven Wool Scarf',
      price: 79.99,
      quantity: 1,
      image: 'https://images.unsplash.com/photo-1601244005535-a48d21d951ac?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      seller: 'Mountain Crafts Co.',
      delivery: '2-4 business days'
    },
    {
      id: 2,
      name: 'Ceramic Coffee Set',
      price: 129.99,
      quantity: 2,
      image: 'https://images.unsplash.com/photo-1610701596007-11502861dcfa?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      seller: 'Clay & Fire Studio',
      delivery: '3-5 business days'
    }
  ];

  const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shipping = 9.99;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold mb-8">Your Shopping Cart</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-6">
            {cartItems.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-xl shadow-md p-6 transform transition-all duration-300 hover:shadow-lg"
              >
                <div className="flex gap-6">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-32 h-32 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-lg mb-1">{item.name}</h3>
                        <p className="text-sm text-gray-600">Sold by {item.seller}</p>
                      </div>
                      <button className="text-red-500 hover:text-red-600 p-2 hover:bg-red-50 rounded-full transition-colors">
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                    <div className="mt-4 flex items-center justify-between">
                      <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-1">
                        <button className="p-1 hover:bg-white rounded-md transition-colors">
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="w-8 text-center font-medium">{item.quantity}</span>
                        <button className="p-1 hover:bg-white rounded-md transition-colors">
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                      <p className="font-bold text-lg text-teal-600">
                        ${(item.price * item.quantity).toFixed(2)}
                      </p>
                    </div>
                    <div className="mt-4 flex items-center text-sm text-gray-600">
                      <Truck className="h-4 w-4 mr-2" />
                      Estimated delivery: {item.delivery}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-semibold mb-6">Order Summary</h2>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className="font-medium">${shipping.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Estimated Tax</span>
                  <span className="font-medium">${tax.toFixed(2)}</span>
                </div>
                <div className="border-t pt-4">
                  <div className="flex justify-between">
                    <span className="font-semibold">Total</span>
                    <span className="font-bold text-xl text-teal-600">${total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
              <button className="w-full mt-6 bg-gradient-to-r from-teal-500 to-emerald-500 text-white py-3 rounded-lg font-medium hover:from-teal-600 hover:to-emerald-600 transition-all duration-300 transform hover:scale-[1.02]">
                Proceed to Checkout
              </button>
            </div>

            {/* Additional Info */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="font-semibold mb-4">Secure Shopping</h3>
              <div className="space-y-4 text-sm text-gray-600">
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-teal-500" />
                  <span>Buyer Protection Guaranteed</span>
                </div>
                <div className="flex items-center gap-3">
                  <CreditCard className="h-5 w-5 text-teal-500" />
                  <span>Secure Payment Processing</span>
                </div>
                <div className="flex items-center gap-3">
                  <Truck className="h-5 w-5 text-teal-500" />
                  <span>Free Returns within 30 Days</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}