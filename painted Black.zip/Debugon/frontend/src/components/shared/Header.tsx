import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, User, Bell, Menu, LayoutDashboard, Store } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import WalletConnect from '../blockchain/WalletConnect';

export default function Header() {
  const { state } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <h1 className="text-2xl font-bold text-teal-600">ArtisanHub</h1>
            </Link>
          </div>

          <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-8">
            <Link
              to="/browse"
              className="text-gray-500 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
            >
              Browse
            </Link>
            <div className="flex items-center space-x-4">
              <WalletConnect />
              {state.isAuthenticated && (
                <>
                  <Link
                    to="/dashboard"
                    className="text-gray-400 hover:text-gray-500"
                  >
                    <LayoutDashboard className="h-6 w-6" />
                  </Link>
                  <Link
                    to="/marketplace"
                    className="text-gray-400 hover:text-gray-500"
                  >
                    <Store className="h-6 w-6" />
                  </Link>
                  <Link
                    to="/notifications"
                    className="text-gray-400 hover:text-gray-500 relative"
                  >
                    <Bell className="h-6 w-6" />
                    <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400 ring-2 ring-white" />
                  </Link>
                  <Link to="/cart" className="text-gray-400 hover:text-gray-500">
                    <ShoppingCart className="h-6 w-6" />
                  </Link>
                  <Link
                    to="/profile"
                    className="text-gray-400 hover:text-gray-500"
                  >
                    <User className="h-6 w-6" />
                  </Link>
                </>
              )}
              {!state.isAuthenticated && (
                <Link
                  to="/login"
                  className="bg-gradient-to-r from-teal-500 to-emerald-500 text-white px-4 py-2 rounded-md text-sm font-medium hover:from-teal-600 hover:to-emerald-600"
                >
                  Sign In
                </Link>
              )}
            </div>
          </div>

          <div className="flex items-center sm:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-teal-500"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              to="/browse"
              className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
            >
              Browse
            </Link>
            {state.isAuthenticated && (
              <>
                <Link
                  to="/dashboard"
                  className="flex items-center px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                >
                  <LayoutDashboard className="h-6 w-6 mr-2" />
                  Dashboard
                </Link>
                <Link
                  to="/marketplace"
                  className="flex items-center px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                >
                  <Store className="h-6 w-6 mr-2" />
                  Marketplace
                </Link>
                <Link
                  to="/notifications"
                  className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                >
                  Notifications
                </Link>
                <Link
                  to="/cart"
                  className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                >
                  Cart
                </Link>
                <Link
                  to="/profile"
                  className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                >
                  Profile
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}