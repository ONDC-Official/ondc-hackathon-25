import React from 'react';
import { Users, Globe, Award, ShoppingBag, ArrowUpRight } from 'lucide-react';

export default function ImpactSection() {
  const stats = [
    { 
      value: '10,000+', 
      label: 'Active Artisans', 
      icon: <Users className="h-8 w-8" />,
      description: 'Talented creators from around the world'
    },
    { 
      value: '50+', 
      label: 'Countries', 
      icon: <Globe className="h-8 w-8" />,
      description: 'Global reach and cultural diversity'
    },
    { 
      value: '$2M+', 
      label: 'Artisan Earnings', 
      icon: <Award className="h-8 w-8" />,
      description: 'Direct income to creative communities'
    },
    { 
      value: '100,000+', 
      label: 'Products Sold', 
      icon: <ShoppingBag className="h-8 w-8" />,
      description: 'Unique handcrafted items delivered'
    }
  ];

  return (
    <div className="py-24 relative overflow-hidden bg-gradient-to-b from-gray-900 via-gray-900 to-black">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/2 -right-1/4 w-96 h-96 bg-teal-500/30 rounded-full blur-3xl" />
        <div className="absolute -bottom-1/2 -left-1/4 w-96 h-96 bg-emerald-500/30 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[size:24px_24px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1 rounded-full bg-teal-500/10 text-teal-400 text-sm font-medium mb-4">
            Our Global Reach
          </span>
          <h2 className="text-4xl font-bold text-white mb-4">Making a Global Impact</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Together, we're building a sustainable marketplace that empowers artisans
            and preserves traditional craftsmanship for future generations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div 
              key={index}
              className="relative group"
            >
              <div className="absolute -inset-0.5 bg-gradient-to-r from-teal-500 to-emerald-500 rounded-2xl blur opacity-25 group-hover:opacity-75 transition duration-500" />
              <div className="relative bg-gray-900 rounded-2xl p-8 ring-1 ring-gray-800 hover:ring-teal-500/50 transition-all duration-300">
                <div className="flex items-center justify-between mb-6">
                  <div className="p-3 bg-teal-500/10 rounded-xl text-teal-400">
                    {stat.icon}
                  </div>
                  <ArrowUpRight className="h-6 w-6 text-teal-400 opacity-0 group-hover:opacity-100 transform translate-x-2 group-hover:translate-x-0 transition-all" />
                </div>
                <div className="space-y-2">
                  <div className="text-4xl font-bold bg-gradient-to-r from-teal-400 to-emerald-400 text-transparent bg-clip-text">
                    {stat.value}
                  </div>
                  <div className="text-lg font-medium text-white">{stat.label}</div>
                  <p className="text-sm text-gray-400">{stat.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <button className="inline-flex items-center px-8 py-3 rounded-full bg-gradient-to-r from-teal-500 to-emerald-500 text-white font-medium hover:from-teal-600 hover:to-emerald-600 transform hover:scale-105 transition-all duration-300">
            Learn About Our Mission
            <ArrowUpRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}