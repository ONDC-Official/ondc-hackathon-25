import React from 'react';
import { Users, Sparkles, Shield } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      title: 'Create Your Account',
      description: 'Sign up and join our community of artisans and art enthusiasts',
      icon: <Users className="h-12 w-12 text-indigo-600" />,
      step: '01'
    },
    {
      title: 'Discover & Connect',
      description: 'Browse unique items and connect directly with talented artisans',
      icon: <Sparkles className="h-12 w-12 text-purple-600" />,
      step: '02'
    },
    {
      title: 'Safe & Secure Purchase',
      description: 'Shop with confidence using our secure payment system',
      icon: <Shield className="h-12 w-12 text-emerald-600" />,
      step: '03'
    }
  ];

  return (
    <div className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
          <p className="text-xl text-gray-600">Simple steps to start your artisanal journey</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {steps.map((step, index) => (
            <div key={index} className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-teal-500 to-emerald-500 rounded-lg blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
              <div className="relative bg-white rounded-lg p-8">
                <div className="text-6xl font-bold text-gray-200 absolute top-4 right-4">{step.step}</div>
                <div className="mb-6">{step.icon}</div>
                <h3 className="text-xl font-semibold mb-4">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}