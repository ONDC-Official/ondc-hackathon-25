import React from 'react';
import { Star } from 'lucide-react';
import Carousel from '../shared/Carousel';

export default function TestimonialsSection() {
  const testimonials = [
    {
      text: "The craftsmanship of every piece I've purchased is absolutely outstanding. Each item tells its own unique story.",
      author: "Emily Richardson",
      role: "Art Collector",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
      rating: 5,
      purchases: 12
    },
    {
      text: "Found incredible artisans from around the world. The platform has transformed how I source unique pieces for my clients.",
      author: "Michael Chen",
      role: "Interior Designer",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
      rating: 5,
      purchases: 28
    },
    {
      text: "Supporting artisans directly while discovering unique treasures - ArtisanHub has revolutionized my shopping experience.",
      author: "Sofia Martinez",
      role: "Boutique Owner",
      image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
      rating: 5,
      purchases: 35
    }
  ];

  return (
    <div className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">What Our Community Says</h2>
          <p className="text-xl text-gray-600">Hear from our satisfied customers and artisans</p>
        </div>
        <Carousel
          items={testimonials.map((testimonial) => (
            <div key={testimonial.author} className="px-4">
              <div className="bg-white rounded-2xl shadow-lg p-8 mx-4 transform hover:-translate-y-1 transition-all duration-300">
                <div className="flex items-center mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.author}
                    className="w-16 h-16 rounded-full object-cover ring-4 ring-teal-50"
                  />
                  <div className="ml-4">
                    <h4 className="text-xl font-semibold">{testimonial.author}</h4>
                    <p className="text-gray-600">{testimonial.role}</p>
                    <p className="text-sm text-teal-600">
                      {testimonial.purchases} purchases
                    </p>
                  </div>
                  <div className="ml-auto flex">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-lg text-gray-700 italic leading-relaxed">"{testimonial.text}"</p>
              </div>
            </div>
          ))}
          interval={6000}
          className="mb-12"
        />
      </div>
    </div>
  );
}