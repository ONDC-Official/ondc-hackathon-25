import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import Carousel from '../shared/Carousel';

export default function CategoryShowcase() {
  const categories = [
    {
      name: "Fine Jewelry",
      image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
      description: "Handcrafted jewelry pieces that tell a story",
      items: "2,345+ items",
      trending: true
    },
    {
      name: "Artisan Ceramics",
      image: "https://images.unsplash.com/photo-1493106641515-6b5631de4bb9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
      description: "Unique ceramic creations for your home",
      items: "1,890+ items",
      hot: true
    },
    {
      name: "Luxury Textiles",
      image: "https://images.unsplash.com/photo-1606744888344-493238951221?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
      description: "Beautiful handwoven textiles and fabrics",
      items: "2,120+ items"
    },
    {
      name: "Fine Woodwork",
      image: "https://images.unsplash.com/photo-1611486212557-88be5ff6f941?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
      description: "Expertly crafted wooden masterpieces",
      items: "1,670+ items",
      new: true
    }
  ];

  return (
    <div className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Explore Categories</h2>
          <p className="text-xl text-gray-600">Find the perfect handcrafted items in every category</p>
        </div>
        <Carousel
          items={categories.map((category) => (
            <Link
              key={category.name}
              to={`/browse?category=${category.name.toLowerCase()}`}
              className="px-4 block group"
            >
              <div className="relative overflow-hidden rounded-2xl aspect-[4/3]">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent flex flex-col justify-end p-8 opacity-90 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-3xl font-bold text-white">{category.name}</h3>
                    {category.trending && (
                      <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                        Trending
                      </span>
                    )}
                    {category.hot && (
                      <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                        Hot
                      </span>
                    )}
                    {category.new && (
                      <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                        New
                      </span>
                    )}
                  </div>
                  <p className="text-gray-200 mb-3">{category.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-teal-400">{category.items}</span>
                    <span className="text-white group-hover:translate-x-2 transition-transform duration-300">
                      Explore <ArrowRight className="inline-block h-5 w-5 ml-1" />
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
          className="mb-12"
        />
      </div>
    </div>
  );
}