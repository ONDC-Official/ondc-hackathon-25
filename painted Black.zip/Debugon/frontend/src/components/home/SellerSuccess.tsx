import React from 'react';
import { TrendingUp } from 'lucide-react';

export default function SellerSuccess() {
  const sellers = [
    {
      name: 'Maria Rodriguez',
      business: 'Traditional Textiles',
      image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
      story: 'Started with a single loom, now employs 10 local artisans and ships worldwide.',
      growth: '+400% growth'
    },
    {
      name: 'James Chen',
      business: 'Ceramic Arts Studio',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
      story: 'Transformed his hobby into a thriving business reaching customers globally.',
      growth: '1200+ orders'
    },
    {
      name: 'Sarah Thompson',
      business: 'Artisan Jewelry',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
      story: 'Built a six-figure business showcasing her unique jewelry designs.',
      growth: '$250K+ sales'
    }
  ];

  return (
    <div className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Seller Success Stories</h2>
          <p className="text-xl text-gray-600">Real stories from our thriving artisan community</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {sellers.map((seller, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-2 transition-all duration-300">
              <div className="relative">
                <img
                  src={seller.image}
                  alt={seller.name}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-0 inset-x-0 h-48 bg-gradient-to-b from-black/50 to-transparent" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{seller.name}</h3>
                <p className="text-teal-600 font-medium mb-4">{seller.business}</p>
                <p className="text-gray-600 mb-4">{seller.story}</p>
                <div className="flex items-center text-emerald-600">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  {seller.growth}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}