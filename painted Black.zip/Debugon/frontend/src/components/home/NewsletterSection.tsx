import React from 'react';
import { Mail } from 'lucide-react';

export default function NewsletterSection() {
  return (
    <div className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-teal-500 to-emerald-500 rounded-2xl p-12 relative overflow-hidden">
          <div className="absolute inset-0 bg-pattern opacity-10" />
          <div className="relative z-10">
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold text-white mb-4">Stay in the Loop</h2>
              <p className="text-xl text-teal-100">
                Get updates on new artisans, special offers, and curated collections
              </p>
            </div>
            <form className="max-w-xl mx-auto">
              <div className="flex gap-4">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-6 py-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-white"
                />
                <button
                  type="submit"
                  className="px-8 py-4 bg-white text-teal-600 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex items-center gap-2"
                >
                  <Mail className="h-5 w-5" />
                  Subscribe
                </button>
              </div>
              <p className="text-sm text-teal-100 mt-4 text-center">
                By subscribing, you agree to our Terms of Service and Privacy Policy
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}