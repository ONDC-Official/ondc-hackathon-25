import React from 'react';
import { Shield, CheckCircle, Award, Truck } from 'lucide-react';

export default function TrustSection() {
  const features = [
    {
      title: 'Secure Payments',
      description: 'Multiple secure payment options and encrypted transactions',
      icon: <Shield className="h-10 w-10 text-emerald-400" />
    },
    {
      title: 'Buyer Protection',
      description: '100% money-back guarantee for every purchase',
      icon: <CheckCircle className="h-10 w-10 text-blue-400" />
    },
    {
      title: 'Verified Sellers',
      description: 'Thoroughly vetted artisans and quality products',
      icon: <Award className="h-10 w-10 text-purple-400" />
    },
    {
      title: 'Safe Shipping',
      description: 'Tracked shipping and insurance on all orders',
      icon: <Truck className="h-10 w-10 text-pink-400" />
    }
  ];

  return (
    <div className="py-24 bg-gradient-to-r from-gray-900 to-indigo-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Shop with Confidence</h2>
          <p className="text-xl text-gray-300">Your security is our top priority</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-lg rounded-lg p-6 transform hover:-translate-y-2 transition-all duration-300">
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-300">{ feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}