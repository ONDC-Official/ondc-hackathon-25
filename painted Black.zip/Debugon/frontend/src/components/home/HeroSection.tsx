import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Gift } from 'lucide-react';

export default function HeroSection() {
  return (
    <div className="relative h-screen">
      <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/90 to-purple-900/90">
        <video
          autoPlay
          loop
          muted
          className="w-full h-full object-cover"
          poster="https://images.unsplash.com/photo-1558180077-09f158c76707?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80"
        >
          <source src="https://player.vimeo.com/external/373787639.hd.mp4?s=48b019b51d5c16a69d7b0cb24a8b7c03d833ffec&profile_id=175" type="video/mp4" />
        </video>
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="text-white max-w-3xl">
          <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight mb-8 leading-tight">
            Discover Unique
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-emerald-400">
              Handcrafted Treasures
            </span>
          </h1>
          <p className="text-xl text-black mb-10">
            Connect with talented artisans worldwide and find one-of-a-kind pieces that tell a story.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link
              to="/browse"
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-full text-white bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 transform hover:scale-105 transition-all duration-300"
            >
              Start Shopping
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              to="/become-seller"
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-full text-white bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 transform hover:scale-105 transition-all duration-300"
            >
              Become a Seller
              <Gift className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}