import React, { useState } from 'react';
import { Star, Heart, Share2, Eye, ShoppingCart, Zap, TrendingUp } from 'lucide-react';
import Carousel from '../shared/Carousel';

export default function FeaturedProducts() {
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);

  const featuredProducts = [
    {
      id: 1,
      name: "Handcrafted Leather Messenger Bag",
      price: "$249",
      image: "https://images.unsplash.com/photo-1524498250077-390f9e378fc0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
      artisan: "Leather & Thread Co.",
      rating: 4.9,
      likes: 342,
      discount: "15% OFF",
      timeLeft: "2 days",
      stock: 5
    },
    {
      id: 2,
      name: "Artisan Ceramic Tea Set",
      price: "$129",
      image: "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
      artisan: "Mountain Clay Studio",
      rating: 4.8,
      likes: 256,
      badge: "Best Seller",
      stock: 12
    },
    {
      id: 3,
      name: "Handwoven Wool Tapestry",
      price: "$299",
      image: "https://images.unsplash.com/photo-1615529182904-14819c35db37?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
      artisan: "Nordic Weaving Co.",
      rating: 5.0,
      likes: 189,
      badge: "New Arrival",
      stock: 3
    },
    {
      id: 4,
      name: "Handmade Silver Jewelry Set",
      price: "$199",
      image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
      artisan: "Silver & Stone Studio",
      rating: 4.9,
      likes: 278,
      discount: "20% OFF",
      timeLeft: "1 day",
      stock: 6
    }
  ];

  const handleQuickView = (productId: number) => {
    setSelectedProduct(productId === selectedProduct ? null : productId);
  };

  return (
    <div className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Artisan Pieces</h2>
          <p className="text-xl text-gray-600">Handpicked selections from our talented creators</p>
        </div>
        <Carousel
          items={featuredProducts.map((product) => (
            <div key={product.id} className="px-4">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="relative group">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-[400px] object-cover"
                  />
                  {product.discount && (
                    <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                      <Zap className="h-4 w-4" />
                      {product.discount}
                      {product.timeLeft && (
                        <span className="ml-1 text-xs">
                          ({product.timeLeft} left)
                        </span>
                      )}
                    </div>
                  )}
                  {product.badge && (
                    <div className="absolute top-4 left-4 bg-indigo-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                      <TrendingUp className="h-4 w-4" />
                      {product.badge}
                    </div>
                  )}
                  <div className="absolute top-4 right-4 flex gap-2">
                    <button 
                      onClick={() => handleQuickView(product.id)}
                      className="p-2 bg-white rounded-full shadow-lg hover:bg-gray-50 transform hover:scale-110 transition-all duration-300"
                    >
                      <Eye className="h-5 w-5 text-gray-600" />
                    </button>
                    <button className="p-2 bg-white rounded-full shadow-lg hover:bg-pink-50 transform hover:scale-110 transition-all duration-300">
                      <Heart className="h-5 w-5 text-pink-500" />
                    </button>
                    <button className="p-2 bg-white rounded-full shadow-lg hover:bg-blue-50 transform hover:scale-110 transition-all duration-300">
                      <Share2 className="h-5 w-5 text-blue-500" />
                    </button>
                  </div>
                  {selectedProduct === product.id && (
                    <div className="absolute inset-0 bg-black/75 flex items-center justify-center p-8">
                      <div className="bg-white rounded-lg p-6 max-w-md w-full">
                        <div className="flex justify-between items-start mb-4">
                          <h3 className="text-xl font-bold">{product.name}</h3>
                          <button 
                            onClick={() => setSelectedProduct(null)}
                            className="text-gray-400 hover:text-gray-500"
                          >
                            ×
                          </button>
                        </div>
                        <p className="text-gray-600 mb-4">By {product.artisan}</p>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-2xl font-bold text-indigo-600">{product.price}</span>
                          <span className="text-sm text-gray-500">Stock: {product.stock} left</span>
                        </div>
                        <button className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 text-white py-2 rounded-lg hover:from-teal-600 hover:to-emerald-600">
                          Add to Cart
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-semibold text-gray-900">{product.name}</h3>
                    <span className="text-2xl font-bold text-indigo-600">{product.price}</span>
                  </div>
                  <p className="text-gray-600 mb-4">By {product.artisan}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center">
                        <Star className="h-5 w-5 text-yellow-400 fill-current" />
                        <span className="ml-1 text-gray-600">{product.rating}</span>
                      </div>
                      <div className="flex items-center">
                        <Heart className="h-4 w-4 text-pink-500" />
                        <span className="ml-1 text-gray-600">{product.likes}</span>
                      </div>
                      {product.stock <= 5 && (
                        <span className="text-red-500 text-sm">
                          Only {product.stock} left!
                        </span>
                      )}
                    </div>
                    <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-lg hover:from-teal-600 hover:to-emerald-600 transform hover:scale-105 transition-all duration-300">
                      <ShoppingCart className="h-4 w-4" />
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
          className="mb-12"
        />
      </div>
    </div>
  );
}