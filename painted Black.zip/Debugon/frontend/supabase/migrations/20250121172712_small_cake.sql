/*
  # Marketplace Integration

  1. Changes
    - Add policy for public store visibility
    - Add policy for public product visibility
    - Add indexes for better marketplace performance
*/

-- Add indexes for better marketplace performance
CREATE INDEX IF NOT EXISTS stores_featured_idx ON stores(featured);
CREATE INDEX IF NOT EXISTS stores_rating_idx ON stores(rating);
CREATE INDEX IF NOT EXISTS stores_created_at_idx ON stores(created_at);
CREATE INDEX IF NOT EXISTS products_category_idx ON products(category);
CREATE INDEX IF NOT EXISTS products_price_idx ON products(price);
CREATE INDEX IF NOT EXISTS products_rating_idx ON products(rating);

-- Add composite indexes for common marketplace queries
CREATE INDEX IF NOT EXISTS stores_featured_rating_idx ON stores(featured, rating);
CREATE INDEX IF NOT EXISTS products_store_category_idx ON products(store_id, category);

-- Ensure RLS is enabled
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE store_categories ENABLE ROW LEVEL SECURITY;

-- Update store policies for marketplace visibility
DO $$
BEGIN
  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "Stores are viewable by everyone" ON stores;
  DROP POLICY IF EXISTS "Products are viewable by everyone" ON products;
  DROP POLICY IF EXISTS "Store categories are viewable by everyone" ON store_categories;

  -- Create new policies
  CREATE POLICY "Stores are viewable by everyone"
    ON stores
    FOR SELECT
    USING (true);

  CREATE POLICY "Products are viewable by everyone"
    ON products
    FOR SELECT
    USING (true);

  CREATE POLICY "Store categories are viewable by everyone"
    ON store_categories
    FOR SELECT
    USING (true);
END $$;