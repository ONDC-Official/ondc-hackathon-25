/*
  # Fix Storage Configuration

  1. Changes
    - Ensure storage bucket exists with proper configuration
    - Fix RLS policies for storage objects
    - Add proper folder structure validation
    - Remove invalid content size check
*/

-- Ensure the storage bucket exists with proper configuration
DO $$
BEGIN
  -- First try to create the bucket
  INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  VALUES (
    'store-images',
    'store-images',
    true,
    5242880, -- 5MB limit
    ARRAY['image/jpeg', 'image/png', 'image/webp']
  )
  ON CONFLICT (id) DO UPDATE
  SET 
    public = true,
    file_size_limit = 5242880,
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp'];

  -- Create required folders structure
  INSERT INTO storage.objects (bucket_id, name, owner, metadata)
  VALUES 
    ('store-images', 'profiles/.keep', auth.uid(), '{"contentType": "text/plain"}'),
    ('store-images', 'covers/.keep', auth.uid(), '{"contentType": "text/plain"}')
  ON CONFLICT DO NOTHING;
END $$;

-- Drop existing policies to avoid conflicts
DO $$
BEGIN
  DROP POLICY IF EXISTS "Store images are publicly accessible" ON storage.objects;
  DROP POLICY IF EXISTS "Users can upload store images" ON storage.objects;
  DROP POLICY IF EXISTS "Users can update store images" ON storage.objects;
  DROP POLICY IF EXISTS "Users can delete store images" ON storage.objects;
END $$;

-- Create new storage policies with proper checks
CREATE POLICY "Store images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'store-images');

CREATE POLICY "Users can upload store images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'store-images'
  AND auth.role() = 'authenticated'
  AND (storage.foldername(name))[1] IN ('profiles', 'covers')
);

CREATE POLICY "Users can update their own store images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'store-images'
  AND auth.role() = 'authenticated'
  AND owner = auth.uid()
);

CREATE POLICY "Users can delete their own store images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'store-images'
  AND auth.role() = 'authenticated'
  AND owner = auth.uid()
);

-- Ensure RLS is enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;