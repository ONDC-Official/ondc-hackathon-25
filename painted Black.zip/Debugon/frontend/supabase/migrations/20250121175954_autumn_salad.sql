-- Drop and recreate seller_kyc table with proper constraints
DROP TABLE IF EXISTS seller_kyc CASCADE;

CREATE TABLE seller_kyc (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid REFERENCES auth.users NOT NULL,
  business_name text NOT NULL,
  business_type text NOT NULL,
  gst_number text UNIQUE,
  pan_number text UNIQUE,
  address_line1 text NOT NULL,
  address_line2 text,
  city text NOT NULL,
  state text NOT NULL,
  postal_code text NOT NULL,
  country text NOT NULL DEFAULT 'India',
  verification_status text NOT NULL DEFAULT 'not_started',
  verified_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_verification_status CHECK (
    verification_status IN ('not_started', 'pending', 'verified', 'rejected')
  )
);

-- Enable RLS
ALTER TABLE seller_kyc ENABLE ROW LEVEL SECURITY;

-- Policies for seller_kyc
CREATE POLICY "Sellers can view their own KYC"
  ON seller_kyc
  FOR SELECT
  USING (auth.uid() = seller_id);

CREATE POLICY "Sellers can insert their own KYC"
  ON seller_kyc
  FOR INSERT
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Sellers can update their own KYC"
  ON seller_kyc
  FOR UPDATE
  USING (auth.uid() = seller_id);

-- Create index
CREATE INDEX idx_seller_kyc_seller_id ON seller_kyc(seller_id);