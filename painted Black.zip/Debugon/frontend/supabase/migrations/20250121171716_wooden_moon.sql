/*
  # Store Products Schema

  1. New Tables
    - `products`
      - `id` (uuid, primary key)
      - `store_id` (uuid, references stores)
      - `name` (text, required)
      - `description` (text)
      - `price` (numeric, required)
      - `stock` (integer, default 0)
      - `image_url` (text)
      - `category` (text)
      - `rating` (numeric, default 0)
      - `reviews_count` (integer, default 0)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on products table
    - Add policies for store owners and public access
*/

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid REFERENCES stores ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text,
  price numeric NOT NULL CHECK (price >= 0),
  stock integer DEFAULT 0,
  image_url text,
  category text,
  rating numeric DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  reviews_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Policies for products table
CREATE POLICY "Products are viewable by everyone"
  ON products
  FOR SELECT
  USING (true);

CREATE POLICY "Store owners can manage their products"
  ON products
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT owner_id FROM stores WHERE id = products.store_id
    )
  );

-- Create trigger for updating updated_at
CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create function to update store products count
CREATE OR REPLACE FUNCTION update_store_products_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE stores 
    SET products_count = products_count + 1
    WHERE id = NEW.store_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE stores 
    SET products_count = products_count - 1
    WHERE id = OLD.store_id;
  END IF;
  RETURN NULL;
END;
$$ language 'plpgsql';

-- Create triggers for updating store products count
CREATE TRIGGER products_insert_trigger
  AFTER INSERT ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_store_products_count();

CREATE TRIGGER products_delete_trigger
  AFTER DELETE ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_store_products_count();