/*
  # Fix storage policies

  1. Changes
    - Add DO block to safely handle policy creation
    - Check for existing policies before creating new ones
    - Ensure bucket exists with proper configuration
*/

-- Create the storage bucket with proper configuration
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  VALUES (
    'store-images',
    'store-images',
    true,
    5242880, -- 5MB limit
    ARRAY['image/jpeg', 'image/png', 'image/webp']
  )
  ON CONFLICT (id) DO UPDATE
  SET 
    public = true,
    file_size_limit = 5242880,
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp'];
END $$;

-- Enable RLS
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Safely create policies
DO $$
BEGIN
  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "Store images are publicly accessible" ON storage.objects;
  DROP POLICY IF EXISTS "Users can upload store images" ON storage.objects;
  DROP POLICY IF EXISTS "Users can update store images" ON storage.objects;
  DROP POLICY IF EXISTS "Users can delete store images" ON storage.objects;

  -- Create new policies
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Store images are publicly accessible'
  ) THEN
    CREATE POLICY "Store images are publicly accessible"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'store-images');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Users can upload store images'
  ) THEN
    CREATE POLICY "Users can upload store images"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = 'store-images'
      AND auth.role() = 'authenticated'
    );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Users can update store images'
  ) THEN
    CREATE POLICY "Users can update store images"
    ON storage.objects FOR UPDATE
    USING (
      bucket_id = 'store-images'
      AND auth.role() = 'authenticated'
    );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Users can delete store images'
  ) THEN
    CREATE POLICY "Users can delete store images"
    ON storage.objects FOR DELETE
    USING (
      bucket_id = 'store-images'
      AND auth.role() = 'authenticated'
    );
  END IF;
END $$;