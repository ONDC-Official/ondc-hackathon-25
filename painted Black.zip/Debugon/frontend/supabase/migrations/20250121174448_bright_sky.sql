-- Create enum types
CREATE TYPE document_status AS ENUM ('pending', 'verified', 'rejected');
CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'completed', 'failed');
CREATE TYPE settlement_status AS ENUM ('pending', 'processing', 'completed', 'failed');

-- Create orders table first
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id uuid REFERENCES auth.users NOT NULL,
  total_amount numeric NOT NULL CHECK (total_amount >= 0),
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create seller_kyc table
CREATE TABLE IF NOT EXISTS seller_kyc (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid REFERENCES auth.users NOT NULL,
  business_name text NOT NULL,
  business_type text NOT NULL,
  gst_number text UNIQUE,
  pan_number text UNIQUE,
  address_line1 text NOT NULL,
  address_line2 text,
  city text NOT NULL,
  state text NOT NULL,
  postal_code text NOT NULL,
  country text NOT NULL DEFAULT 'India',
  verification_status document_status DEFAULT 'pending',
  verified_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create seller_documents table
CREATE TABLE IF NOT EXISTS seller_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid REFERENCES auth.users NOT NULL,
  document_type text NOT NULL,
  document_number text NOT NULL,
  storage_path text NOT NULL,
  status document_status DEFAULT 'pending',
  verification_notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(seller_id, document_type)
);

-- Create seller_inventory table
CREATE TABLE IF NOT EXISTS seller_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products NOT NULL,
  seller_id uuid REFERENCES auth.users NOT NULL,
  quantity integer NOT NULL DEFAULT 0,
  reserved_quantity integer NOT NULL DEFAULT 0,
  low_stock_threshold integer NOT NULL DEFAULT 5,
  scheduled_quantity integer NOT NULL DEFAULT 0,
  scheduled_release_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create seller_payments table
CREATE TABLE IF NOT EXISTS seller_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid REFERENCES auth.users NOT NULL,
  order_id uuid REFERENCES orders NOT NULL,
  amount numeric NOT NULL CHECK (amount > 0),
  payment_status payment_status DEFAULT 'pending',
  settlement_status settlement_status DEFAULT 'pending',
  gateway text NOT NULL,
  gateway_payment_id text,
  gateway_settlement_id text,
  commission_amount numeric NOT NULL DEFAULT 0,
  net_amount numeric NOT NULL DEFAULT 0,
  settled_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE seller_kyc ENABLE ROW LEVEL SECURITY;
ALTER TABLE seller_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE seller_inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE seller_payments ENABLE ROW LEVEL SECURITY;

-- Policies for orders
CREATE POLICY "Users can view their own orders"
  ON orders
  FOR SELECT
  USING (auth.uid() = buyer_id);

-- Policies for seller_kyc
CREATE POLICY "Sellers can view their own KYC"
  ON seller_kyc
  FOR SELECT
  USING (auth.uid() = seller_id);

CREATE POLICY "Sellers can insert their own KYC"
  ON seller_kyc
  FOR INSERT
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Sellers can update their own KYC"
  ON seller_kyc
  FOR UPDATE
  USING (auth.uid() = seller_id);

-- Policies for seller_documents
CREATE POLICY "Sellers can view their own documents"
  ON seller_documents
  FOR SELECT
  USING (auth.uid() = seller_id);

CREATE POLICY "Sellers can insert their own documents"
  ON seller_documents
  FOR INSERT
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Sellers can update their own documents"
  ON seller_documents
  FOR UPDATE
  USING (auth.uid() = seller_id);

-- Policies for seller_inventory
CREATE POLICY "Sellers can view their own inventory"
  ON seller_inventory
  FOR SELECT
  USING (auth.uid() = seller_id);

CREATE POLICY "Sellers can manage their own inventory"
  ON seller_inventory
  FOR ALL
  USING (auth.uid() = seller_id);

-- Policies for seller_payments
CREATE POLICY "Sellers can view their own payments"
  ON seller_payments
  FOR SELECT
  USING (auth.uid() = seller_id);

-- Create indexes
CREATE INDEX idx_orders_buyer_id ON orders(buyer_id);
CREATE INDEX idx_seller_kyc_seller_id ON seller_kyc(seller_id);
CREATE INDEX idx_seller_documents_seller_id ON seller_documents(seller_id);
CREATE INDEX idx_seller_inventory_seller_id ON seller_inventory(seller_id);
CREATE INDEX idx_seller_inventory_product_id ON seller_inventory(product_id);
CREATE INDEX idx_seller_payments_seller_id ON seller_payments(seller_id);
CREATE INDEX idx_seller_payments_order_id ON seller_payments(order_id);

-- Create storage bucket for seller documents
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  VALUES (
    'seller-documents',
    'seller-documents',
    false,
    5242880, -- 5MB limit
    ARRAY['application/pdf', 'image/jpeg', 'image/png']
  )
  ON CONFLICT (id) DO UPDATE
  SET 
    public = false,
    file_size_limit = 5242880,
    allowed_mime_types = ARRAY['application/pdf', 'image/jpeg', 'image/png'];
END $$;

-- Create policies for seller documents bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage'
    AND policyname = 'Sellers can access their documents'
  ) THEN
    CREATE POLICY "Sellers can access their documents"
    ON storage.objects FOR SELECT
    USING (
      bucket_id = 'seller-documents'
      AND auth.role() = 'authenticated'
      AND (storage.foldername(name))[1] = auth.uid()::text
    );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage'
    AND policyname = 'Sellers can upload their documents'
  ) THEN
    CREATE POLICY "Sellers can upload their documents"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = 'seller-documents'
      AND auth.role() = 'authenticated'
      AND (storage.foldername(name))[1] = auth.uid()::text
    );
  END IF;
END $$;