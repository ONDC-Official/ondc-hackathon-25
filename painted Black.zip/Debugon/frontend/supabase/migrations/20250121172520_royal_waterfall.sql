/*
  # Create storage bucket and policies

  1. Changes
    - Create store-images bucket with proper configuration
    - Set up RLS policies for the bucket
    - Enable public access for viewing images
    - Allow authenticated users to manage their uploads
*/

-- Create the storage bucket with proper configuration
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  VALUES (
    'store-images',
    'store-images',
    true,
    5242880, -- 5MB limit
    ARRAY['image/jpeg', 'image/png', 'image/webp']
  )
  ON CONFLICT (id) DO UPDATE
  SET 
    public = true,
    file_size_limit = 5242880,
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp'];
END $$;

-- Enable RLS
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Allow public access to files
CREATE POLICY "Store images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'store-images');

-- Allow authenticated users to upload files
CREATE POLICY "Users can upload store images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'store-images'
  AND auth.role() = 'authenticated'
);

-- Allow authenticated users to update files
CREATE POLICY "Users can update store images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'store-images'
  AND auth.role() = 'authenticated'
);

-- Allow authenticated users to delete files
CREATE POLICY "Users can delete store images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'store-images'
  AND auth.role() = 'authenticated'
);