/*
  # Fix Storage Configuration

  1. Changes
    - Ensure storage schema exists
    - Configure storage bucket with proper settings
    - Set up correct policies for image uploads
    - Enable RLS
*/

-- Create storage schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS storage;

-- Create the storage bucket with proper configuration
DO $$
BEGIN
  -- First try to create the bucket
  INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  VALUES (
    'store-images',
    'store-images',
    true,
    5242880, -- 5MB limit
    ARRAY['image/jpeg', 'image/png', 'image/webp']
  )
  ON CONFLICT (id) DO UPDATE
  SET 
    public = true,
    file_size_limit = 5242880,
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp'];
END $$;

-- Ensure RLS is enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Create new storage policies with proper checks
DO $$
BEGIN
  -- Public read access
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage'
    AND policyname = 'Public Read Access'
  ) THEN
    CREATE POLICY "Public Read Access"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'store-images');
  END IF;

  -- Authenticated users can upload
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage'
    AND policyname = 'Authenticated Users Can Upload'
  ) THEN
    CREATE POLICY "Authenticated Users Can Upload"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = 'store-images'
      AND auth.role() = 'authenticated'
    );
  END IF;

  -- Users can update their own uploads
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage'
    AND policyname = 'Users Can Update Own Files'
  ) THEN
    CREATE POLICY "Users Can Update Own Files"
    ON storage.objects FOR UPDATE
    USING (
      bucket_id = 'store-images'
      AND auth.role() = 'authenticated'
      AND owner = auth.uid()
    );
  END IF;

  -- Users can delete their own uploads
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage'
    AND policyname = 'Users Can Delete Own Files'
  ) THEN
    CREATE POLICY "Users Can Delete Own Files"
    ON storage.objects FOR DELETE
    USING (
      bucket_id = 'store-images'
      AND auth.role() = 'authenticated'
      AND owner = auth.uid()
    );
  END IF;
END $$;