/*
  # Create storage bucket for store images

  1. New Storage Bucket
    - Creates a public bucket for store images
    - Enables public access for authenticated users
    - Sets up security policies
*/

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('store-images', 'store-images', true);

-- Allow public access to files
CREATE POLICY "Store images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'store-images');

-- Allow authenticated users to upload files
CREATE POLICY "Users can upload store images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'store-images'
  AND auth.role() = 'authenticated'
);

-- Allow users to update their own uploads
CREATE POLICY "Users can update their own store images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'store-images'
  AND owner = auth.uid()
);

-- Allow users to delete their own uploads
CREATE POLICY "Users can delete their own store images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'store-images'
  AND owner = auth.uid()
);