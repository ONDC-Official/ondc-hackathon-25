/*
  # Fix storage bucket policies

  1. Changes
    - Drop existing policies and recreate them with proper authentication checks
    - Add more permissive policies for store image uploads
    - Ensure proper owner assignment
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Store images are publicly accessible" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload store images" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their own store images" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own store images" ON storage.objects;

-- Create new policies
-- Allow public read access
CREATE POLICY "Store images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'store-images');

-- Allow authenticated users to upload files
CREATE POLICY "Users can upload store images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'store-images' 
  AND auth.role() = 'authenticated'
);

-- Allow authenticated users to update their files
CREATE POLICY "Users can update store images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'store-images'
  AND auth.role() = 'authenticated'
);

-- Allow authenticated users to delete their files
CREATE POLICY "Users can delete store images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'store-images'
  AND auth.role() = 'authenticated'
);