/*
  # Store Management Schema

  1. New Tables
    - `stores`
      - `id` (uuid, primary key)
      - `name` (text, required)
      - `description` (text)
      - `location` (text)
      - `cover_image_url` (text)
      - `profile_image_url` (text)
      - `owner_id` (uuid, references auth.users)
      - `rating` (numeric, default 0)
      - `reviews_count` (integer, default 0)
      - `followers_count` (integer, default 0)
      - `products_count` (integer, default 0)
      - `featured` (boolean, default false)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `store_categories`
      - `id` (uuid, primary key)
      - `store_id` (uuid, references stores)
      - `category` (text)

  2. Security
    - Enable RLS on all tables
    - Add policies for store owners and public access
*/

-- Create stores table
CREATE TABLE IF NOT EXISTS stores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  location text,
  cover_image_url text,
  profile_image_url text,
  owner_id uuid REFERENCES auth.users NOT NULL,
  rating numeric DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  reviews_count integer DEFAULT 0,
  followers_count integer DEFAULT 0,
  products_count integer DEFAULT 0,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create store categories table
CREATE TABLE IF NOT EXISTS store_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid REFERENCES stores ON DELETE CASCADE NOT NULL,
  category text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE store_categories ENABLE ROW LEVEL SECURITY;

-- Policies for stores table
CREATE POLICY "Stores are viewable by everyone"
  ON stores
  FOR SELECT
  USING (true);

CREATE POLICY "Users can create their own store"
  ON stores
  FOR INSERT
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can update their own store"
  ON stores
  FOR UPDATE
  USING (auth.uid() = owner_id);

CREATE POLICY "Users can delete their own store"
  ON stores
  FOR DELETE
  USING (auth.uid() = owner_id);

-- Policies for store_categories table
CREATE POLICY "Store categories are viewable by everyone"
  ON store_categories
  FOR SELECT
  USING (true);

CREATE POLICY "Store owners can manage categories"
  ON store_categories
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT owner_id FROM stores WHERE id = store_categories.store_id
    )
  );

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updating updated_at
CREATE TRIGGER update_stores_updated_at
  BEFORE UPDATE ON stores
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();