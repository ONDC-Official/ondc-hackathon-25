import React, { useState } from 'react';
import { Globe, Store, ChevronDown, ArrowRight, Phone, Mail, ArrowLeft, Camera, MapPin, Building2, User } from 'lucide-react';

// Language options
const languages = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'हिंदी' },
  { code: 'ta', name: 'தமிழ்' },
  { code: 'te', name: 'తెలుగు' },
];

// Business categories
const categories = [
  'Grocery Store',
  'Restaurant',
  'Fashion & Apparel',
  'Electronics',
  'Home & Furniture',
  'Beauty & Personal Care',
  'Books & Stationery',
  'Pharmacy',
  'Other'
];

type AuthMethod = 'phone' | 'email';
type AuthStep = 'initial' | 'phone' | 'email' | 'otp';
type ProfileStep = 'basic' | 'contact' | 'documents';

interface BusinessProfile {
  businessName: string;
  category: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  ownerName: string;
  contactNumber: string;
  gst: string;
  pan: string;
  storePhoto: string;
}

function App() {
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [isLanguageOpen, setIsLanguageOpen] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [authStep, setAuthStep] = useState<AuthStep>('initial');
  const [profileStep, setProfileStep] = useState<ProfileStep>('basic');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [profile, setProfile] = useState<BusinessProfile>({
    businessName: '',
    category: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    ownerName: '',
    contactNumber: '',
    gst: '',
    pan: '',
    storePhoto: ''
  });

  const handleStartSelling = () => {
    setShowAuth(true);
  };

  const handleAuthMethodSelect = (method: AuthMethod) => {
    setAuthStep(method);
  };

  const handleBack = () => {
    if (showProfile) {
      if (profileStep === 'contact') {
        setProfileStep('basic');
      } else if (profileStep === 'documents') {
        setProfileStep('contact');
      }
    } else if (authStep === 'otp') {
      setAuthStep('phone');
    } else {
      setAuthStep('initial');
    }
  };

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthStep('otp');
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowAuth(false);
    setShowProfile(true);
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowAuth(false);
    setShowProfile(true);
  };

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  const handleBasicDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setProfileStep('contact');
  };

  const handleContactDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setProfileStep('documents');
  };

  const handleDocumentsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle final submission
    console.log('Profile completed:', profile);
  };

  const renderAuthContent = () => {
    switch (authStep) {
      case 'initial':
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-center mb-8">Get Started</h2>
            <button
              onClick={() => handleAuthMethodSelect('phone')}
              className="w-full flex items-center justify-center space-x-3 bg-white border-2 border-gray-200 p-4 rounded-lg hover:border-blue-500 transition-colors"
            >
              <Phone className="h-5 w-5 text-gray-600" />
              <span className="text-lg">Continue with Phone</span>
            </button>
            <button
              onClick={() => handleAuthMethodSelect('email')}
              className="w-full flex items-center justify-center space-x-3 bg-white border-2 border-gray-200 p-4 rounded-lg hover:border-blue-500 transition-colors"
            >
              <Mail className="h-5 w-5 text-gray-600" />
              <span className="text-lg">Continue with Email</span>
            </button>
          </div>
        );

      case 'phone':
        return (
          <form onSubmit={handlePhoneSubmit} className="space-y-4">
            <h2 className="text-2xl font-bold text-center mb-8">Enter Your Phone Number</h2>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                id="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                placeholder="Enter your 10-digit number"
                pattern="[0-9]{10}"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Get OTP
            </button>
          </form>
        );

      case 'email':
        return (
          <form onSubmit={handleEmailSubmit} className="space-y-4">
            <h2 className="text-2xl font-bold text-center mb-8">Sign Up with Email</h2>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                placeholder="Enter your email"
                required
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                placeholder="Create a password"
                minLength={8}
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Create Account
            </button>
          </form>
        );

      case 'otp':
        return (
          <form onSubmit={handleOtpSubmit} className="space-y-4">
            <h2 className="text-2xl font-bold text-center mb-8">Enter OTP</h2>
            <p className="text-center text-gray-600 mb-4">
              We've sent a verification code to {phone}
            </p>
            <div>
              <label htmlFor="otp" className="block text-sm font-medium text-gray-700 mb-1">
                Verification Code
              </label>
              <input
                type="text"
                id="otp"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                placeholder="Enter 6-digit OTP"
                pattern="[0-9]{6}"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Verify & Continue
            </button>
          </form>
        );
    }
  };

  const renderProfileContent = () => {
    switch (profileStep) {
      case 'basic':
        return (
          <form onSubmit={handleBasicDetailsSubmit} className="space-y-6">
            <h2 className="text-2xl font-bold text-center mb-8">Business Details</h2>
            
            {/* Progress Indicator */}
            <div className="flex items-center justify-center space-x-2 mb-8">
              <div className="w-3 h-3 rounded-full bg-blue-600"></div>
              <div className="w-3 h-3 rounded-full bg-gray-200"></div>
              <div className="w-3 h-3 rounded-full bg-gray-200"></div>
            </div>

            <div className="space-y-4">
              <div>
                <label htmlFor="businessName" className="block text-sm font-medium text-gray-700 mb-1">
                  Business Name
                </label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="text"
                    id="businessName"
                    name="businessName"
                    value={profile.businessName}
                    onChange={handleProfileChange}
                    className="w-full pl-10 p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    placeholder="Enter your business name"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                  Business Category
                </label>
                <div className="relative">
                  <Store className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <select
                    id="category"
                    name="category"
                    value={profile.category}
                    onChange={handleProfileChange}
                    className="w-full pl-10 p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500 appearance-none bg-white"
                    required
                  >
                    <option value="">Select a category</option>
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5 pointer-events-none" />
                </div>
              </div>

              <div>
                <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                  Business Address
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="text"
                    id="address"
                    name="address"
                    value={profile.address}
                    onChange={handleProfileChange}
                    className="w-full pl-10 p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    placeholder="Enter your business address"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                    City
                  </label>
                  <input
                    type="text"
                    id="city"
                    name="city"
                    value={profile.city}
                    onChange={handleProfileChange}
                    className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    placeholder="City"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">
                    State
                  </label>
                  <input
                    type="text"
                    id="state"
                    name="state"
                    value={profile.state}
                    onChange={handleProfileChange}
                    className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    placeholder="State"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="pincode" className="block text-sm font-medium text-gray-700 mb-1">
                  PIN Code
                </label>
                <input
                  type="text"
                  id="pincode"
                  name="pincode"
                  value={profile.pincode}
                  onChange={handleProfileChange}
                  className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  placeholder="6-digit PIN code"
                  pattern="[0-9]{6}"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Continue
            </button>
          </form>
        );

      case 'contact':
        return (
          <form onSubmit={handleContactDetailsSubmit} className="space-y-6">
            <h2 className="text-2xl font-bold text-center mb-8">Contact Information</h2>
            
            {/* Progress Indicator */}
            <div className="flex items-center justify-center space-x-2 mb-8">
              <div className="w-3 h-3 rounded-full bg-blue-600"></div>
              <div className="w-3 h-3 rounded-full bg-blue-600"></div>
              <div className="w-3 h-3 rounded-full bg-gray-200"></div>
            </div>

            <div className="space-y-4">
              <div>
                <label htmlFor="ownerName" className="block text-sm font-medium text-gray-700 mb-1">
                  Owner's Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="text"
                    id="ownerName"
                    name="ownerName"
                    value={profile.ownerName}
                    onChange={handleProfileChange}
                    className="w-full pl-10 p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    placeholder="Enter owner's name"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="contactNumber" className="block text-sm font-medium text-gray-700 mb-1">
                  Contact Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="tel"
                    id="contactNumber"
                    name="contactNumber"
                    value={profile.contactNumber}
                    onChange={handleProfileChange}
                    className="w-full pl-10 p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    placeholder="10-digit mobile number"
                    pattern="[0-9]{10}"
                    required
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Continue
            </button>
          </form>
        );

      case 'documents':
        return (
          <form onSubmit={handleDocumentsSubmit} className="space-y-6">
            <h2 className="text-2xl font-bold text-center mb-8">Business Documents</h2>
            
            {/* Progress Indicator */}
            <div className="flex items-center justify-center space-x-2 mb-8">
              <div className="w-3 h-3 rounded-full bg-blue-600"></div>
              <div className="w-3 h-3 rounded-full bg-blue-600"></div>
              <div className="w-3 h-3 rounded-full bg-blue-600"></div>
            </div>

            <div className="space-y-4">
              <div>
                <label htmlFor="gst" className="block text-sm font-medium text-gray-700 mb-1">
                  GST Number (Optional)
                </label>
                <input
                  type="text"
                  id="gst"
                  name="gst"
                  value={profile.gst}
                  onChange={handleProfileChange}
                  className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  placeholder="Enter GST number"
                />
              </div>

              <div>
                <label htmlFor="pan" className="block text-sm font-medium text-gray-700 mb-1">
                  PAN Number
                </label>
                <input
                  type="text"
                  id="pan"
                  name="pan"
                  value={profile.pan}
                  onChange={handleProfileChange}
                  className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  placeholder="Enter PAN number"
                  pattern="[A-Z]{5}[0-9]{4}[A-Z]{1}"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Store Photo
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-200 border-dashed rounded-lg hover:border-blue-500 transition-colors cursor-pointer">
                  <div className="space-y-1 text-center">
                    <Camera className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label
                        htmlFor="storePhoto"
                        className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
                      >
                        <span>Upload a photo</span>
                        <input
                          id="storePhoto"
                          name="storePhoto"
                          type="file"
                          className="sr-only"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                setProfile(prev => ({
                                  ...prev,
                                  storePhoto: reader.result as string
                                }));
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">
                      PNG, JPG up to 10MB
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Complete Setup
            </button>
          </form>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Store className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">ONDC Connect</span>
          </div>
          
          {/* Language Selector */}
          <div className="relative">
            <button
              onClick={() => setIsLanguageOpen(!isLanguageOpen)}
              className="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Globe className="h-5 w-5 text-gray-600" />
              <span className="text-gray-700">
                {languages.find(lang => lang.code === selectedLanguage)?.name}
              </span>
              <ChevronDown className="h-4 w-4 text-gray-600" />
            </button>
            
            {isLanguageOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-10">
                {languages.map((language) => (
                  <button
                    key={language.code}
                    onClick={() => {
                      setSelectedLanguage(language.code);
                      setIsLanguageOpen(false);
                    }}
                    className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-blue-50 transition-colors"
                  >
                    {language.name}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {!showAuth && !showProfile ? (
          <>
            <div className="text-center">
              <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
                Get Your Business Online with ONDC Connect
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                Join India's digital commerce revolution. Create your online store in minutes, 
                reach more customers, and grow your business with ONDC.
              </p>
              <button 
                onClick={handleStartSelling}
                className="inline-flex items-center px-8 py-4 bg-blue-600 text-white text-lg font-semibold rounded-lg hover:bg-blue-700 transition-colors"
              >
                Start Selling
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>

            {/* Features Grid */}
            <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  title: 'Easy Setup',
                  description: 'Create your digital store in minutes with our simple, step-by-step process',
                  image: 'https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?auto=format&fit=crop&w=800&q=80'
                },
                {
                  title: 'Reach More Customers',
                  description: 'Connect with customers across India through the ONDC network',
                  image: 'https://images.unsplash.com/photo-1556740738-b6a63e27c4df?auto=format&fit=crop&w=800&q=80'
                },
                {
                  title: 'Grow Your Business',
                  description: 'Manage orders, track inventory, and expand your business digitally',
                  image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80'
                }
              ].map((feature, index) => (
                <div key={index} className="bg-white rounded-xl shadow-sm overflow-hidden">
                  <img 
                    src={feature.image} 
                    alt={feature.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Success Stories */}
            <div className="mt-24 bg-blue-50 rounded-2xl p-8">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                Success Stories
              </h2>
              <div className="max-w-3xl mx-auto bg-white rounded-xl p-6 shadow-sm">
                <div className="flex items-start space-x-4">
                  <img
                    src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=200&q=80"
                    alt="Store owner"
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="font-semibold text-gray-900">Rajesh Kumar</h3>
                    <p className="text-gray-600 mt-1">Local Grocery Store, Delhi</p>
                    <p className="text-gray-700 mt-2">
                      "ONDC Connect helped me bring my small grocery store online. 
                      Now I get orders from all over my neighborhood, and my business 
                      has grown by 40% in just three months!"
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="max-w-md mx-auto">
            {(authStep !== 'initial' || showProfile) && (
              <button
                onClick={handleBack}
                className="flex items-center text-gray-600 hover:text-gray-900 mb-8"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back
              </button>
            )}
            <div className="bg-white rounded-xl shadow-lg p-8">
              {showProfile ? renderProfileContent() : renderAuthContent()}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-50 mt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wider">
                Support
              </h4>
              <ul className="mt-4 space-y-2">
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900">
                    Contact Us
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wider">
                Legal
              </h4>
              <ul className="mt-4 space-y-2">
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900">
                    Terms of Service
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wider">
                About ONDC
              </h4>
              <ul className="mt-4 space-y-2">
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900">
                    What is ONDC?
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900">
                    Benefits
                  </a>
                </li>
              </ul>
            </div>
           </div>
          <div className="mt-8 pt-8 border-t border-gray-200">
            <p className="text-gray-400 text-center">
              © 2024 ONDC Connect. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;