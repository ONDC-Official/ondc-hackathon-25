# virtual_market_learner_team
virtual market is digital local market which both seller and buyers can use
Check out the [Virtual Market Learner Team](https://safiyaansari.github.io/virtual_market_learner_team/) project for more details.
[Demo Video](https://drive.google.com/file/d/1lfe2gBsyC7x-HxRt66nI_hG-yj5P6naB/view?usp=sharing)
