const dbController = require("./db_controller");

module.exports = {
  dbController,
};
