import { Info } from 'lucide-react-native';
import { iconWithClassName } from './iconWithClassName';
iconWithClassName(Info);
export { Info };