import { Sun } from 'lucide-react-native';
import { iconWithClassName } from './iconWithClassName';
iconWithClassName(Sun);
export { Sun };