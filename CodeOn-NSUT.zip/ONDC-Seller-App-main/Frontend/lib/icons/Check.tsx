import { Check } from 'lucide-react-native';
import { iconWithClassName } from './iconWithClassName';
iconWithClassName(Check);
export { Check };