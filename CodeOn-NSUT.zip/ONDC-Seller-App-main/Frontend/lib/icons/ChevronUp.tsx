import { ChevronUp } from 'lucide-react-native';
import { iconWithClassName } from './iconWithClassName';
iconWithClassName(ChevronUp);
export { ChevronUp };