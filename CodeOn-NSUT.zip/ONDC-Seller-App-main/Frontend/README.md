## To Run

### 1. npm install

### 2. npx expo start -c
