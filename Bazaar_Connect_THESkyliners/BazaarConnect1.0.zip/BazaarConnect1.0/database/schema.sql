CREATE TABLE Users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100),
    role ENUM('customer', 'seller', 'admin'),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE Inventory (
    id SERIAL PRIMARY KEY,
    sellerId INT REFERENCES Users(id),
    name VARCHAR(100),
    price DECIMAL(10, 2),
    stock INT,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE Orders (
    id SERIAL PRIMARY KEY,
    customerId INT REFERENCES Users(id),
    totalAmount DECIMAL(10, 2),
    status ENUM('pending', 'completed', 'cancelled'),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE Catalog (
    id SERIAL PRIMARY KEY,
    sellerId INT REFERENCES Users(id),
    name VARCHAR(100),
    price DECIMAL(10, 2),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Invoices Table
CREATE TABLE Invoices (
    id SERIAL PRIMARY KEY,
    order_id INT REFERENCES Orders(id),
    items JSON NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cart Table
CREATE TABLE Cart (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES Users(id),
    item_id INT REFERENCES Inventory(id),
    quantity INT NOT NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Payments Table
CREATE TABLE Payments (
    id SERIAL PRIMARY KEY,
    order_id INT REFERENCES Orders(id),
    payment_method VARCHAR(50) NOT NULL,
    payment_status VARCHAR(50) DEFAULT 'pending',
    amount DECIMAL(10, 2) NOT NULL,
    paid_at TIMESTAMP
);
