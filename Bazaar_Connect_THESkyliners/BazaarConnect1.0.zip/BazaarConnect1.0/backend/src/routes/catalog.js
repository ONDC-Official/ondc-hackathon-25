const express = require('express');
const router = express.Router();
const { verifySeller } = require('../middleware/auth');
const Catalog = require('../models/Catalog');

// Add Item to Catalog
router.post('/', verifySeller, async (req, res) => {
    try {
        const item = await Catalog.create(req.body);
        res.status(201).json(item);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Get Catalog
router.get('/', async (req, res) => {
    try {
        const catalog = await Catalog.findAll();
        res.json(catalog);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
