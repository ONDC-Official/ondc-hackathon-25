const express = require('express');
const router = express.Router();
const { verifyUser } = require('../middleware/auth');
const Orders = require('../models/Orders');
const Invoices = require('../models/Invoices');
const Payments = require('../models/Payments');

// Create Order and Invoice
router.post('/', verifyUser, async (req, res) => {
    try {
        const { items, total, paymentMethod } = req.body;

        // Create Order
        const newOrder = await Orders.create({
            userId: req.user.id,
            totalAmount: total,
            status: 'pending',
        });

        // Create Invoice
        const invoice = await Invoices.create({
            order_id: newOrder.id,
            items: JSON.stringify(items),
            total_amount: total,
        });

        // Create Payment Entry
        await Payments.create({
            order_id: newOrder.id,
            payment_method: paymentMethod,
            amount: total,
        });

        res.status(201).json({ message: 'Order and Invoice created', invoiceId: invoice.id });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Get All Orders
router.get('/', verifyUser, async (req, res) => {
    try {
        const orders = await Orders.findAll({ where: { userId: req.user.id } });
        res.json(orders);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Update Order Status
router.put('/:id', verifyUser, async (req, res) => {
    try {
        const updated = await Orders.update(req.body, { where: { id: req.params.id } });
        res.json(updated);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Track Payments
router.get('/payments', verifyUser, async (req, res) => {
    try {
        const payments = await Payments.findAll({ where: { userId: req.user.id } });
        res.json(payments);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
