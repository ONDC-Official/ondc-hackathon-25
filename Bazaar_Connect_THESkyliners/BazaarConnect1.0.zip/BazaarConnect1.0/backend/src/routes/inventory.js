const express = require('express');
const router = express.Router();
const { verifySeller } = require('../middleware/auth');
const Inventory = require('../models/Inventory');

// Create Inventory Item
router.post('/', verifySeller, async (req, res) => {
    try {
        const newItem = await Inventory.create(req.body);
        res.status(201).json(newItem);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Get Inventory
router.get('/', async (req, res) => {
    try {
        const inventory = await Inventory.findAll();
        res.json(inventory);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Update Inventory
router.put('/:id', verifySeller, async (req, res) => {
    try {
        const updated = await Inventory.update(req.body, { where: { id: req.params.id } });
        res.json(updated);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Delete Inventory
router.delete('/:id', verifySeller, async (req, res) => {
    try {
        await Inventory.destroy({ where: { id: req.params.id } });
        res.json({ message: 'Item deleted' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
