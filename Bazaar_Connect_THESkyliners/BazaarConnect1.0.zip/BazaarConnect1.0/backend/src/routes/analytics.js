const express = require('express');
const router = express.Router();
const Orders = require('../models/Orders');

// Get Sales Analytics
router.get('/sales', async (req, res) => {
    try {
        const sales = await Orders.findAll({
            attributes: [
                [sequelize.fn('DATE', sequelize.col('createdAt')), 'date'],
                [sequelize.fn('SUM', sequelize.col('totalAmount')), 'sales'],
            ],
            group: ['date'],
        });
        res.json(sales);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
