import React, { useEffect, useState } from 'react';
import api from '../utils/api';

const Inventory = () => {
    const [products, setProducts] = useState([]);

    const fetchInventory = async () => {
        const response = await api.get('/inventory');
        setProducts(response.data);
    };

    const handleDelete = async (id) => {
        await api.delete(`/inventory/${id}`);
        fetchInventory();
    };

    useEffect(() => {
        fetchInventory();
    }, []);

    return (
        <div className="p-6">
            <h1 className="text-3xl font-bold mb-4">Your Inventory</h1>
            <div className="space-y-4">
                {products.map((product) => (
                    <div key={product.id} className="p-4 bg-gray-100 rounded shadow">
                        <p className="text-lg font-medium">{product.name}</p>
                        <button
                            onClick={() => handleDelete(product.id)}
                            className="mt-2 px-4 py-2 text-white bg-red-500 rounded hover:bg-red-600"
                        >
                            Delete
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Inventory;
