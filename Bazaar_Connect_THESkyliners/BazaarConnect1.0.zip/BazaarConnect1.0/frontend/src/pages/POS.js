import React, { useState, useEffect } from 'react';
import axios from 'axios';

const POS = () => {
    const [inventory, setInventory] = useState([]);
    const [cart, setCart] = useState([]);
    const [total, setTotal] = useState(0);

    useEffect(() => {
        axios.get('/api/inventory').then((response) => {
            setInventory(response.data);
        });
    }, []);

    const addToCart = (item) => {
        const existingItem = cart.find((i) => i.id === item.id);
        if (existingItem) {
            setCart(cart.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i)));
        } else {
            setCart([...cart, { ...item, quantity: 1 }]);
        }
        setTotal((prev) => prev + item.price);
    };

    const removeFromCart = (itemId) => {
        const item = cart.find((i) => i.id === itemId);
        if (item) {
            if (item.quantity > 1) {
                setCart(cart.map((i) => (i.id === itemId ? { ...i, quantity: i.quantity - 1 } : i)));
            } else {
                setCart(cart.filter((i) => i.id !== itemId));
            }
            setTotal((prev) => prev - item.price);
        }
    };

    const checkout = () => {
        axios
            .post('/api/orders', { items: cart, total })
            .then((response) => {
                alert(`Order created successfully! Invoice ID: ${response.data.invoiceId}`);
                setCart([]);
                setTotal(0);
            })
            .catch((error) => {
                alert('Error during checkout: ' + error.message);
            });
    };

    return (
        <div className="p-6">
            <h1 className="text-3xl font-bold mb-6">Point of Sale</h1>
            <div className="grid grid-cols-2 gap-6">
                <div>
                    <h2 className="text-xl font-semibold mb-4">Inventory</h2>
                    <ul className="space-y-4">
                        {inventory.map((item) => (
                            <li key={item.id} className="flex justify-between items-center bg-gray-100 p-4 rounded shadow">
                                <span>{item.name} - ${item.price}</span>
                                <button
                                    onClick={() => addToCart(item)}
                                    className="px-4 py-2 text-white bg-blue-500 rounded hover:bg-blue-600"
                                >
                                    Add to Cart
                                </button>
                            </li>
                        ))}
                    </ul>
                </div>
                <div>
                    <h2 className="text-xl font-semibold mb-4">Cart</h2>
                    <ul className="space-y-4">
                        {cart.map((item) => (
                            <li key={item.id} className="flex justify-between items-center bg-gray-100 p-4 rounded shadow">
                                <span>
                                    {item.name} - ${item.price} x {item.quantity}
                                </span>
                                <button
                                    onClick={() => removeFromCart(item.id)}
                                    className="px-4 py-2 text-white bg-red-500 rounded hover:bg-red-600"
                                >
                                    Remove
                                </button>
                            </li>
                        ))}
                    </ul>
                    <h3 className="text-lg font-medium mt-4">Total: ${total.toFixed(2)}</h3>
                    <button
                        onClick={checkout}
                        className="mt-4 w-full px-4 py-2 text-white bg-green-500 rounded hover:bg-green-600"
                    >
                        Checkout
                    </button>
                </div>
            </div>
        </div>
    );
};

export default POS;
