import React from 'react';

const Home = () => {
  return (
    <div className="container mx-auto text-center py-16">
      <h1 className="text-4xl font-bold mb-6">Welcome to E-Dukaan</h1>
      <p className="text-lg mb-8">
        Transforming local markets into digital hubs.
      </p>
      <div className="space-x-4">
        <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
          Explore Products
        </button>
        <button className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
          Join as Seller
        </button>
      </div>
    </div>
  );
};

export default Home;
