import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import api from '../utils/api';

const Analytics = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const response = await api.get('/analytics/sales');
        setData(response.data);
      } catch (err) {
        alert('Error fetching analytics');
      }
    };
    fetchAnalytics();
  }, []);

  const chartData = {
    labels: data.map((item) => item.date),
    datasets: [
      {
        label: 'Sales',
        data: data.map((item) => item.sales),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
    ],
  };

  return (
    <div className="p-6 bg-white rounded shadow-lg">
      <h1 className="text-2xl font-semibold mb-4">Sales Analytics</h1>
      <Bar data={chartData} />
    </div>
  );
};

export default Analytics;
