import React, { useState } from 'react';
import api from '../utils/api';

const Catalog = () => {
  const [catalog, setCatalog] = useState([]);
  const [newItem, setNewItem] = useState({ name: '', price: '', stock: '' });

  const handleUpload = async () => {
    try {
      const response = await api.post('/catalog', newItem);
      setCatalog([...catalog, response.data]);
    } catch (err) {
      alert('Error uploading item');
    }
  };

  return (
    <div className="p-6 bg-white rounded shadow-lg">
      <h1 className="text-2xl font-semibold mb-4">Catalog Management</h1>
      <form
        className="flex flex-col space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          handleUpload();
        }}
      >
        <input
          className="border p-2 rounded"
          type="text"
          placeholder="Item Name"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
        />
        <input
          className="border p-2 rounded"
          type="number"
          placeholder="Price"
          value={newItem.price}
          onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
        />
        <input
          className="border p-2 rounded"
          type="number"
          placeholder="Stock"
          value={newItem.stock}
          onChange={(e) => setNewItem({ ...newItem, stock: e.target.value })}
        />
        <button className="bg-blue-500 text-white p-2 rounded hover:bg-blue-600">
          Upload
        </button>
      </form>
    </div>
  );
};

export default Catalog;
