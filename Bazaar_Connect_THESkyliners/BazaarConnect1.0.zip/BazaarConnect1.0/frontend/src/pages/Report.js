import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import api from '../utils/api';

const Reports = () => {
    const [data, setData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            const response = await api.get('/analytics/sales');
            setData(response.data);
        };
        fetchData();
    }, []);

    const chartData = {
        labels: data.map((item) => item.date),
        datasets: [
            {
                label: 'Sales',
                data: data.map((item) => item.sales),
                backgroundColor: 'rgba(75,192,192,0.6)',
            },
        ],
    };

    return <Bar data={chartData} />;
};

export default Reports;
