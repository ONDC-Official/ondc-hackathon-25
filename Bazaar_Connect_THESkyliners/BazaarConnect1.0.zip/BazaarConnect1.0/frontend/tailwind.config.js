module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'], // Includes all files inside src
  theme: {
      extend: {
          colors: {
              primary: '#1D4ED8', // Tailwind Blue
              secondary: '#10B981', // Tailwind Green
              accent: '#F59E0B', // Tailwind Yellow
              neutral: '#374151', // Tailwind Gray
              background: '#F3F4F6', // Light Background
          },
      },
  },
  plugins: [require('@tailwindcss/forms')], // Enables better form styling
};
