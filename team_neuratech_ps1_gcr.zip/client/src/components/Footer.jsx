import React from 'react'

export default function Footer() {
  return (
    <div className='footer'> &copy; 2025 All Rights Reserved</div>
  )
}
