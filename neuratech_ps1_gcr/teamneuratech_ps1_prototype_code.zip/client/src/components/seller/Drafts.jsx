import React from 'react'

export default function Drafts() {
  return (
    <div>Drafts</div>
  )
}
