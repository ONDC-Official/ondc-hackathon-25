export const base_url = "https://digic-backend.vercel.app/api/";
// export const base_url = "http://localhost:4000/api/";
