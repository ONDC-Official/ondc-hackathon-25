chrome.runtime.onInstalled.addListener(() => {
  console.log("BoldBuy Language Changer Extension Installed");
});
